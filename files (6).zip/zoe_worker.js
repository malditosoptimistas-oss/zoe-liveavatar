/**
 * ZOE — Cloudflare Worker
 * Puente entre LiveAvatar y Google Apps Script
 *
 * SETUP (5 minutos):
 * 1. Ir a https://workers.cloudflare.com → crear cuenta gratis
 * 2. Crear nuevo Worker → pegar este código
 * 3. Agregar variable de entorno: GAS_URL = tu webhook de GAS
 * 4. Deployar → copiar la URL del worker (ej: zoe-bridge.tuusuario.workers.dev)
 * 5. En GAS ejecutar: actualizarLLMConfig('https://zoe-bridge.tuusuario.workers.dev')
 */

export default {
  async fetch(request, env) {

    // CORS — LiveAvatar puede llamar desde cualquier origen
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);

    // LiveAvatar llama a /chat/completions — este es el endpoint que recibimos
    if (request.method === 'POST' && url.pathname === '/chat/completions') {

      try {
        const body = await request.json();

        // Extraer el último mensaje del usuario
        const messages = body.messages || [];
        let userMsg = '';
        for (let i = messages.length - 1; i >= 0; i--) {
          if (messages[i].role === 'user' && messages[i].content) {
            userMsg = messages[i].content.trim();
            break;
          }
        }

        if (!userMsg) {
          return openAIResponse('', corsHeaders);
        }

        // Llamar a GAS con el mensaje
        const gasUrl = env.GAS_URL;
        const gasRes = await fetch(gasUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: body.messages,
            user: body.user || 'Usuario',
            model: body.model
          })
        });

        if (!gasRes.ok) {
          console.error('GAS error:', gasRes.status);
          return openAIResponse('', corsHeaders);
        }

        const gasData = await gasRes.json();

        // GAS devuelve formato OpenAI si viene de LiveAvatar
        // o formato { reply: "..." } si viene del webhook normal
        let respuesta = '';
        if (gasData.choices && gasData.choices[0]) {
          respuesta = gasData.choices[0].message.content || '';
        } else if (gasData.reply) {
          respuesta = gasData.reply || '';
        }

        return openAIResponse(respuesta, corsHeaders);

      } catch (e) {
        console.error('Error:', e);
        return openAIResponse('', corsHeaders);
      }
    }

    // Health check
    if (url.pathname === '/') {
      return new Response(JSON.stringify({ status: 'ZOE Worker OK' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response('Not found', { status: 404 });
  }
};

function openAIResponse(content, corsHeaders) {
  return new Response(JSON.stringify({
    id: 'chatcmpl-zoe-' + Date.now(),
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model: 'gpt-4o-mini',
    choices: [{
      index: 0,
      message: { role: 'assistant', content: content || '' },
      finish_reason: 'stop'
    }],
    usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
}
