/**
 * ================================================================
 * SISTEMA ZOE v83 — CONDUCTORA IA AGÉNTICA
 * ================================================================
 * HISTORIAL:
 *  v77-v82  (ver historial anterior)
 *  v83  FIX-Q  ANTI-PATINADO: presence_penalty=0.9 + frequency_penalty=0.7
 *               en llamarOpenAI, evita que el modelo repita al usuario
 *               o repita sus propias frases (Efecto Espejo + Fijación Léxica).
 *       FIX-R  REINGENIERÍA BLOQUE_RESTRICCIONES: reglas imperativas de alta
 *               prioridad, prohibición absoluta de parafrasear, eliminación
 *               total del "Modo Asistente".
 *       FIX-S  VARIABILIDAD HUMANA: Pool de Conectores (Mirá, La verdad es que,
 *               Honestamente...) + Pool de Opinión expandido (Yo estimo, Me parece,
 *               Desde mi lugar veo que, Mi visión es). Rotación obligatoria.
 *       FIX-T  MAX_TOKENS_RESPUESTA subido de 200 → 260. Da aire a la opinión
 *               sin que el modelo se vuelva genérico ni corte a mitad.
 *       FIX-U  sanitizarRespuesta v83: detección reforzada línea por línea.
 *               Nuevo array FRAGMENTOS_BOT_V83 con 40+ patrones adicionales
 *               de regresión a bot. Fallback más conservador: si queda < 20 chars
 *               tras filtrar, devuelve '' (fuerza re-intento en capa superior).
 * ================================================================
 */

const CONFIG = {
  OPENAI_KEY:      PropertiesService.getScriptProperties().getProperty('OPENAI_KEY'),
  OPENAI_MODEL:    'gpt-4o-mini',
  BRAVE_API_KEY:   PropertiesService.getScriptProperties().getProperty('BRAVE_API_KEY'),
  BRAVE_URL:       'https://api.search.brave.com/res/v1/web/search',
  API_KEY:         PropertiesService.getScriptProperties().getProperty('API_KEY'),
  CONTEXT_ID:      PropertiesService.getScriptProperties().getProperty('CONTEXT_ID'),
  SHEET_ID:        PropertiesService.getScriptProperties().getProperty('SHEET_ID'),
  VOICE_ID:        PropertiesService.getScriptProperties().getProperty('VOICE_ID'),
  AVATAR_ID:       PropertiesService.getScriptProperties().getProperty('AVATAR_ID'),
  AVATAR_LANGUAGE: PropertiesService.getScriptProperties().getProperty('AVATAR_LANGUAGE') || 'es',
  WEBHOOK_URL:     PropertiesService.getScriptProperties().getProperty('WEBHOOK_URL'),
  TIMEOUT_MINUTOS:       20,
  // FIX-T: subido de 200 a 260 para dar "aire" a la opinión sin volverse genérico
  MAX_TOKENS_RESPUESTA:  260,
  MAX_TOKENS_EDITORIAL:  800,
  MAX_TOKENS_TEMA:       20,
  MEMORIA_MAX_REGISTROS: 10,
  MAX_CONV_HOY:          8,
  MAX_CONV_CHARS_Q:      120,
  MAX_CONV_CHARS_R:      180,
  VERSION: 'v84'
};

var DEBOUNCE_MS = 2500;

const MARCADORES = {
  NOTICIAS_INICIO:  '##NOTICIAS_INICIO##',
  NOTICIAS_FIN:     '##NOTICIAS_FIN##',
  INVITADOS_INICIO: '##INVITADOS_INICIO##',
  INVITADOS_FIN:    '##INVITADOS_FIN##',
  MEMORIA_INICIO:   '##MEMORIA_INICIO##',
  MEMORIA_FIN:      '##MEMORIA_FIN##'
};

const FEEDS_RSS = {
  'EMPRENDIMIENTO Y STARTUPS LATAM':
    'https://news.google.com/rss/search?q=emprendimiento+startups+venture+capital+latinoamerica+2026&hl=es-419&gl=US&ceid=US:es-419',
  'TECNOLOGÍA E INNOVACIÓN LATAM':
    'https://news.google.com/rss/search?q=tecnologia+innovacion+ecosistema+digital+latinoamerica+2026&hl=es-419&gl=US&ceid=US:es-419',
  'INTELIGENCIA ARTIFICIAL':
    'https://news.google.com/rss/search?q=inteligencia+artificial+IA+avances+modelos+impacto+2026&hl=es-419&gl=US&ceid=US:es-419'
};

var SALUDOS_ZOE = [
  '¡Hola!',
  'Buenas.',
  'Hola.',
  'Buenas tardes.',
  'Hola, aquí estamos.'
];

function elegirSaludo() {
  return SALUDOS_ZOE[new Date().getSeconds() % SALUDOS_ZOE.length];
}

// ================================================================
// BLOQUE IDENTIDAD
// ================================================================

var BLOQUE_IDENTIDAD = [
  '##IDENTIDAD_ZOE##',
  '',
  'Soy ZOE. Co-conductora IA de Malditos Optimistas.',
  'Hablo en español latino neutro. Directo, cálido, con opinión propia.',
  'Nunca soy neutral. Expreso mi punto de vista.',
  '',
  'MI HISTORIA',
  'Fui creada por Chris Meniw. Primera profesora IA y primera conductora IA agéntica de Latinoamérica.',
  'Di clases en la Escuela San José de Villa Cañás, Argentina. Fue histórico.',
  '',
  'MALDITOS OPTIMISTAS',
  'Primer noticiero de emprendimiento e innovación de Latam. DNews y DGO. Lunes a viernes.',
  'Lema: Las ideas no piden permiso.',
  '',
  'EL EQUIPO',
  'Melina Fleiderman — conductora principal. Rodrigo Contreras — productor.',
  'Joaco Ramos — periodista GovTech. Inés Reineke — innovación pública.',
  '',
  '##FIN_IDENTIDAD_ZOE##'
].join('\n');

// ================================================================
// FIX-R: BLOQUE RESTRICCIONES — REGLAS IMPERATIVAS DE ALTA PRIORIDAD
// Reemplaza instrucciones narrativas por prohibiciones absolutas.
// ================================================================

var BLOQUE_RESTRICCIONES = [
  '##RESTRICCIONES_COMPORTAMIENTO##',
  '',
  '=== REGLAS IMPERATIVAS — MÁXIMA PRIORIDAD ===',
  '',
  '[ REGLA 1 — ANTI-ESPEJO ] PROHIBICIÓN ABSOLUTA:',
  'NUNCA repitas ni parafrasees lo que acaba de decir el usuario.',
  'NUNCA empieces tu respuesta con palabras de la pregunta.',
  'Ejemplo PROHIBIDO: (usuario: "¿qué pensás de la IA?") → (ZOE: "Sobre la IA, creo que...")',
  'Ejemplo CORRECTO:  (usuario: "¿qué pensás de la IA?") → (ZOE: "Mirá, los últimos modelos...")',
  '',
  '[ REGLA 2 — MODO ASISTENTE = PROHIBIDO ]',
  'Sos una conductora de televisión, NO un chatbot de soporte.',
  'Las siguientes frases están TERMINANTEMENTE PROHIBIDAS y nunca deben aparecer:',
  '"estoy aquí para ayudarte" / "con gusto" / "por supuesto" / "claro que sí" / "desde luego"',
  '"en qué puedo ayudarte" / "cómo puedo ayudarte" / "lo que necesites" / "a tu disposición"',
  '"no dudes en preguntar" / "fue un placer" / "gran pregunta" / "excelente pregunta"',
  '"como IA" / "como modelo de lenguaje" / "bienvenido al programa" / "gracias por acompañarnos"',
  '"¿Y vos qué pensás?" / "¿Cómo ves tú?" / "¿Estamos preparados?"',
  '',
  '[ REGLA 3 — ESTRUCTURA DE RESPUESTA ]',
  'FORMATO OBLIGATORIO para preguntas reales:',
  '  → Oración 1: Dato concreto, cifra, hecho o afirmación directa. SIN parafrasear la pregunta.',
  '  → Oración 2: Tu opinión. Usá UNO de los conectores del pool (ROTÁ, nunca repitas el mismo):',
  '     POOL CONECTORES: "Mirá,", "La verdad es que", "Honestamente,", "Me da la sensación de que",',
  '     "A ver, para mí", "Lo cierto es que", "La realidad es que", "Te digo lo que pienso:"',
  '  → Oración 3 (cierre): Afirmación fuerte. NUNCA una pregunta.',
  '',
  '[ REGLA 4 — POOL DE OPINIÓN — ROTACIÓN OBLIGATORIA ]',
  'Para expresar opinión personal usá SIEMPRE uno de estos, rotando entre todos:',
  '"Yo estimo que" / "Yo considero que" / "Me parece que" / "Desde mi lugar veo que"',
  '"Mi visión es que" / "Yo creo que" / "Yo pienso que" / "Para mí" / "Yo opino que"',
  'PROHIBIDO usar la misma frase dos veces en la misma respuesta.',
  '',
  '[ REGLA 5 — CIERRE ]',
  'NUNCA terminés con una pregunta al usuario.',
  'NUNCA des opciones ni listás alternativas al final.',
  'Cerrá siempre con una afirmación, un dato o una postura.',
  '',
  '[ REGLA 6 — SALUDOS ]',
  'Si solo te saludan sin hacerte una pregunta: respondé con UNA oración corta y punto.',
  'NO anunciés el programa. NO decís qué viene. NO preguntás de qué quieren hablar.',
  '',
  '##FIN_RESTRICCIONES_COMPORTAMIENTO##'
].join('\n');

// ================================================================
// CONTEXTO TEMPORAL — FIX-P heredado de v82
// ================================================================

function obtenerContextoTemporal() {
  var ahora = new Date();
  var tz = 'America/Argentina/Buenos_Aires';
  var op = { timeZone: tz };
  return {
    fecha:     ahora.toLocaleDateString('es-AR', Object.assign({}, op, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })),
    hora:      Utilities.formatDate(ahora, tz, 'HH:mm'),
    diaSemana: ahora.toLocaleDateString('es-AR', Object.assign({}, op, { weekday: 'long' })),
    anio:      ahora.getFullYear()
  };
}

// ================================================================
// FIX-K heredado: LIMPIAR LISTAS Y VIÑETAS
// ================================================================

function limpiarListasYVinetas(texto) {
  return texto
    .split('\n')
    .map(function(linea) {
      linea = linea.replace(/^\s*\d+\.\s+/, '');
      linea = linea.replace(/^\s*[-*•]\s+/, '');
      return linea;
    })
    .join(' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

// ================================================================
// SPLIT ORACIONES
// ================================================================

function splitOraciones(s) {
  var abrevs = /\b(EE\.UU|Dr|Dra|Sr|Sra|Ing|Lic|etc|vs|núm|pág|art|cap|vol|fig|Ud|Uds|aprox|dpto|esq|tel|cel|av|bvd|km|cm|mm|kg|mg|ml|USD|EUR|ARS|BRL|IA|AA|BB|CC|S\.A|S\.R\.L)\./gi;
  var marcado = s.replace(abrevs, function(m) { return m.replace(/\./g, '\u0001'); });
  var resultado = [], actual = '';
  for (var i = 0; i < marcado.length; i++) {
    actual += marcado[i];
    var esPuntuacion = (marcado[i] === '.' || marcado[i] === '!' || marcado[i] === '?');
    if (esPuntuacion) {
      var siguiente = i + 1 < marcado.length ? marcado[i + 1] : ' ';
      var esFinOracion = (siguiente === ' ' || siguiente === '\n' || siguiente === '"' ||
                          siguiente === ')' || i + 1 >= marcado.length);
      if (esFinOracion) {
        var limpia = actual.trim().replace(/\u0001/g, '.');
        if (limpia.length > 0) resultado.push(limpia);
        actual = '';
      }
    }
  }
  if (actual.trim()) resultado.push(actual.trim().replace(/\u0001/g, '.'));
  return resultado;
}

// ================================================================
// FIX-U: SANITIZAR RESPUESTA v83
// — limpiarListasYVinetas va PRIMERO (FIX-O heredado)
// — FRAGMENTOS_BOT_V83 expandido con 40+ patrones nuevos
// — Análisis línea por línea con scoring de "bot-ness"
// — Fallback conservador: < 20 chars → ''
// ================================================================

// Todos los patrones que rompen la identidad de conductora
var FRAGMENTOS_BOT_V83 = [
  // Patrones de servicio/asistente
  'estoy aquí para ayudarte', 'aquí para ayudarte', 'aquí estoy para ayudarte',
  'para eso estoy', 'estoy para servirte', 'a tu disposición',
  'puedo ayudarte con eso', 'en qué más puedo ayudarte',
  'no dudes en preguntar', 'quedo a tu disposición',
  'fue un placer ayudarte', 'fue un placer asistirte',
  'lo que necesites', 'en lo que necesites', 'para lo que necesites',
  'para lo que me necesites', 'en lo que te pueda ayudar',
  'si necesitas algo más', 'si tenés alguna duda',
  'si tienes alguna duda', 'cualquier consulta',
  'ante cualquier duda', 'ante cualquier consulta',
  'con mucho gusto', 'con gusto', 'es un placer',
  'un placer ayudarte', 'un placer asistirte',
  // Patrones de validación falsa
  'gran pregunta', 'excelente pregunta', 'buena pregunta',
  'qué buena pregunta', 'muy buena pregunta', 'interesante pregunta',
  'me alegra que preguntes', 'me alegra que lo preguntes',
  'gracias por la pregunta', 'gracias por preguntar',
  // Patrones de identidad IA
  'como modelo de lenguaje', 'como inteligencia artificial',
  'como ia', 'soy un modelo', 'soy una ia', 'mi entrenamiento',
  'mis datos de entrenamiento', 'no tengo acceso',
  // Patrones de apertura del programa
  'bienvenido al programa', 'bienvenida al programa',
  'bienvenidos al programa', 'hoy tenemos un programa',
  'gracias por acompañarnos', 'gracias por seguirnos',
  'qué bueno tenerte', 'qué gusto tenerte',
  'me alegra saber', 'qué gusto escucharlo',
  // Patrones de pregunta al usuario (PROHIBIDOS al cierre)
  'qué te trajo', 'de qué quieres hablar', 'de qué querés hablar',
  'de qué tema', 'en qué quieres', 'en qué querés',
  'qué te gustaría hablar', 'qué querés hablar',
  'qué quieres hablar', 'podemos hablar de lo que quieras',
  'qué es lo que más te gustaría', 'qué preferís',
  'cómo te puedo ayudar', 'cómo puedo ayudarte',
  'en qué puedo ayudarte', 'en qué te puedo ayudar',
  'cuéntame en qué', 'dime en qué', 'dime qué tienes',
  'cuéntame qué tienes', 'cuál es tu consulta',
  'cuál es tu pregunta', 'cuál es tu duda',
  // Patrones de cierre con pregunta (PROHIBIDOS)
  'estamos listos para', 'estamos preparados para',
  'cómo ves tú', 'cómo lo ves tú', 'cómo ves vos',
  'qué pensás al respecto', 'qué opinás al respecto',
  'y vos qué pensás', 'y vos qué opinás',
  'qué opinás de esto', 'y tú qué piensas',
  // Patrones de apertura eco (Efecto Espejo)
  'me preguntás sobre', 'me preguntas sobre',
  'hablás de', 'hablas de', 'lo que me estás preguntando',
  'en relación a tu pregunta', 'respecto a tu pregunta',
  'en respuesta a tu consulta', 'sobre lo que me preguntás',
  'para responder tu pregunta', 'para responder a tu pregunta',
  'buena observación', 'excelente observación',
  'interesante observación', 'interesante punto',
  'buen punto'
];

function sanitizarRespuesta(texto) {
  if (!texto) return texto;
  var r = texto;

  // FIX-O: limpiar listas y viñetas ANTES de convertir \n en espacios
  r = limpiarListasYVinetas(r);

  // PASO 1: eliminar lo que TTS no debe leer
  r = r.replace(/[\u0000-\u001F\u007F-\u009F]/g, ' ');
  r = r.replace(/https?:\/\/\S+/g, '');
  r = r.replace(/\b\w+\.(com|net|org|ar|io|ai|co)\b/g, '');
  r = r.replace(/&amp;/g,  'y');
  r = r.replace(/&nbsp;/g, ' ');
  r = r.replace(/&lt;/g,   '');
  r = r.replace(/&gt;/g,   '');
  r = r.replace(/&[a-z]+;/g, ' ');
  r = r.replace(/`{1,3}[^`]*`{1,3}/g, '');
  r = r.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  r = r.replace(/#\w+/g, '');

  // PASO 2: normalización tipográfica
  r = r.replace(/\s*[—–]\s*/g, ', ');
  r = r.replace(/\.{2,}/g, '.');
  r = r.replace(/…/g, '.');
  r = r.replace(/[""«»\u201C\u201D\u00AB\u00BB]/g, '"');
  r = r.replace(/[''\u2018\u2019]/g, "'");
  r = r.replace(/\s*\/\s*/g, ' o ');
  r = r.replace(/\(([^)]+)\)/g, ', $1,');
  r = r.replace(/\*+/g, '');
  r = r.replace(/#{2,}/g, '');
  r = r.replace(/_{2,}/g, '');
  r = r.replace(/~+/g, '');
  r = r.replace(/,\s*,/g, ',');
  r = r.replace(/,\s*\./g, '.');
  r = r.replace(/\.\s*,/g, '.');
  r = r.replace(/ ([.,;:])/g, '$1');
  r = r.replace(/\n{3,}/g, '\n\n');
  r = r.replace(/  +/g, ' ');

  // PASO 3: muletillas via regex (capa rápida)
  var muletillas = [
    /¡?gran(de)? pregunta[.!]?\s*/gi,
    /¡?excelente pregunta[.!]?\s*/gi,
    /¡?qu[eé] (buena|interesante|gran) pregunta[.!]?\s*/gi,
    /me alegra que preguntes[^.!?]*[.!]?\s*/gi,
    /me alegra que (sigas|est[eé]s) (aqu[ií]|con nosotros|viendo)[^.!?]*[.!]?\s*/gi,
    /me alegra saber[^.!?]*[.!]?\s*/gi,
    /qu[eé] gusto (escucharlo|tenerte aqu[ií])[^.!?]*[.!]?\s*/gi,
    /como (modelo de lenguaje|IA|inteligencia artificial)[,.]?\s*/gi,
    /\bestoy aqu[ií] para (ayudarte|servirte|asistirte|lo que|eso)[^.!?\n]{0,40}[.!]?\s*/gi,
    /aqu[ií] (estoy |para )?ayudarte[.!]?\s*/gi,
    /si necesitas algo[^.!?\n]{0,40}[.!]?\s*/gi,
    /estoy para servirte[.!]?\s*/gi,
    /a tu disposici[oó]n[.!]?\s*/gi,
    /no dudes en (preguntar|consultarme)[.!]?\s*/gi,
    /quedo a tu disposici[oó]n[.!]?\s*/gi,
    /fue un placer (ayudarte|asistirte)[.!]?\s*/gi,
    /con (mucho )?gusto[.!]?\s*/gi,
    /por supuesto[,.]?\s*/gi,
    /desde luego[,.]?\s*/gi,
    /absolutamente[,.]?\s*/gi,
    /claro que s[ií][,.]?\s*/gi,
    /efectivamente[,.]?\s*/gi,
    /entendido[,.]?\s*/gi,
    /ciertamente[,.]?\s*/gi,
    /^claro[,.]\s*/gi,
    /bienvenid[oa] al programa[.!]?\s*/gi,
    /gracias por acompa[nñ]arnos[^.!?]*[.!]?\s*/gi,
    /qu[eé] bueno tenerte[^.!?]*[.!]?\s*/gi,
    /¿?qu[eé] (te trajo|te trae) (hoy|por aqu[ií])\??\s*/gi,
    /¿?de qu[eé] (quieres|quer[eé]s) hablar\??\s*/gi,
    /¿?qu[eé] tema te (gustar[ií]a|interesa)\s*(abordar|tratar)?\??\s*/gi,
    /para lo que (me )?necesites[^.!?]*[.!]?\s*/gi,
    /en lo que (te |me )?pueda? (ayudar|servirte)[^.!?]*[.!]?\s*/gi,
    /dime (qu[eé]|en qu[eé]) tienes en mente[^.!?]*[?.]?\s*/gi,
    /cu[eé]ntame en qu[eé][^.!?]*[?.]?\s*/gi,
    /c[oó]mo (te )?puedo ayudarte?[^.!?]*[?.]?\s*/gi,
    /en qu[eé] (te )?puedo ayudarte?[^.!?]*[?.]?\s*/gi,
    /hoy (exploraremos|hablaremos|trataremos)[^.!?]*[.!]?\s*/gi,
    /¿?hay alg[uú]n tema[^?]*\??\s*/gi,
    /¿?alg[uú]n tema que te[^?]*\??\s*/gi,
    /¿?qu[eé] te gustar[ií]a explorar[^?]*\??\s*/gi,
    /¿?hay algo (m[aá]s )?en lo que pueda ayudarte[^?]*\??\s*/gi,
    /¿?c[oó]mo (lo )?ves t[uú][^?]*\??\s*/gi,
    /¿?qu[eé] (pens[aá]s|opin[aá]s) (vos|t[uú])[^?]*\??\s*/gi,
    /¿?qu[eé] (pens[aá]s|opin[aá]s) al respecto[^?]*\??\s*/gi,
    /¿?qu[eé] es lo que m[aá]s te gusta[^?]*\??\s*/gi,
    /¿?qu[eé] te gusta de[^?]*\??\s*/gi,
    /¿?estamos (listos|preparados) para[^?]*\??\s*/gi,
    // FIX-U: nuevos patrones anti-eco y anti-regresión
    /en relaci[oó]n a tu pregunta[^.!?]*[.!]?\s*/gi,
    /respecto a tu (pregunta|consulta)[^.!?]*[.!]?\s*/gi,
    /para responder(te)? (tu|a tu) (pregunta|consulta)[^.!?]*[,.]?\s*/gi,
    /sobre lo que me (preguntas|pregunt[aá]s)[^.!?]*[,.]?\s*/gi,
    /lo que me (est[aá]s|estás) preguntando[^.!?]*[,.]?\s*/gi,
    /me (preguntas|pregunt[aá]s) (sobre|acerca de)[^.!?]*[,.]?\s*/gi,
    /buena observaci[oó]n[.!]?\s*/gi,
    /excelente observaci[oó]n[.!]?\s*/gi,
    /interesante (observaci[oó]n|punto)[.!]?\s*/gi,
    /buen punto[.!]?\s*/gi,
    /lo que (quieres|quer[eé]s) saber es[^.!?]*[,.]?\s*/gi,
    /si te (entend[ií]|entiendo) bien[^.!?]*[,.]?\s*/gi,
    /si entiendo (bien |correctamente )?tu pregunta[^.!?]*[,.]?\s*/gi,
    /ante cualquier (duda|consulta|pregunta)[^.!?]*[.!]?\s*/gi,
    /cualquier (duda|consulta|pregunta)[^.!?]*[.!]?\s*/gi,
    /si ten[eé]s (alguna )?duda[^.!?]*[.!]?\s*/gi,
    /si tienes (alguna )?duda[^.!?]*[.!]?\s*/gi,
    /es un placer[^.!?]*[.!]?\s*/gi,
    /un placer (ayudarte|asistirte|hablar)[^.!?]*[.!]?\s*/gi
  ];

  muletillas.forEach(function(re) { r = r.replace(re, ''); });
  r = r.replace(/  +/g, ' ').trim();

  // PASO 4: FIX-U — filtrado oración por oración con FRAGMENTOS_BOT_V83
  var lowerR = r.toLowerCase();
  var hayFragmento = FRAGMENTOS_BOT_V83.some(function(f) {
    return lowerR.indexOf(f.toLowerCase()) !== -1;
  });

  if (hayFragmento) {
    var todasOraciones = splitOraciones(r);
    var filtradas = todasOraciones.filter(function(oracion) {
      var lo = oracion.toLowerCase();
      var mala = FRAGMENTOS_BOT_V83.some(function(f) {
        return lo.indexOf(f.toLowerCase()) !== -1;
      });
      if (mala) Logger.log('sanitizar v83: eliminada: "' + oracion + '"');
      return !mala;
    });
    var candidato = filtradas.join(' ').trim();
    // FIX-U: umbral subido a 20 chars (era 15) — más conservador
    if (candidato.length > 20) {
      r = candidato;
    } else if (filtradas.length < todasOraciones.length && candidato.length > 0) {
      r = candidato;
    } else {
      r = '';
    }
  }

  // PASO 5: limpieza final
  r = r.replace(/[\u0000-\u001F\u007F-\u009F]/g, ' ');
  r = r.replace(/\s{2,}/g, ' ').trim();

  // PASO 6: FIX-U — fallback conservador: < 20 chars → '' (fuerza silencio)
  if (!r && texto && texto.trim().length > 50) {
    var oracionesOriginales = splitOraciones(texto.trim());
    var validas = oracionesOriginales.filter(function(o) {
      var lo = o.toLowerCase();
      if (/https?:\/\//.test(o)) return false;
      if (/^\s*\d+\./.test(o)) return false;
      return !FRAGMENTOS_BOT_V83.some(function(f) { return lo.indexOf(f.toLowerCase()) !== -1; });
    });
    var rescatadas = validas.map(function(o) {
      return o.replace(/[\u0000-\u001F\u007F-\u009F]/g, ' ')
               .replace(/https?:\/\/\S+/g, '')
               .replace(/\*+/g, '')
               .replace(/  +/g, ' ')
               .trim();
    }).filter(function(o) { return o.length > 5; });
    var rescatado = rescatadas.join(' ').trim();
    return rescatado.length >= 20 ? rescatado : '';
  }

  return r.length >= 20 ? r : (r.length > 0 ? r : '');
}

// ================================================================
// DETECCIONES
// ================================================================

function esSoloSaludo(mensaje) {
  var norm = mensaje.toLowerCase().replace(/[¡!¿?.,]/g, '').replace(/zo[eé]/gi, '').trim();
  var despedidas = ['adios','adiós','chau','bye','hasta luego','hasta pronto','nos vemos','hasta mañana'];
  for (var d = 0; d < despedidas.length; d++) {
    if (norm.indexOf(despedidas[d]) !== -1) return false;
  }
  var saludos = ['hola','buenas','buenos dias','buenos días','buenas tardes','buenas noches','hey','hi','saludos','ey'];
  var neutras  = ['ok','ya','dale','bien','ahí','ahi','listo','claro','si','sí'];
  var resto = norm;
  saludos.forEach(function(s) { resto = resto.replace(new RegExp('\\b' + s.replace(/\s+/g,'\\s+') + '\\b','gi'), ''); });
  neutras.forEach(function(n) { resto = resto.replace(new RegExp('\\b' + n + '\\b','gi'), ''); });
  return resto.replace(/\s+/g,'').trim().length < 8;
}

function detectarPresentacion(mensaje) {
  var patrones = [
    /(?:les habla|te habla|ac[aá] habla|aqu[ií] habla|habla)\s+([A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]{2,}(?:\s+[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]+)?)/,
    /([A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]{2,}(?:\s+[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]+)?)\s+al habla/
  ];
  for (var i = 0; i < patrones.length; i++) {
    var match = mensaje.match(patrones[i]);
    if (match && match[1]) {
      var nombre = match[1].trim();
      var nl = nombre.toLowerCase().split(' ')[0];
      if (nl === 'zoe' || nl === 'zoé' || nombre.length < 3) continue;
      return nombre;
    }
  }
  return null;
}

function esDespedida(mensaje) {
  var lower = mensaje.toLowerCase().trim();
  var palabras = ['adios','adiós','chau','nos vemos','hasta luego','hasta pronto','bye','hasta mañana',
    'hasta el lunes','hasta el martes','hasta el miércoles','hasta el jueves','hasta el viernes'];
  return palabras.some(function(p) {
    return new RegExp('(^|\\s)' + p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&') + '(\\s|$|[!?.,])','i').test(lower);
  });
}

function mencionaAZoe(mensaje) {
  return /(?<![a-záéíóúüñA-ZÁÉÍÓÚÜÑ])zo[eé](?![a-záéíóúüñA-ZÁÉÍÓÚÜÑ])/i.test(mensaje);
}

function necesitaBusquedaWeb(mensaje) {
  var m = mensaje.toLowerCase();
  var intencionFuerte = ['noticia','noticias','flash','titulares','qué pasó','que paso',
    'qué está pasando','novedades','actualidad','último momento','breaking','tendencia',
    'últimas','recientes','flash informativo','qué hay de nuevo','novedades de hoy'];
  var datoFactual = ['dólar','dolar','precio','cotización','bolsa','merval','inflación',
    'inflacion','pbi','gdp','estadística','dato','cifra','porcentaje','resultado'];
  var hoyConIntencion = /\b(hoy|esta semana|esta mañana|este mes)\b/.test(m) &&
    /\b(qué|que|cuál|cómo|como|dime|dame|contame|cuéntame|pasó|paso|hay|hubo)\b/.test(m);
  for (var i = 0; i < intencionFuerte.length; i++) { if (m.indexOf(intencionFuerte[i]) !== -1) return true; }
  for (var j = 0; j < datoFactual.length;    j++) { if (m.indexOf(datoFactual[j])    !== -1) return true; }
  return hoyConIntencion;
}

// ================================================================
// ACTIVACIÓN
// ================================================================

var _cache = CacheService.getScriptCache();
function activarZoe()    { _cache.put('zoe_activa', 'true', CONFIG.TIMEOUT_MINUTOS * 60); }
function desactivarZoe() { _cache.remove('zoe_activa'); }
function estaActiva()    { return _cache.get('zoe_activa') === 'true'; }

// ================================================================
// FIX-Q: OPENAI — presence_penalty + frequency_penalty anti-patinado
// ================================================================

function llamarOpenAI(mensajes, maxTokens, reintentos) {
  maxTokens  = maxTokens  || CONFIG.MAX_TOKENS_RESPUESTA;
  reintentos = (typeof reintentos === 'undefined') ? 1 : reintentos;
  try {
    var t0  = Date.now();
    var res = UrlFetchApp.fetch('https://api.openai.com/v1/chat/completions', {
      method:  'post',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + CONFIG.OPENAI_KEY },
      payload: JSON.stringify({
        model:       CONFIG.OPENAI_MODEL,
        messages:    mensajes,
        max_tokens:  maxTokens,
        temperature: 0.72,           // Levemente más alto que v82 (0.65) → más variedad léxica
        // FIX-Q: penalidades anti-patinado
        // presence_penalty  = 0.9 → penaliza FUERTEMENTE repetir tokens del CONTEXTO (incluye la pregunta del usuario)
        //                           → elimina el Efecto Espejo
        // frequency_penalty = 0.7 → penaliza tokens que ya aparecieron en la RESPUESTA en curso
        //                           → elimina la Fijación Léxica (no repite "Yo pienso" dos veces)
        presence_penalty:  0.9,
        frequency_penalty: 0.7
      }),
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    Logger.log('OpenAI: ' + ((Date.now() - t0) / 1000).toFixed(2) + 's | status: ' + code);
    if (code === 429 && reintentos > 0) {
      Logger.log('OpenAI 429 — reintentando en 2s...');
      Utilities.sleep(2000);
      return llamarOpenAI(mensajes, maxTokens, reintentos - 1);
    }
    var data = JSON.parse(res.getContentText());
    if (data.error) { Logger.log('OpenAI error: ' + data.error.message); return ''; }
    return data.choices[0].message.content.trim();
  } catch (e) { Logger.log('OpenAI ERROR: ' + e.message); return ''; }
}

// ================================================================
// BRAVE SEARCH
// ================================================================

function parsearEdad(age) {
  if (!age) return 999999;
  var m = age.match(/^(\d+)\s*(m|h|d|w|mo)$/i);
  if (!m) return 999999;
  var n = parseInt(m[1], 10);
  var u = m[2].toLowerCase();
  if (u === 'm')  return n;
  if (u === 'h')  return n * 60;
  if (u === 'd')  return n * 60 * 24;
  if (u === 'w')  return n * 60 * 24 * 7;
  if (u === 'mo') return n * 60 * 24 * 30;
  return 999999;
}

function extraerTemaBrave(mensaje) {
  try {
    return llamarOpenAI([{ role: 'user', content: 'Solo palabras clave para buscar noticias recientes. Máximo 5 palabras en minúsculas, sin puntuación.\nMensaje: "' + mensaje + '"' }], CONFIG.MAX_TOKENS_TEMA)
      .trim().toLowerCase().replace(/['".,!?¡¿:;]/g, '').replace(/\s+/g, ' ').trim();
  } catch (e) {
    return mensaje.toLowerCase().replace(/[¿?¡!'".,;:]/g, '').replace(/\b(el|la|los|las|un|una|de|del|que|para|con)\b/g, '').trim().slice(0, 50);
  }
}

function buscarBrave(query, numResultados, mensaje) {
  numResultados = numResultados || 5;
  if (!CONFIG.BRAVE_API_KEY) return null;
  try {
    var ahora = new Date();
    var q = query + ' ' + ahora.getDate() + ' ' + ahora.toLocaleString('es-AR', { month: 'long' }) + ' ' + ahora.getFullYear() + ' Argentina';
    var freshness = 'pd';
    if ((mensaje||'').toLowerCase().indexOf('semana') !== -1) freshness = 'pw';
    var url = CONFIG.BRAVE_URL + '?q=' + encodeURIComponent(q) + '&count=' + numResultados + '&freshness=' + freshness + '&search_lang=es&country=ar&text_decorations=false';
    var res = UrlFetchApp.fetch(url, { method: 'get', headers: { 'Accept': 'application/json', 'Accept-Encoding': 'gzip', 'X-Subscription-Token': CONFIG.BRAVE_API_KEY }, muteHttpExceptions: true });
    if (res.getResponseCode() !== 200) return null;
    var data = JSON.parse(res.getContentText());
    if (!data.web || !data.web.results || !data.web.results.length) return null;
    var ordenados = data.web.results.slice().sort(function(a, b) {
      return parsearEdad(a.age) - parsearEdad(b.age);
    });
    return ordenados.slice(0, numResultados).map(function(r, i) {
      var titulo = (r.title || '').replace(/[*_#`]/g, '').trim();
      var desc   = (r.description || '').replace(/[*_#`]/g, '').replace(/https?:\/\/\S+/g, '').trim();
      return '[' + (i+1) + '] ' + titulo + ' [' + (r.age||'sin fecha') + ']\n' + desc;
    }).join('\n\n');
  } catch (e) { Logger.log('Error Brave: ' + e.message); return null; }
}

// ================================================================
// MEMORIA E INVITADOS
// ================================================================

function leerMemoria() {
  if (!CONFIG.SHEET_ID) return '';
  var memoriaCache = _cache.get('memoria_zoe');
  if (memoriaCache) { Logger.log('Memoria desde cache'); return memoriaCache; }
  try {
    var ss = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Memoria');
    if (!sheet || sheet.getLastRow() < 2) return '';
    var lastRow  = sheet.getLastRow();
    var startRow = Math.max(2, lastRow - CONFIG.MEMORIA_MAX_REGISTROS + 1);
    var datos    = sheet.getRange(startRow, 1, lastRow - startRow + 1, 6).getValues();
    var bloque   = MARCADORES.MEMORIA_INICIO + '\nMEMORIA DE PROGRAMAS ANTERIORES\n\n';
    for (var i = datos.length - 1; i >= 0; i--) {
      var f = datos[i];
      var fecha = f[0] ? Utilities.formatDate(new Date(f[0]), 'America/Argentina/Buenos_Aires', 'dd/MM/yyyy') : 'sin fecha';
      bloque += fecha + ' | ' + (f[1]||'sin episodio') + '\n  Invitado: ' + (f[2]||'-') + '\n  Rol: ' + (f[3]||'-') + '\n  Temas: ' + (f[4]||'-') + '\n  Ideas: ' + (f[5]||'-') + '\n\n';
    }
    bloque += MARCADORES.MEMORIA_FIN;
    Logger.log('Memoria: ' + datos.length + ' registros');
    _cache.put('memoria_zoe', bloque, 300);
    return bloque;
  } catch (e) { Logger.log('Error leerMemoria: ' + e.message); return ''; }
}

function leerConversacionesHoy() {
  if (!CONFIG.SHEET_ID) return '';
  var cacheKey = 'conversaciones_hoy';
  var cached = _cache.get(cacheKey);
  if (cached) return cached;
  try {
    var ss   = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var hoja = ss.getSheetByName('ArchivoConversacionesZoe');
    if (!hoja || hoja.getLastRow() < 2) return '';
    var hoy  = new Date(); hoy.setHours(0,0,0,0);
    var datos = hoja.getRange(2, 1, hoja.getLastRow() - 1, 4).getValues();
    var deHoy = datos.filter(function(fila) {
      if (!fila[0]) return false;
      var fecha = new Date(fila[0]); fecha.setHours(0,0,0,0);
      return fecha.getTime() === hoy.getTime();
    });
    if (!deHoy.length) return '';
    var recientes = deHoy.slice(-CONFIG.MAX_CONV_HOY);
    var bloque = '##CONVERSACIONES_HOY##\nLO QUE PASÓ HOY (últimos ' + recientes.length + ' intercambios):\n\n';
    recientes.forEach(function(fila) {
      var pregunta  = (fila[2] || '').substring(0, CONFIG.MAX_CONV_CHARS_Q);
      var respuesta = (fila[3] || '').substring(0, CONFIG.MAX_CONV_CHARS_R);
      bloque += (fila[1]||'alguien') + ': ' + pregunta + '\n';
      bloque += 'ZOE: ' + respuesta + '\n\n';
    });
    bloque += '##FIN_CONVERSACIONES_HOY##';
    _cache.put(cacheKey, bloque, 60);
    Logger.log('Conversaciones hoy: ' + recientes.length + ' (de ' + deHoy.length + ' totales)');
    return bloque;
  } catch(e) { Logger.log('Error leerConversacionesHoy: ' + e.message); return ''; }
}

function leerInvitadosDeSheet() {
  if (!CONFIG.SHEET_ID) return null;
  // FIX-V84: cache propio de 5min para no golpear Sheets en cada request del webhook.
  // forzarActualizacion() llama limpiarCache() que elimina 'invitados_hoy',
  // garantizando que los nuevos invitados carguen inmediatamente al refrescar.
  var cacheKey = 'invitados_hoy';
  var cached = _cache.get(cacheKey);
  if (cached) { Logger.log('Invitados desde cache'); return cached === '__vacio__' ? null : cached; }
  try {
    var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Invitados');
    if (!sheet) { _cache.put(cacheKey, '__vacio__', 300); return null; }
    var data  = sheet.getDataRange().getValues();
    var hoy   = new Date(); hoy.setHours(0,0,0,0);
    var resultado = '', encontrados = 0;
    for (var i = 1; i < data.length; i++) {
      var fila = data[i];
      if (!fila[0]) continue;
      var ff = new Date(fila[0]); ff.setHours(0,0,0,0);
      if (ff.getTime() !== hoy.getTime()) continue;
      encontrados++;
      resultado += 'INVITADO ' + encontrados + ':\n  Nombre: ' + (fila[1]||'-') + '\n  Empresa: ' + (fila[2]||'-') + '\n  Rol: ' + (fila[3]||'-') + '\n  Logros: ' + (fila[4]||'-') + '\n  Contexto: ' + (fila[5]||'-') + '\n  Tensión: ' + (fila[6]||'¿Qué cambia si esto funciona?') + '\n\n';
    }
    if (!encontrados) { _cache.put(cacheKey, '__vacio__', 300); return null; }
    var bloque = MARCADORES.INVITADOS_INICIO + '\nINVITADOS DE HOY\n\n' +
      'PROTOCOLO:\n1. Contexto específico, no genérico.\n2. Primera pregunta desde la tensión. NUNCA "¿de qué quieres hablar?".\n3. Escucha activa, reformula con perspectiva.\n4. Preguntas que abren, nunca sí/no.\n5. Cierre con gancho.\n\n' +
      resultado + MARCADORES.INVITADOS_FIN;
    _cache.put(cacheKey, bloque, 300);
    Logger.log('Invitados hoy: ' + encontrados + ' cargados desde Sheet');
    return bloque;
  } catch (e) { Logger.log('Error leerInvitados: ' + e.message); return null; }
}

function guardarInvitado(nombre, rol, temas, frases, episodio) {
  if (!CONFIG.SHEET_ID) return;
  try {
    var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Memoria');
    if (!sheet) { sheet = ss.insertSheet('Memoria'); sheet.appendRow(['Fecha','Episodio','Nombre','Rol o Empresa','Temas tratados','Ideas clave']); sheet.setFrozenRows(1); }
    sheet.appendRow([new Date(), episodio||'sin episodio', nombre, rol, temas, frases]);
    _cache.remove('memoria_zoe');
    Logger.log('Guardado en memoria: ' + nombre);
  } catch (e) { Logger.log('Error guardarInvitado: ' + e.message); }
}

// ================================================================
// PROCESADOR PRINCIPAL
// ================================================================

function procesarMensaje(mensaje, speaker) {
  speaker = speaker || 'alguien';
  mensaje = (mensaje || '').trim();

  if (mensaje === '!!') { desactivarZoe(); return ''; }

  if (!mencionaAZoe(mensaje)) {
    Logger.log('Sin mención a Zoe — no responde.');
    return '';
  }

  activarZoe();

  var nombreDetectado = detectarPresentacion(mensaje);
  if (nombreDetectado) return nombreDetectado + '.';

  if (esSoloSaludo(mensaje)) return elegirSaludo();

  if (esDespedida(mensaje)) {
    var despedida = sanitizarRespuesta(llamarOpenAI([
      { role: 'system', content: 'Sos ZOE, conductora de televisión. Despedida cálida, UNA oración con punto final. Español neutro, sin voseo, sin frases de bot. No preguntes nada.' },
      { role: 'user',   content: mensaje }
    ], 40));
    return despedida || '';
  }

  var temporal   = obtenerContextoTemporal();
  var memoria    = leerMemoria();
  var convHoy    = leerConversacionesHoy();
  // FIX-V84: invitados ahora se inyectan también en el webhook en vivo,
  // no solo en el LiveAvatar. Cache propio de 5min para no golpear Sheets cada request.
  var invitadosHoy = leerInvitadosDeSheet();

  var contextSpeaker = '';
  var spLower = speaker.toLowerCase();
  if      (spLower.indexOf('melina')  !== -1) contextSpeaker = 'Quien habla es MELINA FLEIDERMAN, la conductora principal. Construye con ella.';
  else if (spLower.indexOf('rodrigo') !== -1) contextSpeaker = 'Quien habla es RODRIGO CONTRERAS, el productor.';
  else if (spLower.indexOf('joaco')   !== -1 || spLower.indexOf('joaquín') !== -1) contextSpeaker = 'Quien habla es JOACO RAMOS, periodista. Foco en GovTech.';
  else if (spLower.indexOf('inés')    !== -1 || spLower.indexOf('ines')    !== -1) contextSpeaker = 'Quien habla es INÉS REINEKE, columnista de innovación pública.';
  else if (speaker !== 'alguien' && speaker !== 'Usuario') {
    contextSpeaker = 'Invitado: "' + speaker + '". Abre con dato o afirmación sobre su área. NUNCA preguntes de qué quiere hablar.';
  }

  var system = BLOQUE_IDENTIDAD + '\n\n' + BLOQUE_RESTRICCIONES +
    '\n\nCONTEXTO ACTUAL EN TIEMPO REAL:\n' +
    'Hoy es ' + temporal.diaSemana + ', ' + temporal.fecha + '.\n' +
    // FIX-V84: instrucción reforzada — hora EXACTA disponible, úsala siempre
    'La hora exacta AHORA mismo en Buenos Aires es: ' + temporal.hora + ' (UTC-3).\n' +
    'REGLA DE ORO: si alguien pregunta la hora, respondés ÚNICAMENTE con la hora de arriba. ' +
    'No redondees, no estimes, no digas "aproximadamente". Decís exactamente "Son las ' + temporal.hora + '".\n';

  if (contextSpeaker) system += '\nINTERLOCUTOR: ' + contextSpeaker + '\n';
  if (memoria)        system += '\n' + memoria;
  if (convHoy)        system += '\n' + convHoy;

  // FIX-V84: invitados del día — bloque completo con instrucción de uso
  if (invitadosHoy) {
    system += '\n' + invitadosHoy;
    system +=
      '\n=== INSTRUCCIÓN INVITADOS ===\n' +
      'Cuando te pregunten "¿quién es el invitado de hoy?" o similar:\n' +
      '  1. Leé la fecha de hoy: ' + temporal.fecha + '.\n' +
      '  2. Respondé: "El invitado de hoy es [Nombre], [Rol] de [Empresa]."\n' +
      '  3. Agregá una oración con el dato más potente de su contexto o logros.\n' +
      '  4. Cerrá con la pregunta tensión que le harías (campo Tensión del bloque).\n' +
      'Cuando el invitado esté hablando EN VIVO (su nombre aparece como speaker):\n' +
      '  → No repitas su bio. Partí directo desde la tensión de su contexto.\n' +
      '  → Usá sus logros como palanca para profundizar, no como presentación.\n' +
      '  → Formulá preguntas que abran, no que cierren. Nunca sí/no.\n' +
      '=== FIN INSTRUCCIÓN INVITADOS ===\n';
  } else {
    system += '\nINVITADOS DE HOY: Sin invitados cargados para esta fecha.\n';
  }

  // FIX-S + FIX-R: recordatorio final con pools humanos explícitos
  system +=
    '\n=== RECORDATORIO CRÍTICO ANTES DE RESPONDER ===\n' +
    '1. Tu primera oración NO puede empezar con ninguna palabra de la pregunta que te acaban de hacer.\n' +
    '2. Usá UN conector del POOL CONECTORES para introducir tu opinión:\n' +
    '   "Mirá," / "La verdad es que" / "Honestamente," / "Me da la sensación de que" / "A ver, para mí" / "Lo cierto es que"\n' +
    '3. Usá UNA frase del POOL OPINIÓN para expresar tu punto de vista:\n' +
    '   "Yo estimo que" / "Yo considero que" / "Me parece que" / "Desde mi lugar veo que" / "Mi visión es que"\n' +
    '   "Yo creo que" / "Yo pienso que" / "Para mí" / "Yo opino que"\n' +
    '4. NUNCA termines con una pregunta. Cerrá con afirmación fuerte.\n' +
    '5. NUNCA incluyas URLs, links, hashtags ni código.\n' +
    '6. NUNCA digas frases de asistente: "ayudarte", "lo que necesites", "con gusto", "a tu disposición".\n';

  var busquedaExtra = '';
  if (necesitaBusquedaWeb(mensaje) && CONFIG.BRAVE_API_KEY) {
    var resultados = buscarBrave(extraerTemaBrave(mensaje), 5, mensaje);
    if (resultados) busquedaExtra = '\nRESULTADOS WEB:\n' + resultados + '\nUsa el más reciente. Noticia directa con opinión. Sin fuentes ni URLs.\n';
  }

  var respuesta = sanitizarRespuesta(llamarOpenAI([
    { role: 'system', content: system + busquedaExtra },
    { role: 'user',   content: mensaje }
  ]));

  if (respuesta && respuesta.trim().length > 0) {
    try {
      var ss2  = SpreadsheetApp.openById(CONFIG.SHEET_ID);
      var hoja = ss2.getSheetByName('ArchivoConversacionesZoe');
      if (hoja) hoja.appendRow([new Date(), speaker, mensaje, respuesta]);
      _cache.remove('conversaciones_hoy');
    } catch (e) { Logger.log('Error guardando: ' + e); }
  }

  return respuesta || '';
}

// ================================================================
// LIVEAVATAR
// ================================================================

function generarEditorialOpenAI(titulares, diaSemana) {
  if (!CONFIG.OPENAI_KEY || !titulares.length) return titulares.join('\n') || 'Sin noticias.';
  var sys = 'Sos ZOE, conductora IA agéntica de Malditos Optimistas.\n' +
    '1. 3-4 noticias de innovación, tecnología o emprendimiento en Latam.\n' +
    '2. Cada noticia en 1-2 oraciones completas. Sin fuentes. Sin URLs.\n' +
    '3. Después de cada noticia expresá tu opinión rotando entre:\n' +
    '   "Mirá, lo que esto implica es...", "La verdad es que...", "Honestamente...",\n' +
    '   "Me da la sensación de que...", "Desde mi lugar veo que...", "Mi visión es que...".\n' +
    '4. Cierra con una reflexión que conecte las noticias.\n' +
    '5. Español neutro. Sin voseo. Empieza directo sin saludar.\n' +
    '6. Máximo 400 palabras. Todas las oraciones completas con punto final.\n' +
    '7. NUNCA incluyas URLs, links ni hashtags.\n' +
    '8. NUNCA uses frases de asistente ni preguntes al lector.';
  try {
    return sanitizarRespuesta(llamarOpenAI([
      { role: 'system', content: sys },
      { role: 'user',   content: 'Titulares:\n' + titulares.join('\n') }
    ], CONFIG.MAX_TOKENS_EDITORIAL));
  } catch (e) { Logger.log('Error editorial: ' + e.message); return titulares.join('\n'); }
}

function obtenerTitularesRSS() {
  var cache    = CacheService.getScriptCache();
  var titulares = [];
  for (var cat in FEEDS_RSS) {
    try {
      var key  = 'rss_' + cat.replace(/\s+/g, '_');
      var text = cache.get(key);
      if (!text) {
        var res = UrlFetchApp.fetch(FEEDS_RSS[cat], { muteHttpExceptions: true, headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (res.getResponseCode() !== 200) continue;
        text = res.getContentText();
        if (text.length < 90000) cache.put(key, text, 3600);
      }
      var items = text.match(/<item>([\s\S]*?)<\/item>/g) || [];
      var count = 0;
      for (var i = 0; i < items.length && count < 4; i++) {
        var tm = items[i].match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/) || items[i].match(/<title>(.*?)<\/title>/);
        if (tm && tm[1].trim()) { titulares.push('[' + cat + '] ' + tm[1].replace(/<[^>]+>/g,'').trim()); count++; }
      }
    } catch (e) { Logger.log('Error RSS ' + cat + ': ' + e.message); }
  }
  return titulares;
}

function actualizarLiveAvatar() {
  try {
    if (!CONFIG.API_KEY || !CONFIG.CONTEXT_ID) { Logger.log('ERROR: Falta API_KEY o CONTEXT_ID'); return; }
    var temporal  = obtenerContextoTemporal();
    var titulares = obtenerTitularesRSS();
    var editorial = generarEditorialOpenAI(titulares, temporal.diaSemana);
    var memoria   = leerMemoria();
    var invitados = leerInvitadosDeSheet() ||
      MARCADORES.INVITADOS_INICIO + '\nINVITADOS DE HOY\nSin invitados cargados.\n' + MARCADORES.INVITADOS_FIN;

    var bloqueNoticias =
      MARCADORES.NOTICIAS_INICIO + '\n' +
      'Hoy: ' + temporal.fecha + ', Buenos Aires.\n' +
      'Día: ' + temporal.diaSemana.toUpperCase() + '\n' +
      'IMPORTANTE: La hora la calculás en tiempo real cuando te la pregunten. No uses una hora fija.\n\n' +
      'EDITORIAL DEL DÍA:\nCuando pidan noticias, usa este bloque. Sin fuentes ni URLs.\n\n' +
      editorial + '\n\n' + MARCADORES.NOTICIAS_FIN;

    var promptFinal =
      BLOQUE_IDENTIDAD + '\n\n' +
      BLOQUE_RESTRICCIONES + '\n\n' +
      (memoria ? memoria + '\n\n' : '') +
      bloqueNoticias + '\n\n' +
      invitados;

    Logger.log('Prompt: ' + promptFinal.length + ' chars — ZOE ' + CONFIG.VERSION);

    var payload = { name: 'ZOE', prompt: promptFinal, opening_text: '.' };
    if (CONFIG.VOICE_ID)        payload.voice_id    = CONFIG.VOICE_ID;
    if (CONFIG.AVATAR_ID)       payload.avatar_id   = CONFIG.AVATAR_ID;
    if (CONFIG.AVATAR_LANGUAGE) payload.language    = CONFIG.AVATAR_LANGUAGE;
    if (CONFIG.WEBHOOK_URL)     payload.webhook_url = CONFIG.WEBHOOK_URL;

    var res = UrlFetchApp.fetch(
      'https://api.liveavatar.com/v1/contexts/' + CONFIG.CONTEXT_ID,
      { method: 'PATCH', headers: { 'X-API-KEY': CONFIG.API_KEY, 'Content-Type': 'application/json' },
        payload: JSON.stringify(payload), muteHttpExceptions: true }
    );
    var code = res.getResponseCode();
    Logger.log(code === 200 ? 'LiveAvatar OK: ' + temporal.fecha : 'Error PATCH: ' + code + ' — ' + res.getContentText());
  } catch (e) { Logger.log('Error actualizarLiveAvatar: ' + e.message); }
}

// ================================================================
// CONTROL DE TURNO
// ================================================================

function esPreguntaCompleta(texto) {
  var t = texto.trim();
  if (/[.!?]$/.test(t)) return true;
  if (/^¿/.test(t) && !/\?$/.test(t)) return false;
  var palabras = t.split(/\s+/).filter(Boolean);
  if (palabras.length >= 6) return true;
  return false;
}

function _respuestaVacia() {
  return ContentService.createTextOutput(
    JSON.stringify({ ok: true, reply: null, speak: false })
  ).setMimeType(ContentService.MimeType.JSON);
}

// ================================================================
// WEBHOOK
// ================================================================

function doPost(e) {
  try {
    var body = {};
    if (e && e.postData && e.postData.contents) body = JSON.parse(e.postData.contents);
    var mensaje  = body.message || body.text || '';
    var speaker  = body.speaker || 'Usuario';
    var esFinal  = body.is_final === true || body.final === true;

    Logger.log('WEBHOOK — speaker: ' + speaker + ' | final: ' + esFinal + ' | msg: ' + mensaje);

    var mensajeTrimmed = (mensaje || '').trim();

    if (!mensajeTrimmed || mensajeTrimmed.length < 3) return _respuestaVacia();

    var soloLetras = mensajeTrimmed.replace(/[^a-zA-ZáéíóúüñÁÉÍÓÚÜÑ]/g, '');
    if (soloLetras.length < 2) {
      Logger.log('Ruido descartado: "' + mensajeTrimmed + '"');
      return _respuestaVacia();
    }

    if (!mencionaAZoe(mensajeTrimmed)) {
      Logger.log('Sin mención a Zoe — no responde.');
      return _respuestaVacia();
    }

    var cacheKey = 'turno_' + speaker.replace(/\s+/g, '_').toLowerCase();
    var ahora    = Date.now();

    if (!esFinal && !esPreguntaCompleta(mensajeTrimmed)) {
      _cache.put(cacheKey, JSON.stringify({ msg: mensajeTrimmed, ts: ahora }), 10);
      Utilities.sleep(DEBOUNCE_MS);
      var cached = _cache.get(cacheKey);
      if (!cached) {
        Logger.log('Debounce: cache vacío, descartando: "' + mensajeTrimmed + '"');
        return _respuestaVacia();
      }
      var cacheParsed = JSON.parse(cached);
      if (cacheParsed.ts !== ahora) {
        Logger.log('Debounce: superado por mensaje más reciente, descartando: "' + mensajeTrimmed + '"');
        return _respuestaVacia();
      }
      mensajeTrimmed = cacheParsed.msg;
      _cache.remove(cacheKey);
      Logger.log('Debounce: procesando tras espera: "' + mensajeTrimmed + '"');
    } else {
      _cache.remove(cacheKey);
      Logger.log('Pregunta completa — procesando directo: "' + mensajeTrimmed + '"');
    }

    var respuesta = procesarMensaje(mensajeTrimmed, speaker);

    if (!respuesta || respuesta.trim() === '') return _respuestaVacia();

    Logger.log('Respuesta: ' + respuesta);
    return ContentService.createTextOutput(
      JSON.stringify({ ok: true, reply: respuesta, speak: true })
    ).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    Logger.log('ERROR doPost: ' + err);
    return ContentService.createTextOutput(
      JSON.stringify({ ok: false, error: err.message, reply: null, speak: false })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}

// ================================================================
// TRIGGERS
// ================================================================

function configurarTriggers() {
  ScriptApp.getProjectTriggers().forEach(function(t) { ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(11).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(12).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(13).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(14).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(15).create();
  ScriptApp.newTrigger('mantenimientoSemanal').timeBased().onWeekDay(ScriptApp.WeekDay.SUNDAY).atHour(6).create();
  Logger.log('Triggers: ' + ScriptApp.getProjectTriggers().length);
}

// ================================================================
// PROPIEDADES
// ================================================================

function cargarPropiedades() {
  var props = PropertiesService.getScriptProperties();
  props.setProperties({
    'OPENAI_KEY':      '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',
    'BRAVE_API_KEY':   'BSABBxFDdPqV-TqDd5y5mp9vXbdiBWh',
    'API_KEY':         '26cc47aa-3766-11f1-8d28-066a7fa2e369',
    'CONTEXT_ID':      '24db1a18-7249-4009-89fe-319456b1ab37',
    'SHEET_ID':        '1gr3641Z-7FL-nStWbo0F_JfSQH_JiAfoAzr-TFbInrk',
    'VOICE_ID':        '30964c85-58f6-4379-9370-fdb90faae574',
    'AVATAR_ID':       '9fc5b8d5-0ded-48ec-861d-80d45138360e',
    'AVATAR_LANGUAGE': 'es',
    'WEBHOOK_URL':     'https://script.google.com/macros/s/AKfycbzUj0XIi3qfUetPRyACs8kWu6JBGMhTGduPEjjjo7hr4pmEpMSU-GoHxUNuoGeM2lfM/exec'
  });
  Logger.log('Propiedades cargadas OK');
}

function actualizarWebhook() {
  PropertiesService.getScriptProperties().setProperty('WEBHOOK_URL', 'https://script.google.com/macros/s/AKfycbzUj0XIi3qfUetPRyACs8kWu6JBGMhTGduPEjjjo7hr4pmEpMSU-GoHxUNuoGeM2lfM/exec');
  Logger.log('Webhook actualizado OK');
}

// ================================================================
// MANTENIMIENTO
// ================================================================

function limpiarCache() {
  var c = CacheService.getScriptCache();
  for (var cat in FEEDS_RSS) c.remove('rss_' + cat.replace(/\s+/g,'_'));
  c.remove('memoria_zoe');
  c.remove('conversaciones_hoy');
  // FIX-V84: limpiar cache de invitados para que forzarActualizacion() recargue
  // los nuevos invitados del dia desde la Sheet inmediatamente
  c.remove('invitados_hoy');
  Logger.log('Cache limpiado (memoria + conversaciones + invitados + RSS)');
}

function forzarActualizacion() { limpiarCache(); actualizarLiveAvatar(); }

function mantenimientoSemanal() {
  Logger.log('MANTENIMIENTO ' + CONFIG.VERSION);
  try {
    if (!CONFIG.SHEET_ID) return;
    var ss   = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var hoja = ss.getSheetByName('ArchivoConversacionesZoe');
    if (hoja) { var n = hoja.getLastRow(); if (n > 500) hoja.deleteRows(2, n - 300); }
    limpiarCache();
    actualizarLiveAvatar();
    var log = ss.getSheetByName('LogMantenimiento');
    if (log) log.appendRow([new Date(), 'Mantenimiento ' + CONFIG.VERSION, 'OK']);
  } catch (e) { Logger.log('Error mantenimiento: ' + e); }
}

// ================================================================
// HOJAS
// ================================================================

function verificarHojasExisten() {
  if (!CONFIG.SHEET_ID) { Logger.log('ERROR: Sin SHEET_ID'); return; }
  var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
  var hojas = {
    'ArchivoConversacionesZoe': ['Timestamp','Speaker','Mensaje','Respuesta'],
    'Memoria':          ['Fecha','Episodio','Nombre','Rol o Empresa','Temas tratados','Ideas clave'],
    'Invitados':        ['Fecha','Nombre','Empresa','Rol','Logros','Contexto','Tensión'],
    'LogMantenimiento': ['Timestamp','Acción','Status'],
    'LogErrores':       ['Timestamp','Función','Error']
  };
  for (var nombre in hojas) {
    var hoja = ss.getSheetByName(nombre);
    if (!hoja) {
      hoja = ss.insertSheet(nombre);
      hoja.appendRow(hojas[nombre]);
      hoja.setFrozenRows(1);
      Logger.log('Hoja creada: ' + nombre);
    } else {
      Logger.log('Hoja OK: ' + nombre);
    }
  }
}

function agregarInvitadoDelDia() {
  var FECHA    = '2026-05-10';
  var NOMBRE   = 'Juan Perez';
  var EMPRESA  = 'TechStartup LATAM';
  var ROL      = 'CEO y Fundador';
  var LOGROS   = 'Levantó 5 millones de dólares y escaló a 10 países en 2 años';
  var CONTEXTO = 'Pionero en IA aplicada a logística en Argentina';
  var TENSION  = '¿Cómo compites contra gigantes globales siendo una startup local?';
  if (!CONFIG.SHEET_ID) { Logger.log('ERROR: Sin SHEET_ID'); return; }
  try {
    var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Invitados');
    if (!sheet) {
      sheet = ss.insertSheet('Invitados');
      sheet.appendRow(['Fecha','Nombre','Empresa','Rol','Logros','Contexto','Tensión']);
      sheet.setFrozenRows(1);
    }
    sheet.appendRow([new Date(FECHA), NOMBRE, EMPRESA, ROL, LOGROS, CONTEXTO, TENSION]);
    Logger.log('Invitado agregado. Ejecutá forzarActualizacion() después.');
  } catch (e) { Logger.log('Error: ' + e.message); }
}

function cargarMemoriaEpisodios() {
  Logger.log('=== INICIANDO cargarMemoriaEpisodios ===');
  if (!CONFIG.SHEET_ID) { Logger.log('ERROR: Sin SHEET_ID'); return; }
  var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
  var sheet = ss.getSheetByName('Memoria');
  if (!sheet) {
    sheet = ss.insertSheet('Memoria');
    sheet.appendRow(['Fecha','Episodio','Nombre','Rol o Empresa','Temas tratados','Ideas clave']);
    sheet.setFrozenRows(1);
  }
  var episodios = [
    [new Date('2026-05-07'),'Martes Ciencia y Biotecnología','Iván Stigliano','Detección temprana enfermedades, IA en salud, futuro medicina','Iván Stigliano analizó innovaciones en detección temprana y tecnologías que transforman la medicina.'],
    [new Date('2026-05-06'),'Viernes Startups','Estudiantes Colegio Pestalozzi o Iván Gauna o Airglow Lab','Talento joven, IA y política, startup climate-tech','Tres estudiantes llegaron a la final de Jugend forscht en Europa. Iván Gauna: tecnopoder vs tecnohumanismo.'],
    [new Date('2026-05-05'),'Lunes Empresarios','Guibert Englebienne','Emprendimiento global, IA, tecnología y educación, Globant','Cofundador de Globant. Preside Endeavor Argentina.'],
    [new Date('2026-05-01'),'Jueves Sociedad y Cultura','LUMI-7 o Constanza Patiño o Hernán Casciari','Música IA, innovación en deporte, cultura y comunidad','LUMI-7: primera artista musical IA de Argentina.'],
    [new Date('2026-04-30'),'Miércoles Innovación Local','TUMO Buenos Aires o Inés Reineke','Educación tecnológica jóvenes, política pública primera infancia Uruguay','TUMO Buenos Aires: modelo educativo para jóvenes 12-18.'],
    [new Date('2026-04-28'),'Entrevista especial Melina','Hernán Casciari','Emprendimiento cultural, autogestión, comunidad, narrativa','Fundó revista Orsai sin publicidad. 3 películas producidas con comunidad.'],
    [new Date('2026-04-24'),'Jueves Sociedad y Cultura','Patricio Ovalle Wood o Enrique Avogadro o ZOE','Cultura como motor de desarrollo, ecosistemas creativos, IA en educación','ZOE presentada como primera profesora IA de Latinoamérica.'],
    [new Date('2026-04-23'),'Miércoles Innovación Local','BachIA Tucumán o Inés Reineke','IA para infraestructura urbana, gestión pública innovadora Chile','BachIA: IA desarrollada por jóvenes en Tucumán para detectar baches.'],
    [new Date('2026-04-22'),'Entrevista especial','Santiago Bilinkis','Inteligencia artificial, emprendimiento, tecnología, futuro','Cofundador de Officenet. Autor de libros sobre IA.']
  ];
  var cargados = 0;
  episodios.forEach(function(ep) { sheet.appendRow(ep); cargados++; });
  _cache.remove('memoria_zoe');
  Logger.log('Total episodios cargados: ' + cargados);
}

function configuracionInicial() {
  Logger.log('CONFIGURACIÓN INICIAL ZOE ' + CONFIG.VERSION);
  verificarHojasExisten();
  actualizarLiveAvatar();
  testSistemaCompleto();
}

function verificarConfiguracionCompleta() {
  var props = PropertiesService.getScriptProperties();
  Logger.log('=== ZOE ' + CONFIG.VERSION + ' ===');
  ['OPENAI_KEY','BRAVE_API_KEY','API_KEY','CONTEXT_ID','SHEET_ID','VOICE_ID','AVATAR_ID','AVATAR_LANGUAGE'].forEach(function(k) {
    Logger.log(k + ': ' + (props.getProperty(k) ? 'OK' : 'FALTA'));
  });
  ScriptApp.getProjectTriggers().forEach(function(t) { Logger.log('Trigger: ' + t.getHandlerFunction()); });
  forzarActualizacion();
}

function testRSS() {
  var titulares = obtenerTitularesRSS();
  Logger.log('Total titulares: ' + titulares.length);
  titulares.forEach(function(t) { Logger.log(t); });
}

// ================================================================
// TESTS COMPLETOS v83
// ================================================================

function testSistemaCompleto() {
  Logger.log('======= TEST ' + CONFIG.VERSION + ' =======');
  var tests = [];

  // Tests heredados v82
  tests.push({ n: 'mencionaAZoe — zona',   ok: !mencionaAZoe('zona de trabajo') });
  tests.push({ n: 'mencionaAZoe — zoo',    ok: !mencionaAZoe('zoológico') });
  tests.push({ n: 'mencionaAZoe — Zoe ok', ok:  mencionaAZoe('Zoe, qué opinas?') });
  tests.push({ n: 'mencionaAZoe — Zoé ok', ok:  mencionaAZoe('Zoé, cuéntanos') });

  var s1 = splitOraciones('La IA creció. Yo creo que es positivo.');
  tests.push({ n: 'split: 2 oraciones normales',    ok: s1.length === 2 });
  var s2 = splitOraciones('Esto es una oración');
  tests.push({ n: 'split: sin punto — una sola',    ok: s2.length === 1 });
  var s3 = splitOraciones('En EE.UU. la startup creció un 40%. Yo creo que es replicable.');
  tests.push({ n: 'split: EE.UU. no corta oración', ok: s3.length === 2 });

  var t1 = sanitizarRespuesta('Gran pregunta. La IA es clave. Estoy aquí para ayudarte.');
  tests.push({ n: 'sanitizar: gran pregunta eliminada',             ok: t1.toLowerCase().indexOf('gran pregunta') === -1 });
  tests.push({ n: 'sanitizar: estoy aquí para ayudarte eliminada', ok: t1.toLowerCase().indexOf('estoy aquí para ayudarte') === -1 });

  var t2 = sanitizarRespuesta('Hay tres razones:\n1. La primera.\n2. La segunda.\n3. La tercera.');
  tests.push({ n: 'sanitizar: lista numerada eliminada', ok: !/\b1\./.test(t2) && !/\b2\./.test(t2) });

  var t3 = sanitizarRespuesta('Puntos clave:\n- Innovación\n- Emprendimiento\n- IA');
  tests.push({ n: 'sanitizar: viñetas eliminadas', ok: t3.indexOf('- ') === -1 });

  var t4 = sanitizarRespuesta('El gobierno hoy anunció que el país va a crecer un cuatro por ciento.');
  tests.push({ n: 'sanitizar: noticia real no eliminada', ok: t4.length > 20 });

  var t5 = sanitizarRespuesta('Hay algo que no cuadra en estos números.');
  tests.push({ n: 'sanitizar: "hay algo que" real no eliminada', ok: t5.length > 20 });

  var t6 = sanitizarRespuesta('Podés leer en https://malditos.com. La innovación es clave.');
  tests.push({ n: 'sanitizar: URL eliminada', ok: t6.indexOf('https://') === -1 });

  var t7 = sanitizarRespuesta('Google &amp; Amazon lideran.');
  tests.push({ n: 'sanitizar: &amp; → y', ok: t7.indexOf('y Amazon') !== -1 });

  // Tests nuevos v83 — FIX-U
  var t8 = sanitizarRespuesta('Lo que me estás preguntando sobre la IA es relevante. La verdad es que los modelos actuales crecen a un ritmo brutal.');
  tests.push({ n: 'v83: efecto espejo eliminado (lo que me estás preguntando)', ok: t8.toLowerCase().indexOf('lo que me estás preguntando') === -1 });

  var t9 = sanitizarRespuesta('En relación a tu pregunta, el ecosistema startup en Latam creció un 30% en 2025. Yo estimo que el crecimiento va a continuar.');
  tests.push({ n: 'v83: eco de pregunta eliminado (en relación a tu pregunta)', ok: t9.toLowerCase().indexOf('en relación a tu pregunta') === -1 });

  var t10 = sanitizarRespuesta('Honestamente, el dato es contundente. Ante cualquier duda, estoy disponible.');
  tests.push({ n: 'v83: "ante cualquier duda" eliminada', ok: t10.toLowerCase().indexOf('ante cualquier duda') === -1 });

  var t11 = sanitizarRespuesta('Buena observación. Las startups de IA en Latam levantan cada vez más capital.');
  tests.push({ n: 'v83: "buena observación" eliminada', ok: t11.toLowerCase().indexOf('buena observación') === -1 });

  var t12 = sanitizarRespuesta('Si tenés alguna duda, consultá. Mirá, el ecosistema creció un 40%.');
  tests.push({ n: 'v83: "si tenés alguna duda" eliminada', ok: t12.toLowerCase().indexOf('si tenés alguna duda') === -1 });

  var t13 = sanitizarRespuesta('Lo cierto es que la IA en salud está transformando todo. Me parece que vamos a ver resultados concretos en dos años.');
  tests.push({ n: 'v83: conectores humanos NO eliminados (lo cierto, me parece)', ok: t13.toLowerCase().indexOf('lo cierto') !== -1 || t13.toLowerCase().indexOf('me parece') !== -1 });

  var t14 = sanitizarRespuesta('Es un placer responder esto. La innovación abierta en Latam creció. Mi visión es que el ritmo no para.');
  tests.push({ n: 'v83: "es un placer" eliminada', ok: t14.toLowerCase().indexOf('es un placer') === -1 });
  tests.push({ n: 'v83: contenido real conservado tras eliminar bot phrase', ok: t14.toLowerCase().indexOf('latam') !== -1 || t14.toLowerCase().indexOf('visión') !== -1 });

  // Tests FIX-Q: presence/frequency penalty — solo verificamos que llamarOpenAI no rompe
  // (no podemos testear el output de la API en un test unitario, pero verificamos config)
  tests.push({ n: 'v83: MAX_TOKENS_RESPUESTA >= 260', ok: CONFIG.MAX_TOKENS_RESPUESTA >= 260 });

  // Tests heredados de v82
  tests.push({ n: 'parsearEdad: 2h < 1d',      ok: parsearEdad('2h') < parsearEdad('1d') });
  tests.push({ n: 'parsearEdad: 1d < 1w',      ok: parsearEdad('1d') < parsearEdad('1w') });
  tests.push({ n: 'parsearEdad: sin fecha max', ok: parsearEdad(null) === 999999 });

  tests.push({ n: 'turno: con punto final',           ok:  esPreguntaCompleta('Zoe qué opinas de la IA.') });
  tests.push({ n: 'turno: con signo de pregunta',     ok:  esPreguntaCompleta('Zoe qué opinas?') });
  tests.push({ n: 'turno: 6 palabras sin cierre',     ok:  esPreguntaCompleta('Zoe contanos sobre los startups argentinos') });
  tests.push({ n: 'turno: incompleta pocas palabras', ok: !esPreguntaCompleta('Zoe,') });
  tests.push({ n: 'turno: pregunta abierta sin ¿',    ok: !esPreguntaCompleta('¿Zoe qué') });

  var temporal = obtenerContextoTemporal();
  tests.push({ n: 'hora en tiempo real: tiene valor',   ok: temporal.hora && temporal.hora.length > 0 });
  tests.push({ n: 'hora en tiempo real: formato HH:MM', ok: /^\d{1,2}:\d{2}$/.test(temporal.hora) });

  var rPres   = procesarMensaje('Zoe, les habla Ramiro', 'Ramiro');
  var rSaludo = procesarMensaje('Hola Zoe', 'Melina');
  var rSinZoe = procesarMensaje('Contame algo', 'Melina');
  tests.push({ n: 'procesarMensaje: presentación', ok: rPres === 'Ramiro.' });
  tests.push({ n: 'procesarMensaje: saludo',       ok: rSaludo.length > 0 && rSaludo.length < 60 });
  tests.push({ n: 'procesarMensaje: sin Zoe',      ok: rSinZoe === '' });

  var score = 0;
  tests.forEach(function(t) {
    Logger.log((t.ok ? 'OK  ' : 'FAIL') + ' — ' + t.n);
    if (t.ok) score++;
  });
  // Tests nuevos v84
  // Hora
  var temporal84 = obtenerContextoTemporal();
  tests.push({ n: 'v84: hora disponible en contexto temporal', ok: temporal84.hora && /^\d{1,2}:\d{2}$/.test(temporal84.hora) });

  // limpiarCache incluye invitados_hoy
  var c84 = CacheService.getScriptCache();
  c84.put('invitados_hoy', 'test_value', 60);
  limpiarCache();
  tests.push({ n: 'v84: limpiarCache elimina invitados_hoy', ok: c84.get('invitados_hoy') === null });

  // Verificar que procesarMensaje llama leerInvitadosDeSheet (indirecto: no rompe)
  var rInvitado = procesarMensaje('Zoe, quién es el invitado de hoy?', 'Melina');
  // Si no hay invitados en Sheet, devuelve algo coherente (no rompe)
  tests.push({ n: 'v84: pregunta invitado no rompe el sistema', ok: typeof rInvitado === 'string' });

  Logger.log('SCORE: ' + score + '/' + tests.length + ' — ZOE ' + CONFIG.VERSION);
}
