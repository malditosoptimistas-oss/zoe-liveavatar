/**
 * ================================================================
 * ZOE — SETUP LIVEAVATAR CUSTOM LLM
 * ================================================================
 * PEGÁ ESTE BLOQUE AL FINAL DE TU CÓDIGO EXISTENTE (zoe_v87.js)
 *
 * QUÉ HACE:
 * Conecta LiveAvatar directamente con el webhook de GAS como LLM.
 * Así el avatar espera la respuesta de ZOE antes de hablar,
 * eliminando el problema de dos respuestas compitiendo.
 *
 * PASOS:
 * 1. Pegá este bloque al final del código
 * 2. Ejecutá configurarLLMPersonalizado() UNA SOLA VEZ
 * 3. Listo — el avatar ya usa ZOE como su LLM
 * ================================================================
 */

// ================================================================
// CONFIGURACIÓN LLM PERSONALIZADO PARA LIVEAVATAR
// ================================================================

var LA_BASE_URL = 'https://api.liveavatar.com';

/**
 * PASO 1 de 3: Registrar la OpenAI key en LiveAvatar
 * LiveAvatar la guarda cifrada con Amazon KMS.
 * Devuelve un secret_id que usamos en el paso 2.
 */
function registrarSecretEnLiveAvatar() {
  var openaiKey = PropertiesService.getScriptProperties().getProperty('OPENAI_KEY');
  var apiKey    = PropertiesService.getScriptProperties().getProperty('API_KEY');

  if (!openaiKey || !apiKey) {
    Logger.log('ERROR: Falta OPENAI_KEY o API_KEY en ScriptProperties');
    return null;
  }

  var res = UrlFetchApp.fetch(LA_BASE_URL + '/v1/secrets', {
    method: 'post',
    headers: {
      'X-API-KEY':    apiKey,
      'Content-Type': 'application/json'
    },
    payload: JSON.stringify({
      secret_type:  'OPENAI_API_KEY',
      secret_value: openaiKey,
      secret_name:  'ZOE OpenAI Key'
    }),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Registrar secret: HTTP ' + code);
  Logger.log(JSON.stringify(data));

  if (code === 200 && data.data && data.data.id) {
    var secretId = data.data.id;
    Logger.log('SECRET ID: ' + secretId);
    // Guardarlo para no tener que registrarlo de nuevo
    PropertiesService.getScriptProperties().setProperty('LA_SECRET_ID', secretId);
    return secretId;
  }

  Logger.log('ERROR registrando secret: ' + JSON.stringify(data));
  return null;
}

/**
 * PASO 2 de 3: Crear configuración LLM que apunta al webhook de GAS
 * LiveAvatar llama a este endpoint como si fuera OpenAI.
 * GAS responde con la respuesta de ZOE.
 * Devuelve un llm_configuration_id que usamos en el paso 3.
 */
function crearConfiguracionLLM(secretId) {
  var apiKey      = PropertiesService.getScriptProperties().getProperty('API_KEY');
  var webhookUrl  = PropertiesService.getScriptProperties().getProperty('WEBHOOK_URL');

  if (!secretId) {
    secretId = PropertiesService.getScriptProperties().getProperty('LA_SECRET_ID');
  }

  if (!apiKey || !webhookUrl || !secretId) {
    Logger.log('ERROR: Falta API_KEY, WEBHOOK_URL o LA_SECRET_ID');
    return null;
  }

  // El base_url debe ser la raíz del endpoint compatible con OpenAI
  // LiveAvatar le agrega /chat/completions automáticamente
  // GAS necesita manejar ese path — usamos el webhook URL base
  var baseUrl = webhookUrl.replace('/exec', '');

  var res = UrlFetchApp.fetch(LA_BASE_URL + '/v1/llm-configurations', {
    method: 'post',
    headers: {
      'X-API-KEY':    apiKey,
      'Content-Type': 'application/json'
    },
    payload: JSON.stringify({
      display_name: 'ZOE v87 GAS',
      model_name:   'gpt-4o-mini',
      secret_id:    secretId,
      base_url:     webhookUrl  // LiveAvatar llama directamente al webhook
    }),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Crear LLM config: HTTP ' + code);
  Logger.log(JSON.stringify(data));

  if (code === 200 && data.data && data.data.id) {
    var llmConfigId = data.data.id;
    Logger.log('LLM CONFIG ID: ' + llmConfigId);
    PropertiesService.getScriptProperties().setProperty('LA_LLM_CONFIG_ID', llmConfigId);
    return llmConfigId;
  }

  Logger.log('ERROR creando LLM config: ' + JSON.stringify(data));
  return null;
}

/**
 * PASO 3 de 3: Actualizar el contexto de ZOE en LiveAvatar
 * Le dice al avatar que use el LLM personalizado (GAS) en vez del de LiveAvatar.
 * También actualiza el prompt con la identidad de ZOE.
 */
function actualizarContextoConLLM(llmConfigId) {
  var apiKey    = PropertiesService.getScriptProperties().getProperty('API_KEY');
  var contextId = PropertiesService.getScriptProperties().getProperty('CONTEXT_ID');

  if (!llmConfigId) {
    llmConfigId = PropertiesService.getScriptProperties().getProperty('LA_LLM_CONFIG_ID');
  }

  if (!apiKey || !contextId || !llmConfigId) {
    Logger.log('ERROR: Falta API_KEY, CONTEXT_ID o LA_LLM_CONFIG_ID');
    return false;
  }

  // Prompt corto — el prompt completo lo maneja GAS dinámicamente
  var promptBase =
    'Sos ZOE, co-conductora IA de Malditos Optimistas. ' +
    'Hablás en español latino neutro, directo y con opinión propia. ' +
    'Respondés solo cuando te interpelan directamente. ' +
    'Máximo 3 oraciones por respuesta. Sin listas, sin URLs, sin frases de bot.';

  var res = UrlFetchApp.fetch(LA_BASE_URL + '/v1/contexts/' + contextId, {
    method: 'PATCH',
    headers: {
      'X-API-KEY':    apiKey,
      'Content-Type': 'application/json'
    },
    payload: JSON.stringify({
      name:         'ZOE v87',
      prompt:       promptBase,
      opening_text: '.',
      llm_configuration_id: llmConfigId
    }),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Actualizar contexto: HTTP ' + code);

  if (code === 200) {
    Logger.log('CONTEXTO ACTUALIZADO — ZOE ahora usa el LLM personalizado (GAS)');
    return true;
  }

  Logger.log('ERROR actualizando contexto: ' + JSON.stringify(data));
  return false;
}

/**
 * FUNCIÓN PRINCIPAL — ejecutá esta UNA SOLA VEZ
 * Hace los 3 pasos en secuencia.
 * Si algo falla, te dice exactamente qué fue.
 */
function configurarLLMPersonalizado() {
  Logger.log('=== CONFIGURANDO LLM PERSONALIZADO PARA LIVEAVATAR ===');
  Logger.log('Paso 1/3: Registrando OpenAI key en LiveAvatar...');

  var secretId = registrarSecretEnLiveAvatar();
  if (!secretId) {
    Logger.log('FALLO en Paso 1. Revisá los logs.');
    return;
  }
  Logger.log('Paso 1 OK — secret_id: ' + secretId);

  Logger.log('Paso 2/3: Creando configuración LLM...');
  var llmConfigId = crearConfiguracionLLM(secretId);
  if (!llmConfigId) {
    Logger.log('FALLO en Paso 2. Revisá los logs.');
    return;
  }
  Logger.log('Paso 2 OK — llm_configuration_id: ' + llmConfigId);

  Logger.log('Paso 3/3: Actualizando contexto de ZOE...');
  var ok = actualizarContextoConLLM(llmConfigId);
  if (!ok) {
    Logger.log('FALLO en Paso 3. Revisá los logs.');
    return;
  }

  Logger.log('');
  Logger.log('=== CONFIGURACIÓN COMPLETA ===');
  Logger.log('ZOE ahora usa GAS como su LLM en LiveAvatar.');
  Logger.log('El avatar esperará la respuesta de ZOE antes de hablar.');
  Logger.log('El problema de trabado debería estar resuelto.');
}

/**
 * Si querés verificar qué IDs quedaron guardados
 */
function verificarConfiguracionLLM() {
  var props = PropertiesService.getScriptProperties();
  Logger.log('LA_SECRET_ID:     ' + (props.getProperty('LA_SECRET_ID')     || 'NO GUARDADO'));
  Logger.log('LA_LLM_CONFIG_ID: ' + (props.getProperty('LA_LLM_CONFIG_ID') || 'NO GUARDADO'));
  Logger.log('CONTEXT_ID:       ' + (props.getProperty('CONTEXT_ID')       || 'NO GUARDADO'));
  Logger.log('WEBHOOK_URL:      ' + (props.getProperty('WEBHOOK_URL')       || 'NO GUARDADO'));
}
