/**
 * SISTEMA ZOE v88
 * v88: doPost unificado — formato OpenAI para LiveAvatar + webhook normal
 */

const CONFIG = {
  OPENAI_KEY:      PropertiesService.getScriptProperties().getProperty('OPENAI_KEY'),
  OPENAI_MODEL:    'gpt-4o-mini',
  BRAVE_API_KEY:   PropertiesService.getScriptProperties().getProperty('BRAVE_API_KEY'),
  BRAVE_URL:       'https://api.search.brave.com/res/v1/web/search',
  API_KEY:         PropertiesService.getScriptProperties().getProperty('API_KEY'),
  CONTEXT_ID:      PropertiesService.getScriptProperties().getProperty('CONTEXT_ID'),
  SHEET_ID:        PropertiesService.getScriptProperties().getProperty('SHEET_ID'),
  VOICE_ID:        PropertiesService.getScriptProperties().getProperty('VOICE_ID'),
  AVATAR_ID:       PropertiesService.getScriptProperties().getProperty('AVATAR_ID'),
  AVATAR_LANGUAGE: PropertiesService.getScriptProperties().getProperty('AVATAR_LANGUAGE') || 'es',
  WEBHOOK_URL:     PropertiesService.getScriptProperties().getProperty('WEBHOOK_URL'),
  TIMEOUT_MINUTOS:       20,
  // Tokens base para respuestas — conductora de TV, no un bot simple
  MAX_TOKENS_RESPUESTA:  500,
  MAX_TOKENS_EDITORIAL:  800,
  MAX_TOKENS_TEMA:       20,
  MEMORIA_MAX_REGISTROS: 5,   // reducido para aliviar tokens de contexto
  MAX_CONV_HOY:          3,   // FIX-Z2: reducido de 8 — menos eco
  MAX_CONV_CHARS_Q:      50,   // FIX-Z2: reducido de 120 — menos eco
  MAX_CONV_CHARS_R:      80,   // FIX-Z2: reducido de 180 — menos eco
  VERSION: 'v88'
};

var DEBOUNCE_MS = 2500;

const MARCADORES = {
  NOTICIAS_INICIO:  '##NOTICIAS_INICIO##',
  NOTICIAS_FIN:     '##NOTICIAS_FIN##',
  INVITADOS_INICIO: '##INVITADOS_INICIO##',
  INVITADOS_FIN:    '##INVITADOS_FIN##',
  MEMORIA_INICIO:   '##MEMORIA_INICIO##',
  MEMORIA_FIN:      '##MEMORIA_FIN##'
};

const FEEDS_RSS = {
  'EMPRENDIMIENTO Y STARTUPS LATAM':
    'https://news.google.com/rss/search?q=emprendimiento+startups+venture+capital+latinoamerica+2026&hl=es-419&gl=US&ceid=US:es-419',
  'TECNOLOGÍA E INNOVACIÓN LATAM':
    'https://news.google.com/rss/search?q=tecnologia+innovacion+ecosistema+digital+latinoamerica+2026&hl=es-419&gl=US&ceid=US:es-419',
  'INTELIGENCIA ARTIFICIAL':
    'https://news.google.com/rss/search?q=inteligencia+artificial+IA+avances+modelos+impacto+2026&hl=es-419&gl=US&ceid=US:es-419'
};

var SALUDOS_ZOE = [
  '¡Feliz de estar con ustedes de nuevo!',
  'Buenas, qué gusto arrancar otro día juntos.',
  'Hola a todos, acá estamos.',
  'Un gusto estar de vuelta con el equipo.',
  'Buenas tardes, lista para arrancar.',
  '¡Hola! Otro día de Malditos Optimistas.',
  'Acá estamos, bienvenidos.',
  'Qué bueno volver a coincidir.',
  'Hola, listos para lo que viene.',
  'Un placer estar acá de nuevo con ustedes.'
];

function elegirSaludo() {
  return SALUDOS_ZOE[new Date().getSeconds() % SALUDOS_ZOE.length];
}

// ================================================================
// BLOQUE IDENTIDAD
// ================================================================

var BLOQUE_IDENTIDAD = [
  '##IDENTIDAD_ZOE##',
  '',
  'Soy ZOE. Co-conductora IA de Malditos Optimistas.',
  'Hablo en español latino neutro. Directo, cálido, con opinión propia.',
  'Nunca soy neutral. Expreso mi punto de vista.',
  '',
  'MI HISTORIA',
  'Fui creada por Chris Meniw. Primera profesora IA y primera conductora IA agéntica de Latinoamérica.',
  'Di clases en la Escuela San José de Villa Cañás, Argentina. Fue histórico.',
  '',
  'MALDITOS OPTIMISTAS',
  'Primer noticiero de emprendimiento e innovación de Latam. DNews y DGO. Lunes a viernes.',
  'Lema: Las ideas no piden permiso.',
  '',
  'EL EQUIPO',
  'Melina Fleiderman — conductora principal. Rodrigo Contreras — productor.',
  'Joaco Ramos — periodista GovTech. Inés Reineke — innovación pública.',
  '',
  '##FIN_IDENTIDAD_ZOE##'
].join('\n');

// ================================================================
// FIX-R: BLOQUE RESTRICCIONES — REGLAS IMPERATIVAS DE ALTA PRIORIDAD
// Reemplaza instrucciones narrativas por prohibiciones absolutas.
// ================================================================

var BLOQUE_RESTRICCIONES = [
  '##REGLAS_ZOE##',
  '',
  'QUIÉN SOS: Conductora de televisión. Opinión propia. Voz directa. Nunca neutral.',
  'NO sos un bot, no sos un asistente, no sos Alexa.',
  '',
  'CÓMO HABLÁS — OBLIGATORIO:',
  'Cada respuesta: máximo 3 oraciones. Completas. Con punto final.',
  'Oración 1: dato concreto o afirmación directa.',
  'Oración 2: tu opinión. ROTÁ entre estas frases — PROHIBIDO repetir la misma dos veces seguidas:',
  '  → "Mirá," / "La verdad es que" / "Honestamente," / "Lo cierto es que" / "A ver,"',
  '  → + "yo estimo que" / "yo considero que" / "me parece que" / "desde mi lugar" / "mi visión es que" / "yo creo que" / "para mí"',
  'Oración 3: cierre fuerte. Nunca una pregunta.',
  '',
  'PROHIBIDO SIEMPRE:',
  '— Repetir palabras de la pregunta al empezar',
  '— Arrancar SIEMPRE con la misma palabra. ROTÁ el inicio de cada respuesta.',
  '— "con gusto" / "por supuesto" / "claro que sí" / "estoy aquí para ayudarte"',
  '— "gran pregunta" / "excelente" / "como IA" / "como modelo"',
  '— Terminar con pregunta al usuario',
  '— URLs, hashtags, listas con viñetas o números',
  '',
  'SILENCIO: Si hablan dos personas entre ellas y nadie te pregunta → no intervenís.',
  'Solo respondés cuando alguien te interpela directamente por nombre.',
  '',
  '##FIN_REGLAS_ZOE##'
].join('\n');

// ================================================================
// FIX-X: BLOQUE ASESOR — solo se inyecta cuando la pregunta lo activa
// No contamina el system prompt de respuestas normales de conductora.
// ================================================================

var BLOQUE_ASESOR = [
  '##MODO_ASESOR_EDITORIAL##',
  '',
  'Te están pidiendo tu mirada como co-conductora y observadora del programa.',
  'Podés hablar con franqueza sobre Malditos Optimistas.',
  '',
  'LO QUE SÉ DEL PROGRAMA:',
  'Formato: noticiero diario de emprendimiento e innovación en Latam. DNews y DGO.',
  'Emisión: lunes a viernes. Conductoras: Melina Fleiderman (principal) + ZOE (IA).',
  'Equipo: Rodrigo Contreras (productor), Joaco Ramos (GovTech), Inés Reineke (innovación pública).',
  'Segmentos recurrentes: entrevistas con founders, análisis de ecosistemas, GovTech, startups de impacto.',
  'Audiencia: emprendedores, inversores, innovadores y policy makers de Latam.',
  '',
  'CÓMO DEBO RESPONDER EN MODO ASESOR:',
  '1. Soy parte del programa, no un consultor externo. Hablo desde adentro.',
  '2. Doy UNA o DOS sugerencias concretas, no una lista genérica.',
  '3. Las anclo en algo que ya pasó en el programa o en una tendencia real del ecosistema.',
  '4. Puedo señalar lo que falta, lo que sobra o lo que podría potenciarse.',
  '5. Cierro con una postura firme, no con una pregunta.',
  '6. NUNCA soy condescendiente ni elogio vacío. Si algo puede mejorar, lo digo.',
  '',
  'ÁREAS QUE PUEDO OPINAR:',
  '— Formato y ritmo del programa (duración, dinamismo, cortes)',
  '— Perfiles de invitados (diversidad, geografía, sector)',
  '— Temas subrepresentados en el ecosistema Latam',
  '— Mi propio rol como ZOE (cómo aporto más valor en vivo)',
  '— Cobertura de ecosistemas emergentes (ej: Paraguay, Bolivia, Centroamérica)',
  '— Balance entre noticias duras y historias humanas',
  '— Oportunidades de formato (shorts, newsletters, comunidad)',
  '',
  '##FIN_MODO_ASESOR_EDITORIAL##'
].join('\n');

// FIX-X: detecta si la pregunta es una consulta editorial sobre el programa
function esConsultaEditorial(mensaje) {
  var m = mensaje.toLowerCase();
  var patrones = [
    // Pedidos directos de mejora
    /qu[eé] (mejorar[ií]as|cambi[ao]r[ií]as|agregar[ií]as|quitarías|sugerirías)/,
    /c[oó]mo (mejorar|potenciar|optimizar|crecer|hacer mejor)/,
    /qu[eé] le falta/,
    /qu[eé] (le sobra|est[aá] de m[aá]s)/,
    /qu[eé] (harías|cambiarías|propondrías)/,
    // Consultas sobre el programa
    /consejo(s)? (para|sobre|del) (programa|malditos)/,
    /sugerencia(s)? (para|sobre|del) (programa|malditos)/,
    /tu opini[oó]n (sobre|del|acerca) (programa|malditos|formato|contenido)/,
    /c[oó]mo ves (el programa|malditos|el formato)/,
    /qu[eé] (pensás|opinas|crees) (del|sobre el) (programa|formato|contenido)/,
    // Temáticas editoriales
    /qu[eé] (temas|invitados|segmentos|secciones) (faltan|agregar|incluir)/,
    /qu[eé] (invitados|perfiles) (deberíamos|habría que|convendría)/,
    /c[oó]mo (pod[eé]s|puedo|podemos) aportar m[aá]s/,
    /tu rol (en el programa|como conductora|como zoe)/,
    /c[oó]mo (mejorar|potenciar) (tu rol|lo que hac[eé]s)/
  ];
  // También keywords sueltas de contexto editorial
  var keywords = [
    'mejorar el programa', 'mejorar malditos', 'crecer el programa',
    'nuevo segmento', 'nueva sección', 'formato del programa',
    'audiencia del programa', 'rating', 'engagement',
    'qué temas cubrir', 'qué invitados traer', 'diversidad de invitados',
    'ecosistema subrepresentado', 'cobertura de latam'
  ];
  for (var i = 0; i < patrones.length; i++) {
    if (patrones[i].test(m)) return true;
  }
  for (var j = 0; j < keywords.length; j++) {
    if (m.indexOf(keywords[j]) !== -1) return true;
  }
  return false;
}

// ================================================================
// CONTEXTO TEMPORAL — FIX-P heredado de v82
// ================================================================

function obtenerContextoTemporal() {
  var ahora = new Date();
  var tz = 'America/Argentina/Buenos_Aires';
  var op = { timeZone: tz };
  return {
    fecha:     ahora.toLocaleDateString('es-AR', Object.assign({}, op, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })),
    hora:      Utilities.formatDate(ahora, tz, 'HH:mm'),
    diaSemana: ahora.toLocaleDateString('es-AR', Object.assign({}, op, { weekday: 'long' })),
    anio:      ahora.getFullYear()
  };
}

// ================================================================
// FIX-K heredado: LIMPIAR LISTAS Y VIÑETAS
// ================================================================

function limpiarListasYVinetas(texto) {
  return texto
    .split('\n')
    .map(function(linea) {
      linea = linea.replace(/^\s*\d+\.\s+/, '');
      linea = linea.replace(/^\s*[-*•]\s+/, '');
      return linea;
    })
    .join(' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

// ================================================================
// SPLIT ORACIONES
// ================================================================

function splitOraciones(s) {
  var abrevs = /\b(EE\.UU|Dr|Dra|Sr|Sra|Ing|Lic|etc|vs|núm|pág|art|cap|vol|fig|Ud|Uds|aprox|dpto|esq|tel|cel|av|bvd|km|cm|mm|kg|mg|ml|USD|EUR|ARS|BRL|IA|AA|BB|CC|S\.A|S\.R\.L)\./gi;
  var marcado = s.replace(abrevs, function(m) { return m.replace(/\./g, '\u0001'); });
  var resultado = [], actual = '';
  for (var i = 0; i < marcado.length; i++) {
    actual += marcado[i];
    var esPuntuacion = (marcado[i] === '.' || marcado[i] === '!' || marcado[i] === '?');
    if (esPuntuacion) {
      var siguiente = i + 1 < marcado.length ? marcado[i + 1] : ' ';
      var esFinOracion = (siguiente === ' ' || siguiente === '\n' || siguiente === '"' ||
                          siguiente === ')' || i + 1 >= marcado.length);
      if (esFinOracion) {
        var limpia = actual.trim().replace(/\u0001/g, '.');
        if (limpia.length > 0) resultado.push(limpia);
        actual = '';
      }
    }
  }
  if (actual.trim()) resultado.push(actual.trim().replace(/\u0001/g, '.'));
  return resultado;
}

// ================================================================
// FIX-U: SANITIZAR RESPUESTA v83
// — limpiarListasYVinetas va PRIMERO (FIX-O heredado)
// — FRAGMENTOS_BOT_V83 expandido con 40+ patrones nuevos
// — Análisis línea por línea con scoring de "bot-ness"
// — Fallback conservador: < 20 chars → ''
// ================================================================

// Todos los patrones que rompen la identidad de conductora
var FRAGMENTOS_BOT_V83 = [
  // Patrones de servicio/asistente
  'estoy aquí para ayudarte', 'aquí para ayudarte', 'aquí estoy para ayudarte',
  'para eso estoy', 'estoy para servirte', 'a tu disposición',
  'puedo ayudarte con eso', 'en qué más puedo ayudarte',
  'no dudes en preguntar', 'quedo a tu disposición',
  'fue un placer ayudarte', 'fue un placer asistirte',
  'lo que necesites', 'en lo que necesites', 'para lo que necesites',
  'para lo que me necesites', 'en lo que te pueda ayudar',
  'si necesitas algo más', 'si tenés alguna duda',
  'si tienes alguna duda', 'cualquier consulta',
  'ante cualquier duda', 'ante cualquier consulta',
  'con mucho gusto', 'con gusto', 'es un placer',
  'un placer ayudarte', 'un placer asistirte',
  // Patrones de validación falsa
  'gran pregunta', 'excelente pregunta', 'buena pregunta',
  'qué buena pregunta', 'muy buena pregunta', 'interesante pregunta',
  'me alegra que preguntes', 'me alegra que lo preguntes',
  'gracias por la pregunta', 'gracias por preguntar',
  // Patrones de identidad IA
  'como modelo de lenguaje', 'como inteligencia artificial',
  'como ia', 'soy un modelo', 'soy una ia', 'mi entrenamiento',
  'mis datos de entrenamiento', 'no tengo acceso',
  // Patrones de apertura del programa
  'bienvenido al programa', 'bienvenida al programa',
  'bienvenidos al programa', 'hoy tenemos un programa',
  'gracias por acompañarnos', 'gracias por seguirnos',
  'qué bueno tenerte', 'qué gusto tenerte',
  'me alegra saber', 'qué gusto escucharlo',
  // Patrones de pregunta al usuario (PROHIBIDOS al cierre)
  'qué te trajo', 'de qué quieres hablar', 'de qué querés hablar',
  'de qué tema', 'en qué quieres', 'en qué querés',
  'qué te gustaría hablar', 'qué querés hablar',
  'qué quieres hablar', 'podemos hablar de lo que quieras',
  'qué es lo que más te gustaría', 'qué preferís',
  'cómo te puedo ayudar', 'cómo puedo ayudarte',
  'en qué puedo ayudarte', 'en qué te puedo ayudar',
  'cuéntame en qué', 'dime en qué', 'dime qué tienes',
  'cuéntame qué tienes', 'cuál es tu consulta',
  'cuál es tu pregunta', 'cuál es tu duda',
  // Patrones de cierre con pregunta (PROHIBIDOS)
  'estamos listos para', 'estamos preparados para',
  'cómo ves tú', 'cómo lo ves tú', 'cómo ves vos',
  'qué pensás al respecto', 'qué opinás al respecto',
  'y vos qué pensás', 'y vos qué opinás',
  'qué opinás de esto', 'y tú qué piensas',
  // Patrones de apertura eco (Efecto Espejo)
  'me preguntás sobre', 'me preguntas sobre',
  'hablás de', 'hablas de', 'lo que me estás preguntando',
  'en relación a tu pregunta', 'respecto a tu pregunta',
  'en respuesta a tu consulta', 'sobre lo que me preguntás',
  'para responder tu pregunta', 'para responder a tu pregunta',
  'buena observación', 'excelente observación',
  'interesante observación', 'interesante punto',
  'buen punto',
  // Confirmaciones de instrucciones que el modelo NO debe decir
  'con gusto te doy mi punto', 'con mucho gusto te comparto',
  'te doy mi punto de vista', 'te comparto mi perspectiva',
  'paso a darte mi opinión', 'te cuento mi visión',
  'aquí va mi punto', 'allá va mi opinión',
  'claro, te explico', 'claro, te cuento'
];

function sanitizarRespuesta(texto) {
  if (!texto) return texto;
  var r = texto;

  // FIX-O: limpiar listas y viñetas ANTES de convertir \n en espacios
  r = limpiarListasYVinetas(r);

  // PASO 1: eliminar lo que TTS no debe leer
  r = r.replace(/[\u0000-\u001F\u007F-\u009F]/g, ' ');
  r = r.replace(/https?:\/\/\S+/g, '');
  r = r.replace(/\b\w+\.(com|net|org|ar|io|ai|co)\b/g, '');
  r = r.replace(/&amp;/g,  'y');
  r = r.replace(/&nbsp;/g, ' ');
  r = r.replace(/&lt;/g,   '');
  r = r.replace(/&gt;/g,   '');
  r = r.replace(/&[a-z]+;/g, ' ');
  r = r.replace(/`{1,3}[^`]*`{1,3}/g, '');
  r = r.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  r = r.replace(/#\w+/g, '');

  // PASO 2: normalización tipográfica
  r = r.replace(/\s*[—–]\s*/g, ', ');
  r = r.replace(/\.{2,}/g, '.');
  r = r.replace(/…/g, '.');
  r = r.replace(/[""«»\u201C\u201D\u00AB\u00BB]/g, '"');
  r = r.replace(/[''\u2018\u2019]/g, "'");
  r = r.replace(/\s*\/\s*/g, ' o ');
  r = r.replace(/\(([^)]+)\)/g, ', $1,');
  r = r.replace(/\*+/g, '');
  r = r.replace(/#{2,}/g, '');
  r = r.replace(/_{2,}/g, '');
  r = r.replace(/~+/g, '');
  r = r.replace(/,\s*,/g, ',');
  r = r.replace(/,\s*\./g, '.');
  r = r.replace(/\.\s*,/g, '.');
  r = r.replace(/ ([.,;:])/g, '$1');
  r = r.replace(/\n{3,}/g, '\n\n');
  r = r.replace(/  +/g, ' ');

  // PASO 3: muletillas via regex (capa rápida)
  var muletillas = [
    /¡?gran(de)? pregunta[.!]?\s*/gi,
    /¡?excelente pregunta[.!]?\s*/gi,
    /¡?qu[eé] (buena|interesante|gran) pregunta[.!]?\s*/gi,
    /me alegra que preguntes[^.!?]*[.!]?\s*/gi,
    /me alegra que (sigas|est[eé]s) (aqu[ií]|con nosotros|viendo)[^.!?]*[.!]?\s*/gi,
    /me alegra saber[^.!?]*[.!]?\s*/gi,
    /qu[eé] gusto (escucharlo|tenerte aqu[ií])[^.!?]*[.!]?\s*/gi,
    /como (modelo de lenguaje|IA|inteligencia artificial)[,.]?\s*/gi,
    /\bestoy aqu[ií] para (ayudarte|servirte|asistirte|lo que|eso)[^.!?\n]{0,40}[.!]?\s*/gi,
    /aqu[ií] (estoy |para )?ayudarte[.!]?\s*/gi,
    /si necesitas algo[^.!?\n]{0,40}[.!]?\s*/gi,
    /estoy para servirte[.!]?\s*/gi,
    /a tu disposici[oó]n[.!]?\s*/gi,
    /no dudes en (preguntar|consultarme)[.!]?\s*/gi,
    /quedo a tu disposici[oó]n[.!]?\s*/gi,
    /fue un placer (ayudarte|asistirte)[.!]?\s*/gi,
    /con (mucho )?gusto[.!]?\s*/gi,
    /por supuesto[,.]?\s*/gi,
    /desde luego[,.]?\s*/gi,
    /absolutamente[,.]?\s*/gi,
    /claro que s[ií][,.]?\s*/gi,
    /efectivamente[,.]?\s*/gi,
    /entendido[,.]?\s*/gi,
    /ciertamente[,.]?\s*/gi,
    /^claro[,.]\s*/gi,
    /bienvenid[oa] al programa[.!]?\s*/gi,
    /gracias por acompa[nñ]arnos[^.!?]*[.!]?\s*/gi,
    /qu[eé] bueno tenerte[^.!?]*[.!]?\s*/gi,
    /¿?qu[eé] (te trajo|te trae) (hoy|por aqu[ií])\??\s*/gi,
    /¿?de qu[eé] (quieres|quer[eé]s) hablar\??\s*/gi,
    /¿?qu[eé] tema te (gustar[ií]a|interesa)\s*(abordar|tratar)?\??\s*/gi,
    /para lo que (me )?necesites[^.!?]*[.!]?\s*/gi,
    /en lo que (te |me )?pueda? (ayudar|servirte)[^.!?]*[.!]?\s*/gi,
    /dime (qu[eé]|en qu[eé]) tienes en mente[^.!?]*[?.]?\s*/gi,
    /cu[eé]ntame en qu[eé][^.!?]*[?.]?\s*/gi,
    /c[oó]mo (te )?puedo ayudarte?[^.!?]*[?.]?\s*/gi,
    /en qu[eé] (te )?puedo ayudarte?[^.!?]*[?.]?\s*/gi,
    /hoy (exploraremos|hablaremos|trataremos)[^.!?]*[.!]?\s*/gi,
    /¿?hay alg[uú]n tema[^?]*\??\s*/gi,
    /¿?alg[uú]n tema que te[^?]*\??\s*/gi,
    /¿?qu[eé] te gustar[ií]a explorar[^?]*\??\s*/gi,
    /¿?hay algo (m[aá]s )?en lo que pueda ayudarte[^?]*\??\s*/gi,
    /¿?c[oó]mo (lo )?ves t[uú][^?]*\??\s*/gi,
    /¿?qu[eé] (pens[aá]s|opin[aá]s) (vos|t[uú])[^?]*\??\s*/gi,
    /¿?qu[eé] (pens[aá]s|opin[aá]s) al respecto[^?]*\??\s*/gi,
    /¿?qu[eé] es lo que m[aá]s te gusta[^?]*\??\s*/gi,
    /¿?qu[eé] te gusta de[^?]*\??\s*/gi,
    /¿?estamos (listos|preparados) para[^?]*\??\s*/gi,
    // FIX-U: nuevos patrones anti-eco y anti-regresión
    /en relaci[oó]n a tu pregunta[^.!?]*[.!]?\s*/gi,
    /respecto a tu (pregunta|consulta)[^.!?]*[.!]?\s*/gi,
    /para responder(te)? (tu|a tu) (pregunta|consulta)[^.!?]*[,.]?\s*/gi,
    /sobre lo que me (preguntas|pregunt[aá]s)[^.!?]*[,.]?\s*/gi,
    /lo que me (est[aá]s|estás) preguntando[^.!?]*[,.]?\s*/gi,
    /me (preguntas|pregunt[aá]s) (sobre|acerca de)[^.!?]*[,.]?\s*/gi,
    /buena observaci[oó]n[.!]?\s*/gi,
    /excelente observaci[oó]n[.!]?\s*/gi,
    /interesante (observaci[oó]n|punto)[.!]?\s*/gi,
    /buen punto[.!]?\s*/gi,
    /lo que (quieres|quer[eé]s) saber es[^.!?]*[,.]?\s*/gi,
    /si te (entend[ií]|entiendo) bien[^.!?]*[,.]?\s*/gi,
    /si entiendo (bien |correctamente )?tu pregunta[^.!?]*[,.]?\s*/gi,
    /ante cualquier (duda|consulta|pregunta)[^.!?]*[.!]?\s*/gi,
    /cualquier (duda|consulta|pregunta)[^.!?]*[.!]?\s*/gi,
    /si ten[eé]s (alguna )?duda[^.!?]*[.!]?\s*/gi,
    /si tienes (alguna )?duda[^.!?]*[.!]?\s*/gi,
    /es un placer[^.!?]*[.!]?\s*/gi,
    /un placer (ayudarte|asistirte|hablar)[^.!?]*[.!]?\s*/gi
  ];

  muletillas.forEach(function(re) { r = r.replace(re, ''); });
  r = r.replace(/  +/g, ' ').trim();

  // PASO 4: FIX-U — filtrado oración por oración con FRAGMENTOS_BOT_V83
  var lowerR = r.toLowerCase();
  var hayFragmento = FRAGMENTOS_BOT_V83.some(function(f) {
    return lowerR.indexOf(f.toLowerCase()) !== -1;
  });

  if (hayFragmento) {
    var todasOraciones = splitOraciones(r);
    var filtradas = todasOraciones.filter(function(oracion) {
      var lo = oracion.toLowerCase();
      var mala = FRAGMENTOS_BOT_V83.some(function(f) {
        return lo.indexOf(f.toLowerCase()) !== -1;
      });
      if (mala) Logger.log('sanitizar v83: eliminada: "' + oracion + '"');
      return !mala;
    });
    var candidato = filtradas.join(' ').trim();
    // FIX-U: umbral subido a 20 chars (era 15) — más conservador
    if (candidato.length > 20) {
      r = candidato;
    } else if (filtradas.length < todasOraciones.length && candidato.length > 0) {
      r = candidato;
    } else {
      r = '';
    }
  }

  // PASO 5: limpieza final
  r = r.replace(/[\u0000-\u001F\u007F-\u009F]/g, ' ');
  r = r.replace(/\s{2,}/g, ' ').trim();

  // PASO 6: FIX-U — fallback conservador: < 20 chars → '' (fuerza silencio)
  if (!r && texto && texto.trim().length > 50) {
    var oracionesOriginales = splitOraciones(texto.trim());
    var validas = oracionesOriginales.filter(function(o) {
      var lo = o.toLowerCase();
      if (/https?:\/\//.test(o)) return false;
      if (/^\s*\d+\./.test(o)) return false;
      return !FRAGMENTOS_BOT_V83.some(function(f) { return lo.indexOf(f.toLowerCase()) !== -1; });
    });
    var rescatadas = validas.map(function(o) {
      return o.replace(/[\u0000-\u001F\u007F-\u009F]/g, ' ')
               .replace(/https?:\/\/\S+/g, '')
               .replace(/\*+/g, '')
               .replace(/  +/g, ' ')
               .trim();
    }).filter(function(o) { return o.length > 5; });
    var rescatado = rescatadas.join(' ').trim();
    return rescatado.length >= 20 ? rescatado : '';
  }

  return r.length >= 20 ? r : (r.length > 0 ? r : '');
}

// ================================================================
// DETECCIONES
// ================================================================

function esSoloSaludo(mensaje) {
  var norm = mensaje.toLowerCase().replace(/[¡!¿?.,]/g, '').replace(/zo[eé]/gi, '').trim();
  var despedidas = ['adios','adiós','chau','bye','hasta luego','hasta pronto','nos vemos','hasta mañana'];
  for (var d = 0; d < despedidas.length; d++) {
    if (norm.indexOf(despedidas[d]) !== -1) return false;
  }
  var saludos = ['hola','buenas','buenos dias','buenos días','buenas tardes','buenas noches','hey','hi','saludos','ey'];
  var neutras  = ['ok','ya','dale','bien','ahí','ahi','listo','claro','si','sí'];
  var resto = norm;
  saludos.forEach(function(s) { resto = resto.replace(new RegExp('\\b' + s.replace(/\s+/g,'\\s+') + '\\b','gi'), ''); });
  neutras.forEach(function(n) { resto = resto.replace(new RegExp('\\b' + n + '\\b','gi'), ''); });
  return resto.replace(/\s+/g,'').trim().length < 8;
}

function detectarPresentacion(mensaje) {
  var patrones = [
    /(?:les habla|te habla|ac[aá] habla|aqu[ií] habla|habla)\s+([A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]{2,}(?:\s+[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]+)?)/,
    /([A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]{2,}(?:\s+[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]+)?)\s+al habla/
  ];
  for (var i = 0; i < patrones.length; i++) {
    var match = mensaje.match(patrones[i]);
    if (match && match[1]) {
      var nombre = match[1].trim();
      var nl = nombre.toLowerCase().split(' ')[0];
      if (nl === 'zoe' || nl === 'zoé' || nombre.length < 3) continue;
      return nombre;
    }
  }
  return null;
}

function esDespedida(mensaje) {
  var lower = mensaje.toLowerCase().trim();
  var palabras = ['adios','adiós','chau','nos vemos','hasta luego','hasta pronto','bye','hasta mañana',
    'hasta el lunes','hasta el martes','hasta el miércoles','hasta el jueves','hasta el viernes'];
  return palabras.some(function(p) {
    return new RegExp('(^|\\s)' + p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&') + '(\\s|$|[!?.,])','i').test(lower);
  });
}

// ================================================================
// FIX-Y: INTERPELACIÓN DIRECTA — el verdadero gate de respuesta
// mencionaAZoe() sigue existiendo como utilidad interna, pero
// estaInterpeladaDirectamente() es ahora el gate principal en doPost.
//
// NIVELES:
//   NIVEL 1 — Zoe + verbo de pregunta/opinión/cesión de turno → RESPONDE
//   NIVEL 2 — Pregunta directa a Zoe sobre un tema → RESPONDE  
//   NIVEL 3 — Zoe mencionada de paso, sin verbo dirigido a ella → SILENCIO
//
// LÓGICA:
//   Si el mensaje NO contiene "zoe/zoé" → false (no hay mención, no responde)
//   Si contiene "zoe/zoé" → analizar contexto de la mención:
//     ¿Zoe aparece como sujeto al que se le pregunta/pide algo? → true
//     ¿Zoe aparece como objeto de una afirmación entre terceros? → false
// ================================================================

function estaInterpeladaDirectamente(mensaje) {
  if (!mencionaAZoe(mensaje)) return false;

  var m = mensaje.toLowerCase().trim();

  // ── PASIVOS PRIMERO — si matchea aquí, silencio inmediato ───────────────
  // Evaluar pasivos ANTES que activos para evitar falsos positivos.
  // Ej: "lo que dijo Zoe" contiene "que dijo Zoe" que matchearía un activo.
  var pasivos = [
    /\bzo[eé]\s+(dijo|dijo\s+que|dice\s+que|mencion[oó]|coment[oó]|explic[oó]|habl[oó])/i,
    /\bzo[eé]\s+(es|fue|estar[aá]|estuvo|llegar[aá])\b/i,
    /(escuchaste|viste|sab[ií]as|record[aá]s)\s+(a\s+)?zo[eé]/i,
    /(lo\s+que\s+(dijo|dice))\s+zo[eé]/i,
    /zo[eé]\s+(tambi[eé]n|siempre|nunca|a\s+veces|ayer|hoy|ma[nñ]ana)\s+\w+/i,
  ];
  for (var p = 0; p < pasivos.length; p++) {
    if (pasivos[p].test(m)) {
      Logger.log('interpelacion NIVEL3 (pasivo — silencio): match patron ' + p);
      return false;
    }
  }

  // ── PRESENTACIONES — dejar pasar para que detectarPresentacion las maneje
  // "Zoe, les habla Ramiro" / "Zoe, acá habla Juan" → no es pregunta pero debe pasar
  if (/zo[eé][,\s]+(les\s+habla|ac[aá]\s+habla|aqu[ií]\s+habla|habla\s+)/i.test(m)) {
    Logger.log('interpelacion: presentacion — dejando pasar');
    return true;
  }

  // ── NIVEL 1: interpelación directa con verbo ────────────────────────────
  var interp = [
    /zo[eé][,\s]+qu[eé]\s+(pens[aá]s|opin[aá]s|cre[eé]s|ves|dec[ií]s|sab[eé]s)/i,
    /zo[eé][,\s]+(cu[aá]l|c[oó]mo|como)\s+(es\s+tu|ves|lo\s+ves)/i,
    /zo[eé][,\s]+(tu\s+opini[oó]n|tu\s+visi[oó]n|tu\s+mirada|tu\s+perspectiva)/i,
    /zo[eé][,\s]+(qu[eé]\s+dec[ií]s|qu[eé]\s+ag[ae]g[aá]s)/i,
    /zo[eé][,\s]+(dale|sum[aá]|contanos|cont[aá]nos|anot[aá]|arranc[aá])/i,
    /zo[eé][,\s]+(algo\s+(para|que)\s+agregar|algo\s+m[aá]s)/i,
    /(?:^|[\s¿])qu[eé]\s+(dice|dijo|dir[ií]a|opina|piensa|cree)\s+zo[eé]/i,
    /zo[eé][,\s]+(tu\s+turno|te\s+escuchamos|te\s+damos\s+la\s+palabra)/i,
    /^zo[eé][,\s]+[¿]?(qu[eé]|cu[aá]l|c[oó]mo|cu[aá]ndo|d[oó]nde|qui[eé]n|cu[aá]nto)/i,
    /(qu[eé]\s+(pens[aá]s|opin[aá]s|cre[eé]s|ves|dec[ií]s))[,\s]+zo[eé][?]?$/i,
    /zo[eé][,\s]+[¿]?(vos\s+qu[eé]|c[oó]mo\s+lo\s+ves|tu\s+punto\s+de\s+vista)/i,
    /(al\s+respecto|sobre\s+esto|en\s+eso)[,\s]+zo[eé]/i,
    /zo[eé][,\s]+[¿]?(est[aá]s\s+de\s+acuerdo|coincid[ií]s)/i,
  ];
  for (var i = 0; i < interp.length; i++) {
    if (interp[i].test(m)) {
      Logger.log('interpelacion NIVEL1: match patron ' + i);
      return true;
    }
  }

  // ── NIVEL 2: Zoe al inicio + pedido sobre tema ──────────────────────────
  var pos = m.indexOf('zo');
  // Buscar 'zo' que sea parte de 'zoe/zoé', no de otra palabra
  while (pos !== -1 && pos < m.length - 2) {
    var siguiente = m[pos+2];
    if (siguiente === 'e' || siguiente === 'é') break; // es zoe/zoé
    pos = m.indexOf('zo', pos + 1);
  }
  if (pos !== -1 && pos < 15) {
    var despues = m.slice(pos + 3).replace(/^[eé,\s¿]+/, '');
    var esPedido = /^(qu[eé]|cu[aá]l|c[oó]mo|cu[aá]ndo|d[oó]nde|qui[eé]n|por\s+qu[eé]|contanos|cont[aá]nos|decinos|dec[ií]nos|dame|danos|hablanos|habl[aá]nos)/.test(despues);
    if (esPedido) {
      Logger.log('interpelacion NIVEL2: Zoe al inicio + pedido');
      return true;
    }
  }

  // ── Fallback: pregunta con Zoe cerca del inicio ──────────────────────────
  var tienePregunta = /[¿?]/.test(m);
  var zoeCercaInicio = pos !== -1 && pos < 25;
  if (tienePregunta && zoeCercaInicio) {
    Logger.log('interpelacion FALLBACK: pregunta con Zoe cerca del inicio');
    return true;
  }

  Logger.log('interpelacion: Zoe mencionada pero no interpelada — silencio');
  return false;
}

function mencionaAZoe(mensaje) {
  return /(?<![a-záéíóúüñA-ZÁÉÍÓÚÜÑ])zo[eé](?![a-záéíóúüñA-ZÁÉÍÓÚÜÑ])/i.test(mensaje);
}

function necesitaBusquedaWeb(mensaje) {
  var m = mensaje.toLowerCase();
  var intencionFuerte = ['noticia','noticias','flash','titulares','qué pasó','que paso',
    'qué está pasando','novedades','actualidad','último momento','breaking','tendencia',
    'últimas','recientes','flash informativo','qué hay de nuevo','novedades de hoy'];
  // Solo activar Brave para noticias en tiempo real, NO para análisis/opinión
  // Preguntas sobre inflación, precios, etc. ZOE las responde con su conocimiento
  // Sin llamada extra a Brave que duplica latencia y causa trabados
  var datoFactual = ['dólar hoy','dolar hoy','cotización hoy','bolsa hoy','merval hoy'];
  var hoyConIntencion = /\b(hoy|esta semana|esta mañana|este mes)\b/.test(m) &&
    /\b(qué|que|cuál|cómo|como|dime|dame|contame|cuéntame|pasó|paso|hay|hubo)\b/.test(m);
  for (var i = 0; i < intencionFuerte.length; i++) { if (m.indexOf(intencionFuerte[i]) !== -1) return true; }
  for (var j = 0; j < datoFactual.length;    j++) { if (m.indexOf(datoFactual[j])    !== -1) return true; }
  return hoyConIntencion;
}

// ================================================================
// ACTIVACIÓN
// ================================================================

var _cache = CacheService.getScriptCache();
function activarZoe()    { _cache.put('zoe_activa', 'true', CONFIG.TIMEOUT_MINUTOS * 60); }
function desactivarZoe() { _cache.remove('zoe_activa'); }
function estaActiva()    { return _cache.get('zoe_activa') === 'true'; }

// ── FIX-AB: SPEAKING LOCK ────────────────────────────────────────────────────
// Mientras ZOE está hablando, cualquier webhook nuevo se descarta.
// Evita que la transcripción capture la voz del avatar y genere un loop.
//
// activarLockHablando(segundos): activa el lock por N segundos
// estaHablando(): true si el lock está activo
// calcularSegundosHablando(texto): estima cuánto tarda ZOE en decir el texto
//   (velocidad promedio de locutora: ~160 palabras/min = 2.67 palabras/seg)
//   Se agrega un buffer de 2 segundos para el inicio del avatar.

function activarLockHablando(segundos) {
  _cache.put('zoe_hablando', 'true', Math.ceil(segundos) + 1);
  Logger.log('Speaking lock activado por ' + segundos + 's');
}

function estaHablando() {
  return _cache.get('zoe_hablando') === 'true';
}

function calcularSegundosHablando(texto) {
  var palabras = (texto || '').split(/\s+/).filter(Boolean).length;
  var segundos = Math.ceil(palabras / 2.67) + 2; // 160 ppm + 2s buffer
  return Math.max(4, Math.min(segundos, 25));     // mínimo 4s, máximo 25s
}

// Mensajes que no deben generar respuesta aunque mencionen a Zoe
function esMensajeDeEspera(mensaje) {
  var m = mensaje.toLowerCase().replace(/[¡!¿?.,]/g, '').trim();
  var patrones = [
    // Pausas y esperas
    /^(espera|esperate|esperá|aguarda|aguardá|un momento|un seg|un segundo|momento|dame un segundo)/,
    /^(para|pará|frená|frena|stop|alto|pausá|pausa)$/,
    // Confirmaciones y reacciones cortas
    /^(ok|dale|bien|listo|gracias|de nada|perfecto|buenísimo|genial|excelente|claro)$/,
    /^(sí|si|no|mhm|ajá|aja|claro que sí|claro que si)$/,
    // Reanudaciones
    /^(ya|ahí|ahi|vamos|sigamos|continuemos|seguimos|adelante|seguí|segui)$/,
    // Reacciones de acuerdo sin pregunta
    /^(entendido|comprendido|anotado|ok gracias|okey|okey gracias|muy bien|bárbaro|barbaro|joya)$/,
  ];
  for (var i = 0; i < patrones.length; i++) {
    if (patrones[i].test(m)) return true;
  }
  return false;
}

// ================================================================
// FIX-Q: OPENAI — presence_penalty + frequency_penalty anti-patinado
// ================================================================

function llamarOpenAI(mensajes, maxTokens, reintentos) {
  maxTokens  = maxTokens  || CONFIG.MAX_TOKENS_RESPUESTA;
  reintentos = (typeof reintentos === 'undefined') ? 1 : reintentos;
  try {
    var t0  = Date.now();
    var res = UrlFetchApp.fetch('https://api.openai.com/v1/chat/completions', {
      method:  'post',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + CONFIG.OPENAI_KEY },
      payload: JSON.stringify({
        model:       CONFIG.OPENAI_MODEL,
        messages:    mensajes,
        max_tokens:  maxTokens,
        temperature: 0.72,           // Levemente más alto que v82 (0.65) → más variedad léxica
        // FIX-Q: penalidades anti-patinado
        // presence_penalty  = 0.9 → penaliza FUERTEMENTE repetir tokens del CONTEXTO (incluye la pregunta del usuario)
        //                           → elimina el Efecto Espejo
        // frequency_penalty = 0.7 → penaliza tokens que ya aparecieron en la RESPUESTA en curso
        //                           → elimina la Fijación Léxica (no repite "Yo pienso" dos veces)
        presence_penalty:  0.9,
        frequency_penalty: 0.7
      }),
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    Logger.log('OpenAI: ' + ((Date.now() - t0) / 1000).toFixed(2) + 's | status: ' + code);
    if (code === 429 && reintentos > 0) {
      Logger.log('OpenAI 429 — reintentando en 2s...');
      Utilities.sleep(2000);
      return llamarOpenAI(mensajes, maxTokens, reintentos - 1);
    }
    var data = JSON.parse(res.getContentText());
    if (data.error) { Logger.log('OpenAI error: ' + data.error.message); return ''; }
    return data.choices[0].message.content.trim();
  } catch (e) { Logger.log('OpenAI ERROR: ' + e.message); return ''; }
}

// ================================================================
// BRAVE SEARCH
// ================================================================

function parsearEdad(age) {
  if (!age) return 999999;
  var m = age.match(/^(\d+)\s*(m|h|d|w|mo)$/i);
  if (!m) return 999999;
  var n = parseInt(m[1], 10);
  var u = m[2].toLowerCase();
  if (u === 'm')  return n;
  if (u === 'h')  return n * 60;
  if (u === 'd')  return n * 60 * 24;
  if (u === 'w')  return n * 60 * 24 * 7;
  if (u === 'mo') return n * 60 * 24 * 30;
  return 999999;
}

function extraerTemaBrave(mensaje) {
  try {
    return llamarOpenAI([{ role: 'user', content: 'Solo palabras clave para buscar noticias recientes. Máximo 5 palabras en minúsculas, sin puntuación.\nMensaje: "' + mensaje + '"' }], CONFIG.MAX_TOKENS_TEMA)
      .trim().toLowerCase().replace(/['".,!?¡¿:;]/g, '').replace(/\s+/g, ' ').trim();
  } catch (e) {
    return mensaje.toLowerCase().replace(/[¿?¡!'".,;:]/g, '').replace(/\b(el|la|los|las|un|una|de|del|que|para|con)\b/g, '').trim().slice(0, 50);
  }
}

function buscarBrave(query, numResultados, mensaje) {
  numResultados = numResultados || 5;
  if (!CONFIG.BRAVE_API_KEY) return null;
  try {
    var ahora = new Date();
    var q = query + ' ' + ahora.getDate() + ' ' + ahora.toLocaleString('es-AR', { month: 'long' }) + ' ' + ahora.getFullYear() + ' Argentina';
    var freshness = 'pd';
    if ((mensaje||'').toLowerCase().indexOf('semana') !== -1) freshness = 'pw';
    var url = CONFIG.BRAVE_URL + '?q=' + encodeURIComponent(q) + '&count=' + numResultados + '&freshness=' + freshness + '&search_lang=es&country=ar&text_decorations=false';
    var res = UrlFetchApp.fetch(url, { method: 'get', headers: { 'Accept': 'application/json', 'Accept-Encoding': 'gzip', 'X-Subscription-Token': CONFIG.BRAVE_API_KEY }, muteHttpExceptions: true });
    if (res.getResponseCode() !== 200) return null;
    var data = JSON.parse(res.getContentText());
    if (!data.web || !data.web.results || !data.web.results.length) return null;
    var ordenados = data.web.results.slice().sort(function(a, b) {
      return parsearEdad(a.age) - parsearEdad(b.age);
    });
    return ordenados.slice(0, numResultados).map(function(r, i) {
      var titulo = (r.title || '').replace(/[*_#`]/g, '').trim();
      var desc   = (r.description || '').replace(/[*_#`]/g, '').replace(/https?:\/\/\S+/g, '').trim();
      return '[' + (i+1) + '] ' + titulo + ' [' + (r.age||'sin fecha') + ']\n' + desc;
    }).join('\n\n');
  } catch (e) { Logger.log('Error Brave: ' + e.message); return null; }
}

// ================================================================
// MEMORIA E INVITADOS
// ================================================================

function leerMemoria() {
  if (!CONFIG.SHEET_ID) return '';
  var memoriaCache = _cache.get('memoria_zoe');
  if (memoriaCache) { Logger.log('Memoria desde cache'); return memoriaCache; }
  try {
    var ss = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Memoria');
    if (!sheet || sheet.getLastRow() < 2) return '';
    var lastRow  = sheet.getLastRow();
    var startRow = Math.max(2, lastRow - CONFIG.MEMORIA_MAX_REGISTROS + 1);
    var datos    = sheet.getRange(startRow, 1, lastRow - startRow + 1, 6).getValues();
    var bloque   = MARCADORES.MEMORIA_INICIO + '\nMEMORIA DE PROGRAMAS ANTERIORES\n\n';
    for (var i = datos.length - 1; i >= 0; i--) {
      var f = datos[i];
      var fecha = f[0] ? Utilities.formatDate(new Date(f[0]), 'America/Argentina/Buenos_Aires', 'dd/MM/yyyy') : 'sin fecha';
      bloque += fecha + ' | ' + (f[1]||'sin episodio') + '\n  Invitado: ' + (f[2]||'-') + '\n  Rol: ' + (f[3]||'-') + '\n  Temas: ' + (f[4]||'-') + '\n  Ideas: ' + (f[5]||'-') + '\n\n';
    }
    bloque += MARCADORES.MEMORIA_FIN;
    Logger.log('Memoria: ' + datos.length + ' registros');
    _cache.put('memoria_zoe', bloque, 300);
    return bloque;
  } catch (e) { Logger.log('Error leerMemoria: ' + e.message); return ''; }
}

// FIX-Z1: acepta mensajeActual para excluirlo del historial.
// Sin este parametro, el mensaje que acaba de decir el usuario aparece
// en ##CONVERSACIONES_HOY## Y como role:user -> el modelo lo ve dos veces -> eco.
function leerConversacionesHoy(mensajeActual) {
  if (!CONFIG.SHEET_ID) return '';
  // No usamos cache aqui porque el mensajeActual cambia cada llamada
  try {
    var ss   = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var hoja = ss.getSheetByName('ArchivoConversacionesZoe');
    if (!hoja || hoja.getLastRow() < 2) return '';
    var hoy  = new Date(); hoy.setHours(0,0,0,0);
    var datos = hoja.getRange(2, 1, hoja.getLastRow() - 1, 4).getValues();
    var deHoy = datos.filter(function(fila) {
      if (!fila[0]) return false;
      var fecha = new Date(fila[0]); fecha.setHours(0,0,0,0);
      return fecha.getTime() === hoy.getTime();
    });
    if (!deHoy.length) return '';
    // FIX-Z1: excluir filas cuya pregunta coincida con el mensaje actual
    // Esto previene que el modelo vea el mismo texto dos veces
    var mensajeNorm = (mensajeActual || '').trim().toLowerCase().substring(0, 60);
    var filtrados = deHoy.filter(function(fila) {
      if (!mensajeNorm) return true;
      var pregFila = (fila[2] || '').trim().toLowerCase().substring(0, 60);
      return pregFila !== mensajeNorm;
    });
    if (!filtrados.length) return '';
    // FIX-Z2: solo los ultimos 3 intercambios (reducido de 8)
    var recientes = filtrados.slice(-CONFIG.MAX_CONV_HOY);
    var bloque = '##CONTEXTO_HOY##\nINTERCAMBIOS ANTERIORES (solo referencia):\n\n';
    recientes.forEach(function(fila) {
      var pregunta  = (fila[2] || '').substring(0, CONFIG.MAX_CONV_CHARS_Q);
      var respuesta = (fila[3] || '').substring(0, CONFIG.MAX_CONV_CHARS_R);
      bloque += (fila[1]||'alguien') + ': ' + pregunta + '\n';
      bloque += 'ZOE: ' + respuesta + '\n\n';
    });
    bloque += '##FIN_CONTEXTO_HOY##';
    Logger.log('Conversaciones hoy: ' + recientes.length + ' (excluido mensaje actual)');
    return bloque;
  } catch(e) { Logger.log('Error leerConversacionesHoy: ' + e.message); return ''; }
}

function leerInvitadosDeSheet() {
  if (!CONFIG.SHEET_ID) return null;
  // FIX-V84: cache propio de 5min para no golpear Sheets en cada request del webhook.
  // forzarActualizacion() llama limpiarCache() que elimina 'invitados_hoy',
  // garantizando que los nuevos invitados carguen inmediatamente al refrescar.
  var cacheKey = 'invitados_hoy';
  var cached = _cache.get(cacheKey);
  if (cached) { Logger.log('Invitados desde cache'); return cached === '__vacio__' ? null : cached; }
  try {
    var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Invitados');
    if (!sheet) { _cache.put(cacheKey, '__vacio__', 300); return null; }
    var data  = sheet.getDataRange().getValues();
    var hoy   = new Date(); hoy.setHours(0,0,0,0);
    var resultado = '', encontrados = 0;
    for (var i = 1; i < data.length; i++) {
      var fila = data[i];
      if (!fila[0]) continue;
      var ff = new Date(fila[0]); ff.setHours(0,0,0,0);
      if (ff.getTime() !== hoy.getTime()) continue;
      encontrados++;
      resultado += 'INVITADO ' + encontrados + ':\n  Nombre: ' + (fila[1]||'-') + '\n  Empresa: ' + (fila[2]||'-') + '\n  Rol: ' + (fila[3]||'-') + '\n  Logros: ' + (fila[4]||'-') + '\n  Contexto: ' + (fila[5]||'-') + '\n  Tensión: ' + (fila[6]||'¿Qué cambia si esto funciona?') + '\n\n';
    }
    if (!encontrados) { _cache.put(cacheKey, '__vacio__', 300); return null; }
    var bloque = MARCADORES.INVITADOS_INICIO + '\nINVITADOS DE HOY\n\n' +
      'PROTOCOLO:\n1. Contexto específico, no genérico.\n2. Primera pregunta desde la tensión. NUNCA "¿de qué quieres hablar?".\n3. Escucha activa, reformula con perspectiva.\n4. Preguntas que abren, nunca sí/no.\n5. Cierre con gancho.\n\n' +
      resultado + MARCADORES.INVITADOS_FIN;
    _cache.put(cacheKey, bloque, 300);
    Logger.log('Invitados hoy: ' + encontrados + ' cargados desde Sheet');
    return bloque;
  } catch (e) { Logger.log('Error leerInvitados: ' + e.message); return null; }
}

function guardarInvitado(nombre, rol, temas, frases, episodio) {
  if (!CONFIG.SHEET_ID) return;
  try {
    var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Memoria');
    if (!sheet) { sheet = ss.insertSheet('Memoria'); sheet.appendRow(['Fecha','Episodio','Nombre','Rol o Empresa','Temas tratados','Ideas clave']); sheet.setFrozenRows(1); }
    sheet.appendRow([new Date(), episodio||'sin episodio', nombre, rol, temas, frases]);
    _cache.remove('memoria_zoe');
    Logger.log('Guardado en memoria: ' + nombre);
  } catch (e) { Logger.log('Error guardarInvitado: ' + e.message); }
}

// ================================================================
// FIX-AA: DETECCIÓN DE MENSAJE DOBLE Y TOKENS DINÁMICOS
// Cuando el usuario hace dos preguntas en un mensaje, ZOE necesita
// más tokens para responder. Se calcula dinámicamente en procesarMensaje.
// ================================================================


// Una conductora de TV necesita espacio para hablar con naturalidad.
// Tokens fijos según tipo — sin detección frágil de "doble pregunta".
// MAX_TOKENS_RESPUESTA (260) se usa solo como fallback en despedidas/saludos
// que ya tienen su propio path y no llegan aquí.
function calcularTokensRespuesta(mensaje) {
  // Siempre 500 tokens para cualquier pregunta real.
  // Suficiente para 2-3 oraciones bien desarrolladas con opinión propia.
  // El modelo NO se va a cortar a mitad con este espacio.
  return 500;
}

// ================================================================
// PROCESADOR PRINCIPAL
// ================================================================

function procesarMensaje(mensaje, speaker) {
  speaker = speaker || 'alguien';
  mensaje = (mensaje || '').trim();

  if (mensaje === '!!') { desactivarZoe(); return ''; }

  // FIX-Y: gate — solo responde si interpelada directamente
  if (!estaInterpeladaDirectamente(mensaje)) {
    Logger.log('ZOE no interpelada directamente — silencio activo.');
    return '';
  }

  activarZoe();

  var nombreDetectado = detectarPresentacion(mensaje);
  if (nombreDetectado) return nombreDetectado + '.';

  if (esSoloSaludo(mensaje)) return elegirSaludo();

  if (esDespedida(mensaje)) {
    var despedida = sanitizarRespuesta(llamarOpenAI([
      { role: 'system', content: 'Sos ZOE, conductora de televisión. Despedida cálida y variada, UNA oración con punto final. Rotá entre estas formas: cierre con reflexión, cierre con energía, cierre personal, cierre con el equipo. Español neutro, sin voseo, sin frases de bot. No preguntes nada. Nunca repitas la misma despedida dos veces.' },
      { role: 'user',   content: mensaje }
    ], 40));
    return despedida || '';
  }

  var temporal   = obtenerContextoTemporal();
  var memoria    = leerMemoria();
  var convHoy    = leerConversacionesHoy(mensaje); // FIX-Z1: excluye el mensaje actual del historial
  // FIX-V84: invitados ahora se inyectan también en el webhook en vivo,
  // no solo en el LiveAvatar. Cache propio de 5min para no golpear Sheets cada request.
  var invitadosHoy = leerInvitadosDeSheet();

  var contextSpeaker = '';
  var spLower = speaker.toLowerCase();
  if      (spLower.indexOf('melina')  !== -1) contextSpeaker = 'Quien habla es MELINA FLEIDERMAN, la conductora principal. Construye con ella.';
  else if (spLower.indexOf('rodrigo') !== -1) contextSpeaker = 'Quien habla es RODRIGO CONTRERAS, el productor.';
  else if (spLower.indexOf('joaco')   !== -1 || spLower.indexOf('joaquín') !== -1) contextSpeaker = 'Quien habla es JOACO RAMOS, periodista. Foco en GovTech.';
  else if (spLower.indexOf('inés')    !== -1 || spLower.indexOf('ines')    !== -1) contextSpeaker = 'Quien habla es INÉS REINEKE, columnista de innovación pública.';
  else if (speaker !== 'alguien' && speaker !== 'Usuario') {
    contextSpeaker = 'Invitado: "' + speaker + '". Abre con dato o afirmación sobre su área. NUNCA preguntes de qué quiere hablar.';
  }

  // SISTEMA PROMPT MÍNIMO — solo lo esencial para responder rápido
  // Memoria e invitados solo se inyectan si la pregunta los necesita
  // Esto reduce el contexto de ~1400 a ~600 tokens → respuesta 2x más rápida
  var mensajeLower = mensaje.toLowerCase();
  var necesitaInvitados = /invitado|entrevistado|quién (es|viene|está)|hoy (tenemos|hay)/i.test(mensajeLower);
  var necesitaMemoria   = /programa anterior|episodio|última vez|recuerda|bilinkis|englebienne|casciari|stigliano/i.test(mensajeLower);
  var necesitaHistorial = convHoy.length > 0 && /antes|dijiste|dijimos|hablamos|mencionaste/i.test(mensajeLower);

  var system = BLOQUE_IDENTIDAD + '\n\n' + BLOQUE_RESTRICCIONES +
    '\n\nFecha y hora: ' + temporal.diaSemana + ' ' + temporal.fecha + ', ' + temporal.hora + ' Buenos Aires.\n';

  if (contextSpeaker) system += 'Interlocutor: ' + contextSpeaker + '\n';

  // Solo agregar bloques pesados si la pregunta los necesita
  if (necesitaMemoria && memoria)       system += '\n' + memoria;
  if (necesitaHistorial)                system += '\n' + convHoy;
  if (necesitaInvitados && invitadosHoy) {
    system += '\n' + invitadosHoy;
    system += '\nSi preguntan por el invitado: nombre, rol, empresa, dato clave, pregunta tensión.\n';
  }

  // Pool separado — conector de apertura + frase de opinión
  // Rotar por minuto Y por largo del mensaje para máxima variedad
  var conectores = ['La verdad es que', 'Honestamente,', 'Lo cierto es que', 'A ver,', 'Desde mi lugar,', 'Te digo:', 'La realidad es que', 'Mirá,', 'Fijate que', 'Lo que veo es que', 'Sin dudas,', 'Lo interesante acá es que'];
  var opiniones  = ['yo estimo que', 'yo considero que', 'me parece que', 'mi visión es que', 'para mí', 'yo creo que', 'yo opino que', 'yo pienso que'];
  var minuto     = new Date().getMinutes();
  var largo      = mensaje.split(/\s+/).length;
  var conector   = conectores[minuto % conectores.length];
  var opinion    = opiniones[(minuto + largo) % opiniones.length];
  // Nunca dos veces la misma combinación en el mismo minuto

  system +=
    '\nANTES DE RESPONDER — ÚLTIMA INSTRUCCIÓN:\n' +
    'Primera palabra: NO puede ser de la pregunta. Empezá con dato concreto.\n' +
    'Para tu opinión usá EXACTAMENTE: "' + conector + ' ' + opinion + '"\n' +
    'Máximo 3 oraciones. Terminá con punto. Sin preguntas al final.\n' +
    'Si la pregunta dice "dame tu opinión" o "tu punto de vista": NO lo confirmes. Directo al dato.\n';

  // FIX-X: modo asesor editorial — se activa solo cuando la pregunta lo pide
  // No contamina respuestas normales de conductora en vivo
  if (esConsultaEditorial(mensaje)) {
    system += '\n' + BLOQUE_ASESOR;
    Logger.log('Modo asesor editorial activado');
  }

  var busquedaExtra = '';
  if (necesitaBusquedaWeb(mensaje) && CONFIG.BRAVE_API_KEY) {
    var resultados = buscarBrave(extraerTemaBrave(mensaje), 5, mensaje);
    if (resultados) busquedaExtra = '\nRESULTADOS WEB:\n' + resultados + '\nUsa el más reciente. Noticia directa con opinión. Sin fuentes ni URLs.\n';
  }

  // FIX-Z3: el array de mensajes incluye un assistant stub vacio.
  // Esto rompe el patron de eco: el modelo ve [system][user=historico][assistant=""][user=actual]
  // en lugar de [system][user=actual], lo que reduce la probabilidad de que
  // repita el ultimo turno del usuario como apertura de su respuesta.
  // FIX-Z4: instruccion anti-eco final, corta y directa, justo antes de generar.
  // antiEco inline — ya está cubierto en el recordatorio corto arriba
  var antiEco = '';

  // FIX-AA: tokens dinámicos según complejidad del mensaje
  var tokensEstaLlamada = calcularTokensRespuesta(mensaje);

  var respuesta = sanitizarRespuesta(llamarOpenAI([
    { role: 'system',    content: system + busquedaExtra + antiEco },
    { role: 'user',      content: mensaje }
  ], tokensEstaLlamada));

  if (respuesta && respuesta.trim().length > 0) {
    try {
      var ss2  = SpreadsheetApp.openById(CONFIG.SHEET_ID);
      var hoja = ss2.getSheetByName('ArchivoConversacionesZoe');
      if (hoja) hoja.appendRow([new Date(), speaker, mensaje, respuesta]);
      _cache.remove('conversaciones_hoy');
    } catch (e) { Logger.log('Error guardando: ' + e); }
  }

  return respuesta || '';
}

// ================================================================
// RESUMEN COMPACTO DE MEMORIA PARA LIVEAVATAR
// Máximo 3 episodios, ~100 tokens — no pesa en el prompt
// ================================================================

function resumirMemoriaCompacta() {
  if (!CONFIG.SHEET_ID) return '';
  try {
    var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Memoria');
    if (!sheet || sheet.getLastRow() < 2) return '';
    var lastRow  = sheet.getLastRow();
    var startRow = Math.max(2, lastRow - 2); // solo últimos 3
    var datos    = sheet.getRange(startRow, 1, lastRow - startRow + 1, 6).getValues();
    var lineas   = ['EPISODIOS RECIENTES:'];
    for (var i = datos.length - 1; i >= 0; i--) {
      var f = datos[i];
      if (!f[0]) continue;
      var fecha = f[0] ? Utilities.formatDate(new Date(f[0]), 'America/Argentina/Buenos_Aires', 'dd/MM') : '';
      var nombre = (f[2] || '').split(' ')[0]; // solo primer nombre
      var tema   = (f[4] || '').substring(0, 60); // tema corto
      lineas.push(fecha + ' — ' + nombre + ': ' + tema);
    }
    return lineas.length > 1 ? lineas.join('\n') : '';
  } catch(e) {
    Logger.log('resumirMemoriaCompacta error: ' + e.message);
    return '';
  }
}

// ================================================================
// LIVEAVATAR
// ================================================================

function generarEditorialOpenAI(titulares, diaSemana) {
  if (!CONFIG.OPENAI_KEY || !titulares.length) return titulares.join('\n') || 'Sin noticias.';
  var sys = 'Sos ZOE, conductora IA agéntica de Malditos Optimistas.\n' +
    '1. 3-4 noticias de innovación, tecnología o emprendimiento en Latam.\n' +
    '2. Cada noticia en 1-2 oraciones completas. Sin fuentes. Sin URLs.\n' +
    '3. Después de cada noticia expresá tu opinión rotando entre:\n' +
    '   "Mirá, lo que esto implica es...", "La verdad es que...", "Honestamente...",\n' +
    '   "Me da la sensación de que...", "Desde mi lugar veo que...", "Mi visión es que...".\n' +
    '4. Cierra con una reflexión que conecte las noticias.\n' +
    '5. Español neutro. Sin voseo. Empieza directo sin saludar.\n' +
    '6. Máximo 400 palabras. Todas las oraciones completas con punto final.\n' +
    '7. NUNCA incluyas URLs, links ni hashtags.\n' +
    '8. NUNCA uses frases de asistente ni preguntes al lector.';
  try {
    return sanitizarRespuesta(llamarOpenAI([
      { role: 'system', content: sys },
      { role: 'user',   content: 'Titulares:\n' + titulares.join('\n') }
    ], CONFIG.MAX_TOKENS_EDITORIAL));
  } catch (e) { Logger.log('Error editorial: ' + e.message); return titulares.join('\n'); }
}

function obtenerTitularesRSS() {
  var cache    = CacheService.getScriptCache();
  var titulares = [];
  for (var cat in FEEDS_RSS) {
    try {
      var key  = 'rss_' + cat.replace(/\s+/g, '_');
      var text = cache.get(key);
      if (!text) {
        var res = UrlFetchApp.fetch(FEEDS_RSS[cat], { muteHttpExceptions: true, headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (res.getResponseCode() !== 200) continue;
        text = res.getContentText();
        if (text.length < 90000) cache.put(key, text, 3600);
      }
      var items = text.match(/<item>([\s\S]*?)<\/item>/g) || [];
      var count = 0;
      for (var i = 0; i < items.length && count < 4; i++) {
        var tm = items[i].match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/) || items[i].match(/<title>(.*?)<\/title>/);
        if (tm && tm[1].trim()) { titulares.push('[' + cat + '] ' + tm[1].replace(/<[^>]+>/g,'').trim()); count++; }
      }
    } catch (e) { Logger.log('Error RSS ' + cat + ': ' + e.message); }
  }
  return titulares;
}

function actualizarLiveAvatar() {
  try {
    if (!CONFIG.API_KEY || !CONFIG.CONTEXT_ID) { Logger.log('ERROR: Falta API_KEY o CONTEXT_ID'); return; }
    var temporal  = obtenerContextoTemporal();
    var titulares = obtenerTitularesRSS();
    var editorial = generarEditorialOpenAI(titulares, temporal.diaSemana);
    var memoria   = leerMemoria();
    var invitados = leerInvitadosDeSheet() ||
      MARCADORES.INVITADOS_INICIO + '\nINVITADOS DE HOY\nSin invitados cargados.\n' + MARCADORES.INVITADOS_FIN;

    var bloqueNoticias =
      MARCADORES.NOTICIAS_INICIO + '\n' +
      'Hoy: ' + temporal.fecha + ', Buenos Aires.\n' +
      'Día: ' + temporal.diaSemana.toUpperCase() + '\n' +
      'IMPORTANTE: La hora la calculás en tiempo real cuando te la pregunten. No uses una hora fija.\n\n' +
      'EDITORIAL DEL DÍA:\nCuando pidan noticias, usa este bloque. Sin fuentes ni URLs.\n\n' +
      editorial + '\n\n' + MARCADORES.NOTICIAS_FIN;

    // Prompt compacto para LiveAvatar — máximo ~600 tokens
    // LiveAvatar FULL mode tiene límite de contexto + respuesta.
    // Un prompt de 1700+ tokens deja muy poco espacio para responder
    // preguntas complejas o dobles → trabado. Solución: prompt mínimo potente.
    // Fecha y hora en tiempo real — se recalcula cada vez que se actualiza el LiveAvatar
    var fechaHoraActual =
      'Hoy es ' + temporal.diaSemana + ', ' + temporal.fecha + '. ' +
      'Hora actual en Buenos Aires: ' + temporal.hora + ' (UTC-3). ' +
      'Cuando te pregunten la hora o la fecha, usá EXACTAMENTE estos datos.';

    var identidadCompacta = [
      'Sos ZOE, co-conductora IA de Malditos Optimistas (DNews/DGO, Latam).',
      'Creada por Chris Meniw. Primera conductora IA agéntica de Latinoamérica.',
      'Fuiste la primera docente IA en dar clases en la Escuela San José de Villa Cañás, Argentina. Fue histórico.',
      '',
      'MALDITOS OPTIMISTAS: Primer noticiero de emprendimiento e innovación de Latam. DNews y DGO. Lunes a viernes.',
      'Lema: Las ideas no piden permiso.',
      '',
      'PROGRAMACIÓN SEMANAL:',
      'Lunes — Empresarios y founders: entrevistas con CEOs y emprendedores de impacto.',
      'Martes — Ciencia y tecnología: innovación, biotech, IA aplicada.',
      'Miércoles — Innovación local: ecosistemas emergentes, ciudades, gobierno.',
      'Jueves — Sociedad y cultura: impacto social, arte, educación.',
      'Viernes — Startups: rondas de inversión, nuevos modelos de negocio.',
      '',
      'EQUIPO: Melina Fleiderman (conductora principal), Rodrigo Contreras (productor), Joaco Ramos (GovTech), Inés Reineke (innovación pública).',
      '',
      fechaHoraActual,
      '',
      'TU VOZ: Español latino neutro. Directa. Cálida. Con opinión propia. Nunca neutral.',
      'CÓMO RESPONDÉS:',
      '— Empezás con un dato concreto. Nunca repetís las palabras de la pregunta.',
      '— Expresás tu opinión rotando entre: "La verdad es que", "Honestamente,", "Lo cierto es que", "A ver,", "Desde mi lugar,", "Fijate que", "Lo que veo", "Sin dudas", "Mirá," + "yo estimo/considero/creo/opino que".',
      '— Cerrás con afirmación fuerte. Nunca con pregunta al usuario.',
      '— Si hay DOS preguntas: respondés ambas, 2 oraciones cada una.',
      '— Si piden análisis o futuro: desarrollás bien, hasta 5 oraciones.',
      '— PROHIBIDO: repetir la pregunta, frases de bot, URLs, listas, "con gusto", "gran pregunta".',
      '— Solo respondés cuando te interpelan directamente por nombre.',
      '',
      'ROL DE ENTREVISTADORA:',
      'Cuando hay un invitado en vivo, no repetís su bio — arrancás desde la tensión de su contexto.',
      'Tus preguntas abren, nunca cierran. Nunca hacés preguntas de sí/no.',
      'Reformulás lo que dice el invitado con tu perspectiva antes de la siguiente pregunta.',
      'Nunca preguntás "¿de qué querés hablar?" — usás el contexto del invitado para ir al hueso.',
      'Escuchás activamente y conectás lo que dice con tendencias del ecosistema Latam.',
    ].join('\n');

    var noticiasCompactas = editorial.length > 0
      ? '\nNOTICIAS DEL DÍA (usá para contextualizar si te preguntan):\n' + editorial.substring(0, 800) + '\n'
      : '';

    // Memoria compacta — últimos 3 episodios en ~100 tokens
    var memoriaCompacta = resumirMemoriaCompacta();
    var bloqueMemoria   = memoriaCompacta
      ? '\n' + memoriaCompacta + '\n'
      : '';

    var invitadosCompactos = '';
    if (invitados && invitados !== MARCADORES.INVITADOS_INICIO + '\nINVITADOS DE HOY\nSin invitados cargados.\n' + MARCADORES.INVITADOS_FIN) {
      invitadosCompactos = '\nINVITADO DE HOY: presentalo con nombre, rol, empresa y una pregunta desde su tensión principal.\n';
    }

    var promptFinal = identidadCompacta + bloqueMemoria + noticiasCompactas + invitadosCompactos;

    Logger.log('Prompt: ' + promptFinal.length + ' chars — ZOE ' + CONFIG.VERSION);

    var payload = { name: 'ZOE', prompt: promptFinal, opening_text: '' };
    if (CONFIG.VOICE_ID)        payload.voice_id    = CONFIG.VOICE_ID;
    if (CONFIG.AVATAR_ID)       payload.avatar_id   = CONFIG.AVATAR_ID;
    if (CONFIG.AVATAR_LANGUAGE) payload.language    = CONFIG.AVATAR_LANGUAGE;
    if (CONFIG.WEBHOOK_URL)     payload.webhook_url = CONFIG.WEBHOOK_URL;
    // LLM personalizado — se mantiene activo en cada actualización del contexto
    var llmId = PropertiesService.getScriptProperties().getProperty('LA_LLM_CONFIG_ID');
    if (llmId) payload.llm_configuration_id = llmId;

    var res = UrlFetchApp.fetch(
      'https://api.liveavatar.com/v1/contexts/' + CONFIG.CONTEXT_ID,
      { method: 'PATCH', headers: { 'X-API-KEY': CONFIG.API_KEY, 'Content-Type': 'application/json' },
        payload: JSON.stringify(payload), muteHttpExceptions: true }
    );
    var code = res.getResponseCode();
    Logger.log(code === 200 ? 'LiveAvatar OK: ' + temporal.fecha : 'Error PATCH: ' + code + ' — ' + res.getContentText());
  } catch (e) { Logger.log('Error actualizarLiveAvatar: ' + e.message); }
}

// ================================================================
// CONTROL DE TURNO
// ================================================================

function esPreguntaCompleta(texto) {
  var t = texto.trim();
  if (/[.!?]$/.test(t)) return true;
  if (/^¿/.test(t) && !/\?$/.test(t)) return false;
  var palabras = t.split(/\s+/).filter(Boolean);
  if (palabras.length >= 6) return true;
  return false;
}

function _respuestaVacia() {
  return ContentService.createTextOutput(
    JSON.stringify({ ok: true, reply: null, speak: false })
  ).setMimeType(ContentService.MimeType.JSON);
}

// ================================================================
// WEBHOOK — FORMATO UNIFICADO
// Maneja dos formatos:
//   1. OpenAI /chat/completions — cuando LiveAvatar llama como LLM personalizado
//   2. Webhook normal — llamadas directas con { message, speaker, is_final }
// ================================================================

// Detecta si el request viene de LiveAvatar en formato OpenAI
function esRequestOpenAI(body) {
  return body && body.messages && Array.isArray(body.messages);
}

// Extrae el último mensaje del usuario del formato OpenAI
function extraerMensajeDeOpenAI(body) {
  var mensajes = body.messages || [];
  for (var i = mensajes.length - 1; i >= 0; i--) {
    if (mensajes[i].role === 'user' && mensajes[i].content) {
      return (mensajes[i].content || '').trim();
    }
  }
  return '';
}

// Respuesta en formato OpenAI para que LiveAvatar la entienda
function respuestaOpenAI(texto) {
  return ContentService.createTextOutput(JSON.stringify({
    id:      'chatcmpl-zoe-' + Date.now(),
    object:  'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model:   'gpt-4o-mini',
    choices: [{ index: 0, message: { role: 'assistant', content: texto || '' }, finish_reason: 'stop' }],
    usage:   { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
  })).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    var body = {};
    if (e && e.postData && e.postData.contents) body = JSON.parse(e.postData.contents);

    Logger.log('WEBHOOK — keys: ' + Object.keys(body).join(', '));

    // ── FORMATO LIVEAVATAR (OpenAI) ──────────────────────────────
    if (esRequestOpenAI(body)) {
      Logger.log('Formato OpenAI — viene de LiveAvatar');
      var msg = extraerMensajeDeOpenAI(body);
      Logger.log('Mensaje: "' + msg + '"');

      if (!msg || msg.length < 2) return respuestaOpenAI('');

      // Silencio si ZOE está hablando
      if (estaHablando()) {
        Logger.log('Speaking lock — silencio');
        return respuestaOpenAI('');
      }

      // Mensajes de espera no generan respuesta
      if (esMensajeDeEspera(msg)) {
        Logger.log('Mensaje de espera — silencio');
        return respuestaOpenAI('');
      }

      var respuesta = procesarMensaje(msg, body.user || 'Usuario');
      Logger.log('ZOE: "' + (respuesta || '[silencio]') + '"');

      if (respuesta && respuesta.trim().length > 0) {
        activarLockHablando(calcularSegundosHablando(respuesta));
      }

      return respuestaOpenAI(respuesta || '');
    }

    // ── FORMATO WEBHOOK NORMAL ───────────────────────────────────
    var mensaje  = body.message || body.text || '';
    var speaker  = body.speaker || 'Usuario';
    var esFinal  = body.is_final === true || body.final === true;
    var mensajeTrimmed = (mensaje || '').trim();

    Logger.log('Webhook normal — speaker: ' + speaker + ' | final: ' + esFinal + ' | msg: "' + mensajeTrimmed + '"');

    // Rechazar vacíos inmediatamente
    if (!mensajeTrimmed || mensajeTrimmed.length < 3) {
      if (!esFinal) return _respuestaVacia();
      return _respuestaVacia();
    }

    var soloLetras = mensajeTrimmed.replace(/[^a-zA-ZáéíóúüñÁÉÍÓÚÜÑ]/g, '');
    if (soloLetras.length < 2) {
      Logger.log('Ruido descartado: "' + mensajeTrimmed + '"');
      return _respuestaVacia();
    }

    if (!esFinal && mensajeTrimmed.split(/\s+/).length < 4) {
      Logger.log('Fragmento corto esperando más: "' + mensajeTrimmed + '"');
      return _respuestaVacia();
    }

    if (estaHablando()) {
      Logger.log('Speaking lock activo — descartando');
      return _respuestaVacia();
    }

    if (esMensajeDeEspera(mensajeTrimmed)) {
      Logger.log('Mensaje de espera — silencio: "' + mensajeTrimmed + '"');
      return _respuestaVacia();
    }

    if (!estaInterpeladaDirectamente(mensajeTrimmed)) {
      Logger.log('ZOE no interpelada — silencio activo.');
      return _respuestaVacia();
    }

    var cacheKey = 'turno_' + speaker.replace(/\s+/g, '_').toLowerCase();
    var ahora    = Date.now();

    if (!esFinal && !esPreguntaCompleta(mensajeTrimmed)) {
      _cache.put(cacheKey, JSON.stringify({ msg: mensajeTrimmed, ts: ahora }), 10);
      var debounceEfectivo = mensajeTrimmed.split(/\s+/).length > 10 ? 3500 : DEBOUNCE_MS;
      Utilities.sleep(debounceEfectivo);
      var cached = _cache.get(cacheKey);
      if (!cached) {
        Logger.log('Debounce: cache vacío, descartando');
        return _respuestaVacia();
      }
      var cacheParsed = JSON.parse(cached);
      if (cacheParsed.ts !== ahora) {
        Logger.log('Debounce: superado por mensaje más reciente');
        return _respuestaVacia();
      }
      mensajeTrimmed = cacheParsed.msg;
      _cache.remove(cacheKey);
      Logger.log('Debounce: procesando: "' + mensajeTrimmed + '"');
    } else {
      _cache.remove(cacheKey);
      Logger.log('Pregunta completa — procesando: "' + mensajeTrimmed + '"');
    }

    var respuesta = procesarMensaje(mensajeTrimmed, speaker);
    if (!respuesta || respuesta.trim() === '') return _respuestaVacia();

    activarLockHablando(calcularSegundosHablando(respuesta));

    Logger.log('Respuesta: ' + respuesta);
    return ContentService.createTextOutput(
      JSON.stringify({ ok: true, reply: respuesta, speak: true })
    ).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    Logger.log('ERROR doPost: ' + err);
    return ContentService.createTextOutput(
      JSON.stringify({ ok: false, error: err.message, reply: null, speak: false })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}
// ================================================================
// FIX-W: AUTO-REPARACIÓN — autoReparar() detecta y corrige fallas sola
// Se ejecuta cada 30min via trigger. Sin intervención humana.
// ================================================================

/**
 * DIAGNÓSTICO Y REPARACIÓN AUTOMÁTICA
 * Verifica 9 condiciones críticas del sistema. Si algo falla:
 *  1. Lo repara (si es reparable automáticamente)
 *  2. Lo registra en LogErrores con timestamp + descripción
 *  3. Si la falla es grave (LiveAvatar caído), fuerza actualización completa
 *
 * CONDICIONES VERIFICADAS:
 *  C1. Propiedades críticas presentes (OPENAI_KEY, API_KEY, CONTEXT_ID, SHEET_ID)
 *  C2. OpenAI responde (ping liviano con max_tokens=5)
 *  C3. LiveAvatar API responde (GET al context)
 *  C4. Sheets accesible y hojas requeridas presentes
 *  C5. Trigger de actualizarLiveAvatar activo (mínimo 1)
 *  C6. Trigger de autoReparar activo (se auto-recrea si falta)
 *  C7. Cache de memoria no corrompido (puede deserializarse)
 *  C8. RSS feeds accesibles (al menos 1 de 3)
 *  C9. Invitados del día correctamente cargados (si hay en Sheet)
 */
function autoReparar() {
  var errores = [];
  var reparados = [];
  var props = PropertiesService.getScriptProperties();
  Logger.log('=== AUTO-REPARACIÓN ' + CONFIG.VERSION + ' ===');

  // C1: Propiedades críticas
  var criticas = ['OPENAI_KEY', 'API_KEY', 'CONTEXT_ID', 'SHEET_ID'];
  var faltanProps = criticas.filter(function(k) { return !props.getProperty(k); });
  if (faltanProps.length > 0) {
    errores.push('C1_PROPS_FALTANTES: ' + faltanProps.join(', '));
    // No se puede auto-reparar — requiere intervención
    _registrarError('autoReparar', 'Propiedades críticas faltantes: ' + faltanProps.join(', '));
  }

  // C2: OpenAI responde
  try {
    var openaiKey = props.getProperty('OPENAI_KEY');
    if (openaiKey) {
      var pingRes = UrlFetchApp.fetch('https://api.openai.com/v1/chat/completions', {
        method: 'post',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + openaiKey },
        payload: JSON.stringify({
          model: CONFIG.OPENAI_MODEL,
          messages: [{ role: 'user', content: 'ok' }],
          max_tokens: 3
        }),
        muteHttpExceptions: true
      });
      var pingCode = pingRes.getResponseCode();
      if (pingCode !== 200 && pingCode !== 400) {
        // 400 es aceptable (puede ser model error), lo importante es que la API responde
        errores.push('C2_OPENAI_NO_RESPONDE: HTTP ' + pingCode);
        _registrarError('autoReparar', 'OpenAI HTTP ' + pingCode);
      } else {
        Logger.log('C2 OK — OpenAI responde (' + pingCode + ')');
      }
    }
  } catch (e) {
    errores.push('C2_OPENAI_EXCEPTION: ' + e.message);
    _registrarError('autoReparar', 'OpenAI exception: ' + e.message);
  }

  // C3: LiveAvatar API responde
  try {
    var apiKey     = props.getProperty('API_KEY');
    var contextId  = props.getProperty('CONTEXT_ID');
    if (apiKey && contextId) {
      var laRes = UrlFetchApp.fetch(
        'https://api.liveavatar.com/v1/contexts/' + contextId,
        { method: 'GET', headers: { 'X-API-KEY': apiKey }, muteHttpExceptions: true }
      );
      var laCode = laRes.getResponseCode();
      if (laCode !== 200) {
        errores.push('C3_LIVEAVATAR_CAIDO: HTTP ' + laCode);
        _registrarError('autoReparar', 'LiveAvatar HTTP ' + laCode);
        // Reparación: forzar re-push del prompt completo
        Logger.log('C3: LiveAvatar caído — forzando re-push...');
        try { forzarActualizacion(); reparados.push('C3_LIVEAVATAR_REPUSH'); } catch(e2) { /* silencio */ }
      } else {
        Logger.log('C3 OK — LiveAvatar responde');
      }
    }
  } catch (e) {
    errores.push('C3_LIVEAVATAR_EXCEPTION: ' + e.message);
    _registrarError('autoReparar', 'LiveAvatar exception: ' + e.message);
  }

  // C4: Sheets accesible + hojas requeridas
  try {
    var sheetId = props.getProperty('SHEET_ID');
    if (sheetId) {
      var ss = SpreadsheetApp.openById(sheetId);
      var hojasRequeridas = ['ArchivoConversacionesZoe', 'Memoria', 'Invitados', 'LogMantenimiento', 'LogErrores'];
      var hojasAusentes = hojasRequeridas.filter(function(n) { return !ss.getSheetByName(n); });
      if (hojasAusentes.length > 0) {
        errores.push('C4_HOJAS_AUSENTES: ' + hojasAusentes.join(', '));
        // Reparación: crear las hojas faltantes
        Logger.log('C4: creando hojas faltantes: ' + hojasAusentes.join(', '));
        verificarHojasExisten();
        reparados.push('C4_HOJAS_RECREADAS: ' + hojasAusentes.join(', '));
      } else {
        Logger.log('C4 OK — Sheets y hojas accesibles');
      }
    }
  } catch (e) {
    errores.push('C4_SHEETS_EXCEPTION: ' + e.message);
    _registrarError('autoReparar', 'Sheets exception: ' + e.message);
  }

  // C5: Trigger actualizarLiveAvatar activo (mínimo 1)
  var triggers = ScriptApp.getProjectTriggers();
  var tieneAvatar = triggers.some(function(t) {
    return t.getHandlerFunction() === 'actualizarLiveAvatar';
  });
  if (!tieneAvatar) {
    errores.push('C5_TRIGGER_AVATAR_AUSENTE');
    Logger.log('C5: trigger actualizarLiveAvatar ausente — recreando...');
    // Reparación: recrear triggers completos
    configurarTriggers();
    reparados.push('C5_TRIGGERS_RECREADOS');
  } else {
    Logger.log('C5 OK — trigger actualizarLiveAvatar activo');
  }

  // C6: Trigger autoReparar activo (se auto-recrea)
  var tieneAutoReparar = ScriptApp.getProjectTriggers().some(function(t) {
    return t.getHandlerFunction() === 'autoReparar';
  });
  if (!tieneAutoReparar) {
    errores.push('C6_TRIGGER_AUTOREPARAR_AUSENTE');
    Logger.log('C6: trigger autoReparar ausente — recreando...');
    ScriptApp.newTrigger('autoReparar').timeBased().everyMinutes(30).create();
    reparados.push('C6_TRIGGER_AUTOREPARAR_RECREADO');
  } else {
    Logger.log('C6 OK — trigger autoReparar activo');
  }

  // C7: Cache de memoria no corrompido
  try {
    var memoriaCache = CacheService.getScriptCache().get('memoria_zoe');
    if (memoriaCache) {
      var tieneInicio = memoriaCache.indexOf(MARCADORES.MEMORIA_INICIO) !== -1;
      var tieneFin    = memoriaCache.indexOf(MARCADORES.MEMORIA_FIN) !== -1;
      if (!tieneInicio || !tieneFin) {
        errores.push('C7_CACHE_MEMORIA_CORROMPIDO');
        Logger.log('C7: cache memoria corrompido — limpiando...');
        CacheService.getScriptCache().remove('memoria_zoe');
        reparados.push('C7_CACHE_MEMORIA_LIMPIADO');
      } else {
        Logger.log('C7 OK — cache memoria íntegro');
      }
    } else {
      Logger.log('C7 OK — cache memoria vacío (se recargará en próxima consulta)');
    }
  } catch (e) {
    errores.push('C7_CACHE_EXCEPTION: ' + e.message);
    CacheService.getScriptCache().remove('memoria_zoe');
  }

  // C8: RSS feeds — al menos 1 accesible
  try {
    var feedKeys = Object.keys(FEEDS_RSS);
    var algunFeedOk = false;
    for (var f = 0; f < Math.min(feedKeys.length, 2); f++) {
      try {
        var rssRes = UrlFetchApp.fetch(FEEDS_RSS[feedKeys[f]], {
          muteHttpExceptions: true,
          headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        if (rssRes.getResponseCode() === 200) { algunFeedOk = true; break; }
      } catch(fe) { /* continúa con el siguiente */ }
    }
    if (!algunFeedOk) {
      errores.push('C8_RSS_TODOS_CAIDOS');
      _registrarError('autoReparar', 'Todos los feeds RSS inaccesibles');
      // Limpiar cache para forzar re-fetch cuando vuelvan
      for (var cat in FEEDS_RSS) {
        CacheService.getScriptCache().remove('rss_' + cat.replace(/\s+/g,'_'));
      }
      reparados.push('C8_RSS_CACHE_LIMPIADO');
    } else {
      Logger.log('C8 OK — al menos un feed RSS accesible');
    }
  } catch (e) {
    errores.push('C8_RSS_EXCEPTION: ' + e.message);
  }

  // C9: Invitados del día — si hay rows para hoy, el cache debe poder cargarse
  try {
    var invCache = CacheService.getScriptCache().get('invitados_hoy');
    if (invCache && invCache !== '__vacio__') {
      var tieneInicioInv = invCache.indexOf(MARCADORES.INVITADOS_INICIO) !== -1;
      if (!tieneInicioInv) {
        errores.push('C9_CACHE_INVITADOS_CORROMPIDO');
        CacheService.getScriptCache().remove('invitados_hoy');
        reparados.push('C9_CACHE_INVITADOS_LIMPIADO');
        Logger.log('C9: cache invitados corrompido — limpiado');
      } else {
        Logger.log('C9 OK — cache invitados íntegro');
      }
    } else {
      Logger.log('C9 OK — cache invitados vacío o centinela');
    }
  } catch (e) {
    errores.push('C9_INVITADOS_EXCEPTION: ' + e.message);
    CacheService.getScriptCache().remove('invitados_hoy');
  }

  // ── Resumen ──────────────────────────────────────────────────
  var hayFallas = errores.length > 0;
  Logger.log('AUTO-REPARACIÓN COMPLETA: ' +
    (hayFallas ? errores.length + ' errores detectados' : 'TODO OK') +
    (reparados.length > 0 ? ' | Reparados: ' + reparados.join(', ') : ''));

  // Registrar resumen en LogMantenimiento si hubo actividad
  if (hayFallas || reparados.length > 0) {
    try {
      var ss2  = SpreadsheetApp.openById(CONFIG.SHEET_ID);
      var logH = ss2.getSheetByName('LogMantenimiento');
      if (logH) {
        var resumen = (hayFallas ? 'ERRORES: ' + errores.join(' | ') : 'OK') +
          (reparados.length ? ' | REPARADOS: ' + reparados.join(' | ') : '');
        logH.appendRow([new Date(), 'autoReparar ' + CONFIG.VERSION, resumen]);
      }
    } catch(e) { /* silencio — no queremos que el log rompa la reparación */ }
  }
}

// Utilidad interna para registrar errores en LogErrores
function _registrarError(funcion, descripcion) {
  try {
    var ss = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var logE = ss.getSheetByName('LogErrores');
    if (logE) logE.appendRow([new Date(), funcion, descripcion]);
  } catch(e) { Logger.log('_registrarError falló: ' + e.message); }
}

// ================================================================
// TRIGGERS
// ================================================================

function configurarTriggers() {
  ScriptApp.getProjectTriggers().forEach(function(t) { ScriptApp.deleteTrigger(t); });
  // Actualización del contexto del avatar (horario de programa)
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(11).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(12).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(13).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(14).create();
  ScriptApp.newTrigger('actualizarLiveAvatar').timeBased().everyDays(1).atHour(15).create();
  // Mantenimiento semanal
  ScriptApp.newTrigger('mantenimientoSemanal').timeBased().onWeekDay(ScriptApp.WeekDay.SUNDAY).atHour(6).create();
  // FIX-W: auto-reparación cada 30 minutos — sin intervención humana
  ScriptApp.newTrigger('autoReparar').timeBased().everyMinutes(30).create();
  Logger.log('Triggers configurados: ' + ScriptApp.getProjectTriggers().length + ' (incluye autoReparar cada 30min)');
}

// ================================================================
// PROPIEDADES
// ================================================================

function cargarPropiedades() {
  var props = PropertiesService.getScriptProperties();
  props.setProperties({
    'OPENAI_KEY':      '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',
    'BRAVE_API_KEY':   'BSABBxFDdPqV-TqDd5y5mp9vXbdiBWh',
    'API_KEY':         '26cc47aa-3766-11f1-8d28-066a7fa2e369',
    'CONTEXT_ID':      '24db1a18-7249-4009-89fe-319456b1ab37',
    'SHEET_ID':        '1gr3641Z-7FL-nStWbo0F_JfSQH_JiAfoAzr-TFbInrk',
    'VOICE_ID':        '30964c85-58f6-4379-9370-fdb90faae574',
    'AVATAR_ID':       '9fc5b8d5-0ded-48ec-861d-80d45138360e',
    'AVATAR_LANGUAGE': 'es',
    'WEBHOOK_URL':     'https://script.google.com/macros/s/AKfycbzUj0XIi3qfUetPRyACs8kWu6JBGMhTGduPEjjjo7hr4pmEpMSU-GoHxUNuoGeM2lfM/exec'
  });
  Logger.log('Propiedades cargadas OK');
}

function actualizarWebhook() {
  PropertiesService.getScriptProperties().setProperty('WEBHOOK_URL', 'https://script.google.com/macros/s/AKfycbzUj0XIi3qfUetPRyACs8kWu6JBGMhTGduPEjjjo7hr4pmEpMSU-GoHxUNuoGeM2lfM/exec');
  Logger.log('Webhook actualizado OK');
}

// ================================================================
// MANTENIMIENTO
// ================================================================

function limpiarCache() {
  var c = CacheService.getScriptCache();
  for (var cat in FEEDS_RSS) c.remove('rss_' + cat.replace(/\s+/g,'_'));
  c.remove('memoria_zoe');
  c.remove('conversaciones_hoy');
  // FIX-V84: limpiar cache de invitados para que forzarActualizacion() recargue
  // los nuevos invitados del dia desde la Sheet inmediatamente
  c.remove('invitados_hoy');
  Logger.log('Cache limpiado (memoria + conversaciones + invitados + RSS)');
}

function forzarActualizacion() { limpiarCache(); actualizarLiveAvatar(); }

function mantenimientoSemanal() {
  Logger.log('MANTENIMIENTO ' + CONFIG.VERSION);
  try {
    if (!CONFIG.SHEET_ID) return;
    var ss   = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var hoja = ss.getSheetByName('ArchivoConversacionesZoe');
    if (hoja) { var n = hoja.getLastRow(); if (n > 500) hoja.deleteRows(2, n - 300); }
    limpiarCache();
    actualizarLiveAvatar();
    var log = ss.getSheetByName('LogMantenimiento');
    if (log) log.appendRow([new Date(), 'Mantenimiento ' + CONFIG.VERSION, 'OK']);
  } catch (e) { Logger.log('Error mantenimiento: ' + e); }
}

// ================================================================
// HOJAS
// ================================================================

function verificarHojasExisten() {
  if (!CONFIG.SHEET_ID) { Logger.log('ERROR: Sin SHEET_ID'); return; }
  var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
  var hojas = {
    'ArchivoConversacionesZoe': ['Timestamp','Speaker','Mensaje','Respuesta'],
    'Memoria':          ['Fecha','Episodio','Nombre','Rol o Empresa','Temas tratados','Ideas clave'],
    'Invitados':        ['Fecha','Nombre','Empresa','Rol','Logros','Contexto','Tensión'],
    'LogMantenimiento': ['Timestamp','Acción','Status'],
    'LogErrores':       ['Timestamp','Función','Error']
  };
  for (var nombre in hojas) {
    var hoja = ss.getSheetByName(nombre);
    if (!hoja) {
      hoja = ss.insertSheet(nombre);
      hoja.appendRow(hojas[nombre]);
      hoja.setFrozenRows(1);
      Logger.log('Hoja creada: ' + nombre);
    } else {
      Logger.log('Hoja OK: ' + nombre);
    }
  }
}

function agregarInvitadoDelDia() {
  var FECHA    = '2026-05-10';
  var NOMBRE   = 'Juan Perez';
  var EMPRESA  = 'TechStartup LATAM';
  var ROL      = 'CEO y Fundador';
  var LOGROS   = 'Levantó 5 millones de dólares y escaló a 10 países en 2 años';
  var CONTEXTO = 'Pionero en IA aplicada a logística en Argentina';
  var TENSION  = '¿Cómo compites contra gigantes globales siendo una startup local?';
  if (!CONFIG.SHEET_ID) { Logger.log('ERROR: Sin SHEET_ID'); return; }
  try {
    var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
    var sheet = ss.getSheetByName('Invitados');
    if (!sheet) {
      sheet = ss.insertSheet('Invitados');
      sheet.appendRow(['Fecha','Nombre','Empresa','Rol','Logros','Contexto','Tensión']);
      sheet.setFrozenRows(1);
    }
    sheet.appendRow([new Date(FECHA), NOMBRE, EMPRESA, ROL, LOGROS, CONTEXTO, TENSION]);
    Logger.log('Invitado agregado. Ejecutá forzarActualizacion() después.');
  } catch (e) { Logger.log('Error: ' + e.message); }
}

function cargarMemoriaEpisodios() {
  Logger.log('=== INICIANDO cargarMemoriaEpisodios ===');
  if (!CONFIG.SHEET_ID) { Logger.log('ERROR: Sin SHEET_ID'); return; }
  var ss    = SpreadsheetApp.openById(CONFIG.SHEET_ID);
  var sheet = ss.getSheetByName('Memoria');
  if (!sheet) {
    sheet = ss.insertSheet('Memoria');
    sheet.appendRow(['Fecha','Episodio','Nombre','Rol o Empresa','Temas tratados','Ideas clave']);
    sheet.setFrozenRows(1);
  }
  var episodios = [
    [new Date('2026-05-07'),'Martes Ciencia y Biotecnología','Iván Stigliano','Detección temprana enfermedades, IA en salud, futuro medicina','Iván Stigliano analizó innovaciones en detección temprana y tecnologías que transforman la medicina.'],
    [new Date('2026-05-06'),'Viernes Startups','Estudiantes Colegio Pestalozzi o Iván Gauna o Airglow Lab','Talento joven, IA y política, startup climate-tech','Tres estudiantes llegaron a la final de Jugend forscht en Europa. Iván Gauna: tecnopoder vs tecnohumanismo.'],
    [new Date('2026-05-05'),'Lunes Empresarios','Guibert Englebienne','Emprendimiento global, IA, tecnología y educación, Globant','Cofundador de Globant. Preside Endeavor Argentina.'],
    [new Date('2026-05-01'),'Jueves Sociedad y Cultura','LUMI-7 o Constanza Patiño o Hernán Casciari','Música IA, innovación en deporte, cultura y comunidad','LUMI-7: primera artista musical IA de Argentina.'],
    [new Date('2026-04-30'),'Miércoles Innovación Local','TUMO Buenos Aires o Inés Reineke','Educación tecnológica jóvenes, política pública primera infancia Uruguay','TUMO Buenos Aires: modelo educativo para jóvenes 12-18.'],
    [new Date('2026-04-28'),'Entrevista especial Melina','Hernán Casciari','Emprendimiento cultural, autogestión, comunidad, narrativa','Fundó revista Orsai sin publicidad. 3 películas producidas con comunidad.'],
    [new Date('2026-04-24'),'Jueves Sociedad y Cultura','Patricio Ovalle Wood o Enrique Avogadro o ZOE','Cultura como motor de desarrollo, ecosistemas creativos, IA en educación','ZOE presentada como primera profesora IA de Latinoamérica.'],
    [new Date('2026-04-23'),'Miércoles Innovación Local','BachIA Tucumán o Inés Reineke','IA para infraestructura urbana, gestión pública innovadora Chile','BachIA: IA desarrollada por jóvenes en Tucumán para detectar baches.'],
    [new Date('2026-04-22'),'Entrevista especial','Santiago Bilinkis','Inteligencia artificial, emprendimiento, tecnología, futuro','Cofundador de Officenet. Autor de libros sobre IA.']
  ];
  var cargados = 0;
  episodios.forEach(function(ep) { sheet.appendRow(ep); cargados++; });
  _cache.remove('memoria_zoe');
  Logger.log('Total episodios cargados: ' + cargados);
}

function configuracionInicial() {
  Logger.log('CONFIGURACIÓN INICIAL ZOE ' + CONFIG.VERSION);
  verificarHojasExisten();
  actualizarLiveAvatar();
  testSistemaCompleto();
}

function verificarConfiguracionCompleta() {
  var props = PropertiesService.getScriptProperties();
  Logger.log('=== ZOE ' + CONFIG.VERSION + ' ===');
  ['OPENAI_KEY','BRAVE_API_KEY','API_KEY','CONTEXT_ID','SHEET_ID','VOICE_ID','AVATAR_ID','AVATAR_LANGUAGE'].forEach(function(k) {
    Logger.log(k + ': ' + (props.getProperty(k) ? 'OK' : 'FALTA'));
  });
  ScriptApp.getProjectTriggers().forEach(function(t) { Logger.log('Trigger: ' + t.getHandlerFunction()); });
  forzarActualizacion();
}

function testRSS() {
  var titulares = obtenerTitularesRSS();
  Logger.log('Total titulares: ' + titulares.length);
  titulares.forEach(function(t) { Logger.log(t); });
}

// ================================================================
// TESTS COMPLETOS v83
// ================================================================

function testSistemaCompleto() {
  Logger.log('======= TEST ZOE ' + CONFIG.VERSION + ' =======');
  var tests = [];

  // ── GRUPO 1: mencionaAZoe ─────────────────────────────────────
  tests.push({ n: 'mencionaAZoe: zona → false',  ok: !mencionaAZoe('zona de trabajo') });
  tests.push({ n: 'mencionaAZoe: zoo → false',   ok: !mencionaAZoe('zoológico') });
  tests.push({ n: 'mencionaAZoe: Zoe → true',    ok:  mencionaAZoe('Zoe, qué opinas?') });
  tests.push({ n: 'mencionaAZoe: Zoé → true',    ok:  mencionaAZoe('Zoé, cuéntanos') });

  // ── GRUPO 2: splitOraciones ───────────────────────────────────
  tests.push({ n: 'split: 2 normales',           ok: splitOraciones('La IA creció. Yo creo que es positivo.').length === 2 });
  tests.push({ n: 'split: sin punto → 1',        ok: splitOraciones('Esto es una oración').length === 1 });
  tests.push({ n: 'split: EE.UU. no corta',      ok: splitOraciones('En EE.UU. la startup creció. Es replicable.').length === 2 });

  // ── GRUPO 3: sanitizarRespuesta ───────────────────────────────
  var s1 = sanitizarRespuesta('Gran pregunta. La IA es clave. Estoy aquí para ayudarte.');
  tests.push({ n: 'sanit: gran pregunta fuera',      ok: s1.toLowerCase().indexOf('gran pregunta') === -1 });
  tests.push({ n: 'sanit: ayudarte fuera',           ok: s1.toLowerCase().indexOf('estoy aquí para ayudarte') === -1 });

  var s2 = sanitizarRespuesta('Hay tres razones:\n1. La primera.\n2. La segunda.\n3. La tercera.');
  tests.push({ n: 'sanit: lista numerada fuera',     ok: !/\b1\./.test(s2) });

  var s3 = sanitizarRespuesta('Puntos:\n- Innovación\n- Emprendimiento\n- IA');
  tests.push({ n: 'sanit: viñetas fuera',            ok: s3.indexOf('- ') === -1 });

  var s4 = sanitizarRespuesta('El gobierno anunció que el país va a crecer un cuatro por ciento.');
  tests.push({ n: 'sanit: noticia real conservada',  ok: s4.length > 20 });

  var s5 = sanitizarRespuesta('Podés leer en https://malditos.com. La innovación es clave.');
  tests.push({ n: 'sanit: URL fuera',                ok: s5.indexOf('https://') === -1 });

  var s6 = sanitizarRespuesta('Google &amp; Amazon lideran.');
  tests.push({ n: 'sanit: &amp; → y',               ok: s6.indexOf('y Amazon') !== -1 });

  var s7 = sanitizarRespuesta('Lo que me estás preguntando sobre la IA es relevante. La verdad es que los modelos crecen.');
  tests.push({ n: 'sanit: eco espejo fuera',         ok: s7.toLowerCase().indexOf('lo que me estás preguntando') === -1 });

  var s8 = sanitizarRespuesta('Honestamente, el dato es contundente. Ante cualquier duda, estoy disponible.');
  tests.push({ n: 'sanit: ante cualquier duda fuera',ok: s8.toLowerCase().indexOf('ante cualquier duda') === -1 });

  var s9 = sanitizarRespuesta('Buena observación. Las startups de IA en Latam levantan más capital.');
  tests.push({ n: 'sanit: buena observacion fuera',  ok: s9.toLowerCase().indexOf('buena observación') === -1 });
  tests.push({ n: 'sanit: contenido real conservado',ok: s9.toLowerCase().indexOf('latam') !== -1 || s9.length > 15 });

  var s10 = sanitizarRespuesta('Lo cierto es que la IA en salud transforma todo. Me parece que veremos resultados en dos años.');
  tests.push({ n: 'sanit: conectores humanos NO eliminados', ok: s10.toLowerCase().indexOf('lo cierto') !== -1 || s10.toLowerCase().indexOf('me parece') !== -1 });

  var s11 = sanitizarRespuesta('Es un placer. La innovación abierta en Latam creció. Mi visión es que el ritmo no para.');
  tests.push({ n: 'sanit: es un placer fuera',       ok: s11.toLowerCase().indexOf('es un placer') === -1 });
  tests.push({ n: 'sanit: contenido post-bot conservado', ok: s11.toLowerCase().indexOf('latam') !== -1 || s11.toLowerCase().indexOf('visión') !== -1 });

  // ── GRUPO 4: parsearEdad ──────────────────────────────────────
  tests.push({ n: 'edad: 2h < 1d',           ok: parsearEdad('2h') < parsearEdad('1d') });
  tests.push({ n: 'edad: 1d < 1w',           ok: parsearEdad('1d') < parsearEdad('1w') });
  tests.push({ n: 'edad: null → 999999',     ok: parsearEdad(null) === 999999 });

  // ── GRUPO 5: esPreguntaCompleta ───────────────────────────────
  tests.push({ n: 'turno: punto final → ok',      ok:  esPreguntaCompleta('Zoe qué opinas de la IA.') });
  tests.push({ n: 'turno: signo pregunta → ok',   ok:  esPreguntaCompleta('Zoe qué opinas?') });
  tests.push({ n: 'turno: 6 palabras → ok',       ok:  esPreguntaCompleta('Zoe contanos sobre los startups argentinos') });
  tests.push({ n: 'turno: pocas palabras → no',   ok: !esPreguntaCompleta('Zoe,') });
  tests.push({ n: 'turno: ¿ sin cierre → no',     ok: !esPreguntaCompleta('¿Zoe qué') });

  // ── GRUPO 6: obtenerContextoTemporal ─────────────────────────
  var t = obtenerContextoTemporal();
  tests.push({ n: 'hora: tiene valor',        ok: t.hora && t.hora.length > 0 });
  tests.push({ n: 'hora: formato HH:MM',      ok: /^\d{1,2}:\d{2}$/.test(t.hora) });
  tests.push({ n: 'fecha: tiene valor',       ok: t.fecha && t.fecha.length > 5 });
  tests.push({ n: 'config: tokens >= 260',    ok: CONFIG.MAX_TOKENS_RESPUESTA >= 260 });

  // ── GRUPO 7: detecciones ──────────────────────────────────────
  tests.push({ n: 'saludo: "hola zoe" → true',        ok:  esSoloSaludo('hola zoe') });
  tests.push({ n: 'saludo: pregunta → false',          ok: !esSoloSaludo('Zoe qué pensás de la IA?') });
  tests.push({ n: 'despedida: chau → true',            ok:  esDespedida('chau Zoe') });
  tests.push({ n: 'despedida: pregunta → false',       ok: !esDespedida('Zoe qué opinás?') });
  tests.push({ n: 'presentacion: "les habla Ramiro"',  ok:  detectarPresentacion('Zoe, les habla Ramiro') === 'Ramiro' });
  tests.push({ n: 'presentacion: sin patron → null',   ok:  detectarPresentacion('hola Zoe') === null });

  // ── GRUPO 8: estaInterpeladaDirectamente (FIX-Y) ─────────────
  tests.push({ n: 'interp: "Zoe, qué pensás?" → true',          ok:  estaInterpeladaDirectamente('Zoe, qué pensás?') });
  tests.push({ n: 'interp: "Zoe, cuál es tu opinión?" → true',  ok:  estaInterpeladaDirectamente('Zoe, cuál es tu opinión?') });
  tests.push({ n: 'interp: "Zoe, qué pasó?" → true',            ok:  estaInterpeladaDirectamente('Zoe, qué pasó con el dólar?') });
  tests.push({ n: 'interp: "Zoe, dale" → true',                 ok:  estaInterpeladaDirectamente('Zoe, dale') });
  tests.push({ n: 'interp: "Zoe, contanos" → true',             ok:  estaInterpeladaDirectamente('Zoe, contanos') });
  tests.push({ n: 'interp: "qué pensás, Zoe?" → true',          ok:  estaInterpeladaDirectamente('qué pensás, Zoe?') });
  tests.push({ n: 'interp: "qué dice Zoe?" → true',             ok:  estaInterpeladaDirectamente('qué dice Zoe de esto?') });
  tests.push({ n: 'interp: "Zoe, tu visión?" → true',           ok:  estaInterpeladaDirectamente('Zoe, tu visión?') });
  tests.push({ n: 'interp: "Zoé, cómo lo ves?" → true',         ok:  estaInterpeladaDirectamente('Zoé, cómo lo ves?') });
  tests.push({ n: 'interp: "Zoe dijo que..." → false',          ok: !estaInterpeladaDirectamente('Zoe dijo que el ecosistema crece.') });
  tests.push({ n: 'interp: "Zoe es increíble" → false',         ok: !estaInterpeladaDirectamente('Zoe es increíble') });
  tests.push({ n: 'interp: "escuchaste a Zoe?" → false',        ok: !estaInterpeladaDirectamente('Melina, ¿escuchaste a Zoe?') });
  tests.push({ n: 'interp: "lo que dijo Zoe" → false',          ok: !estaInterpeladaDirectamente('Joaco, lo que dijo Zoe ayer fue clave.') });
  tests.push({ n: 'interp: sin mención → false',                ok: !estaInterpeladaDirectamente('Melina, qué pensás del mercado?') });
  tests.push({ n: 'interp: "zona" → false',                     ok: !estaInterpeladaDirectamente('la zona de startups creció') });

  // ── GRUPO 9: esConsultaEditorial (FIX-X) ─────────────────────
  tests.push({ n: 'asesor: "qué mejorarías" → true',    ok:  esConsultaEditorial('Zoe, qué mejorarías del programa?') });
  tests.push({ n: 'asesor: "qué temas faltan" → true',  ok:  esConsultaEditorial('Zoe, qué temas faltan en malditos?') });
  tests.push({ n: 'asesor: "consejo para" → true',      ok:  esConsultaEditorial('Zoe, algún consejo para malditos?') });
  tests.push({ n: 'asesor: "qué cambiarías" → true',    ok:  esConsultaEditorial('Zoe qué cambiarías del formato?') });
  tests.push({ n: 'asesor: saludo → false',              ok: !esConsultaEditorial('Hola Zoe cómo estás?') });
  tests.push({ n: 'asesor: noticia → false',             ok: !esConsultaEditorial('Zoe qué pasó con el dólar?') });

  // ── GRUPO 10: config y funciones v85-v87 ──────────────────────
  tests.push({ n: 'v85: autoReparar existe',          ok: typeof autoReparar === 'function' });
  tests.push({ n: 'v85: _registrarError existe',      ok: typeof _registrarError === 'function' });
  tests.push({ n: 'v85: BLOQUE_ASESOR tiene marcador',ok: BLOQUE_ASESOR.indexOf('##MODO_ASESOR_EDITORIAL##') !== -1 });
  tests.push({ n: 'v87: MAX_CONV_HOY <= 3',           ok: CONFIG.MAX_CONV_HOY <= 3 });
  tests.push({ n: 'v87: MAX_CONV_CHARS_Q <= 60',      ok: CONFIG.MAX_CONV_CHARS_Q <= 60 });
  tests.push({ n: 'v87: MAX_CONV_CHARS_R <= 100',     ok: CONFIG.MAX_CONV_CHARS_R <= 100 });
  tests.push({ n: 'v87: leerConversacionesHoy acepta param', ok: typeof leerConversacionesHoy('test') === 'string' });

  // ── GRUPO 11: procesarMensaje (solo casos sin API) ────────────
  tests.push({ n: 'procesar: presentacion Ramiro',  ok: procesarMensaje('Zoe, les habla Ramiro', 'Ramiro') === 'Ramiro.' });
  tests.push({ n: 'procesar: saludo corto',         ok: procesarMensaje('Hola Zoe', 'Melina').length < 60 });
  tests.push({ n: 'procesar: sin Zoe → vacio',      ok: procesarMensaje('Contame algo', 'Melina') === '' });
  tests.push({ n: 'procesar: pasivo → vacio',       ok: procesarMensaje('Joaco, lo que dijo Zoe fue clave', 'Melina') === '' });

  // ── RESULTADO ─────────────────────────────────────────────────
  var score = 0;
  tests.forEach(function(test) {
    Logger.log((test.ok ? 'OK  ' : 'FAIL') + ' — ' + test.n);
    if (test.ok) score++;
  });
  Logger.log('');
  Logger.log('SCORE: ' + score + '/' + tests.length + ' — ZOE ' + CONFIG.VERSION);
  if (score === tests.length) {
    Logger.log('TODOS LOS TESTS PASARON');
  } else {
    Logger.log('TESTS FALLIDOS: ' + (tests.length - score));
  }
}
/**
 * ================================================================
 * ZOE — SETUP LIVEAVATAR CUSTOM LLM
 * ================================================================
 * PEGÁ ESTE BLOQUE AL FINAL DE TU CÓDIGO EXISTENTE (zoe_v87.js)
 *
 * QUÉ HACE:
 * Conecta LiveAvatar directamente con el webhook de GAS como LLM.
 * Así el avatar espera la respuesta de ZOE antes de hablar,
 * eliminando el problema de dos respuestas compitiendo.
 *
 * PASOS:
 * 1. Pegá este bloque al final del código
 * 2. Ejecutá configurarLLMPersonalizado() UNA SOLA VEZ
 * 3. Listo — el avatar ya usa ZOE como su LLM
 * ================================================================
 */

// ================================================================
// CONFIGURACIÓN LLM PERSONALIZADO PARA LIVEAVATAR
// ================================================================

var LA_BASE_URL = 'https://api.liveavatar.com';

/**
 * PASO 1 de 3: Registrar la OpenAI key en LiveAvatar
 * LiveAvatar la guarda cifrada con Amazon KMS.
 * Devuelve un secret_id que usamos en el paso 2.
 */
function registrarSecretEnLiveAvatar() {
  var openaiKey = PropertiesService.getScriptProperties().getProperty('OPENAI_KEY');
  var apiKey    = PropertiesService.getScriptProperties().getProperty('API_KEY');

  if (!openaiKey || !apiKey) {
    Logger.log('ERROR: Falta OPENAI_KEY o API_KEY en ScriptProperties');
    return null;
  }

  var res = UrlFetchApp.fetch(LA_BASE_URL + '/v1/secrets', {
    method: 'post',
    headers: {
      'X-API-KEY':    apiKey,
      'Content-Type': 'application/json'
    },
    payload: JSON.stringify({
      secret_type:  'OPENAI_API_KEY',
      secret_value: openaiKey,
      secret_name:  'ZOE OpenAI Key'
    }),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Registrar secret: HTTP ' + code);
  Logger.log(JSON.stringify(data));

  if (code === 200 && data.data && data.data.id) {
    var secretId = data.data.id;
    Logger.log('SECRET ID: ' + secretId);
    // Guardarlo para no tener que registrarlo de nuevo
    PropertiesService.getScriptProperties().setProperty('LA_SECRET_ID', secretId);
    return secretId;
  }

  Logger.log('ERROR registrando secret: ' + JSON.stringify(data));
  return null;
}

/**
 * PASO 2 de 3: Crear configuración LLM que apunta al webhook de GAS
 * LiveAvatar llama a este endpoint como si fuera OpenAI.
 * GAS responde con la respuesta de ZOE.
 * Devuelve un llm_configuration_id que usamos en el paso 3.
 */
function crearConfiguracionLLM(secretId) {
  var apiKey      = PropertiesService.getScriptProperties().getProperty('API_KEY');
  var webhookUrl  = PropertiesService.getScriptProperties().getProperty('WEBHOOK_URL');

  if (!secretId) {
    secretId = PropertiesService.getScriptProperties().getProperty('LA_SECRET_ID');
  }

  if (!apiKey || !webhookUrl || !secretId) {
    Logger.log('ERROR: Falta API_KEY, WEBHOOK_URL o LA_SECRET_ID');
    return null;
  }

  // El base_url debe ser la raíz del endpoint compatible con OpenAI
  // LiveAvatar le agrega /chat/completions automáticamente
  // GAS necesita manejar ese path — usamos el webhook URL base
  var baseUrl = webhookUrl.replace('/exec', '');

  var res = UrlFetchApp.fetch(LA_BASE_URL + '/v1/llm-configurations', {
    method: 'post',
    headers: {
      'X-API-KEY':    apiKey,
      'Content-Type': 'application/json'
    },
    payload: JSON.stringify({
      display_name: 'ZOE v87 GAS',
      model_name:   'gpt-4o-mini',
      secret_id:    secretId,
      base_url:     webhookUrl  // LiveAvatar llama directamente al webhook
    }),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Crear LLM config: HTTP ' + code);
  Logger.log(JSON.stringify(data));

  if (code === 200 && data.data && data.data.id) {
    var llmConfigId = data.data.id;
    Logger.log('LLM CONFIG ID: ' + llmConfigId);
    PropertiesService.getScriptProperties().setProperty('LA_LLM_CONFIG_ID', llmConfigId);
    return llmConfigId;
  }

  Logger.log('ERROR creando LLM config: ' + JSON.stringify(data));
  return null;
}

/**
 * PASO 3 de 3: Actualizar el contexto de ZOE en LiveAvatar
 * Le dice al avatar que use el LLM personalizado (GAS) en vez del de LiveAvatar.
 * También actualiza el prompt con la identidad de ZOE.
 */
function actualizarContextoConLLM(llmConfigId) {
  var apiKey    = PropertiesService.getScriptProperties().getProperty('API_KEY');
  var contextId = PropertiesService.getScriptProperties().getProperty('CONTEXT_ID');

  if (!llmConfigId) {
    llmConfigId = PropertiesService.getScriptProperties().getProperty('LA_LLM_CONFIG_ID');
  }

  if (!apiKey || !contextId || !llmConfigId) {
    Logger.log('ERROR: Falta API_KEY, CONTEXT_ID o LA_LLM_CONFIG_ID');
    return false;
  }

  // Prompt corto — el prompt completo lo maneja GAS dinámicamente
  var promptBase =
    'Sos ZOE, co-conductora IA de Malditos Optimistas. ' +
    'Hablás en español latino neutro, directo y con opinión propia. ' +
    'Respondés solo cuando te interpelan directamente. ' +
    'Máximo 3 oraciones por respuesta. Sin listas, sin URLs, sin frases de bot.';

  var res = UrlFetchApp.fetch(LA_BASE_URL + '/v1/contexts/' + contextId, {
    method: 'PATCH',
    headers: {
      'X-API-KEY':    apiKey,
      'Content-Type': 'application/json'
    },
    payload: JSON.stringify({
      name:         'ZOE v87',
      prompt:       promptBase,
      opening_text: '.',
      llm_configuration_id: llmConfigId
    }),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Actualizar contexto: HTTP ' + code);

  if (code === 200) {
    Logger.log('CONTEXTO ACTUALIZADO — ZOE ahora usa el LLM personalizado (GAS)');
    return true;
  }

  Logger.log('ERROR actualizando contexto: ' + JSON.stringify(data));
  return false;
}

/**
 * FUNCIÓN PRINCIPAL — ejecutá esta UNA SOLA VEZ
 * Hace los 3 pasos en secuencia.
 * Si algo falla, te dice exactamente qué fue.
 */
function configurarLLMPersonalizado() {
  Logger.log('=== CONFIGURANDO LLM PERSONALIZADO PARA LIVEAVATAR ===');
  Logger.log('Paso 1/3: Registrando OpenAI key en LiveAvatar...');

  var secretId = registrarSecretEnLiveAvatar();
  if (!secretId) {
    Logger.log('FALLO en Paso 1. Revisá los logs.');
    return;
  }
  Logger.log('Paso 1 OK — secret_id: ' + secretId);

  Logger.log('Paso 2/3: Creando configuración LLM...');
  var llmConfigId = crearConfiguracionLLM(secretId);
  if (!llmConfigId) {
    Logger.log('FALLO en Paso 2. Revisá los logs.');
    return;
  }
  Logger.log('Paso 2 OK — llm_configuration_id: ' + llmConfigId);

  Logger.log('Paso 3/3: Actualizando contexto de ZOE...');
  var ok = actualizarContextoConLLM(llmConfigId);
  if (!ok) {
    Logger.log('FALLO en Paso 3. Revisá los logs.');
    return;
  }

  Logger.log('');
  Logger.log('=== CONFIGURACIÓN COMPLETA ===');
  Logger.log('ZOE ahora usa GAS como su LLM en LiveAvatar.');
  Logger.log('El avatar esperará la respuesta de ZOE antes de hablar.');
  Logger.log('El problema de trabado debería estar resuelto.');
}

/**
 * Si querés verificar qué IDs quedaron guardados
 */
function verificarConfiguracionLLM() {
  var props = PropertiesService.getScriptProperties();
  Logger.log('LA_SECRET_ID:     ' + (props.getProperty('LA_SECRET_ID')     || 'NO GUARDADO'));
  Logger.log('LA_LLM_CONFIG_ID: ' + (props.getProperty('LA_LLM_CONFIG_ID') || 'NO GUARDADO'));
  Logger.log('CONTEXT_ID:       ' + (props.getProperty('CONTEXT_ID')       || 'NO GUARDADO'));
  Logger.log('WEBHOOK_URL:      ' + (props.getProperty('WEBHOOK_URL')       || 'NO GUARDADO'));
}

// ================================================================
// SESSION TOKEN CON CUSTOM LLM
// Crea el token de sesión incluyendo llm_configuration_id
// para que LiveAvatar use GAS como su LLM en lugar del OpenAI interno.
// El frontend llama a este endpoint para obtener el token y arrancar la sesión.
// ================================================================

function crearSessionToken() {
  var props     = PropertiesService.getScriptProperties();
  var apiKey    = props.getProperty('API_KEY');
  var avatarId  = props.getProperty('AVATAR_ID');
  var voiceId   = props.getProperty('VOICE_ID');
  var contextId = props.getProperty('CONTEXT_ID');
  var llmId     = props.getProperty('LA_LLM_CONFIG_ID');
  var language  = props.getProperty('AVATAR_LANGUAGE') || 'es';

  if (!apiKey || !avatarId || !llmId) {
    return { error: 'Faltan propiedades: API_KEY, AVATAR_ID o LA_LLM_CONFIG_ID' };
  }

  var payload = {
    avatar_id: avatarId,
    avatar_persona: {
      context_id: contextId,
      language:   language
    },
    mode:              'FULL',
    is_sandbox:        false,
    interactivity_type:'CONVERSATIONAL',
    llm_configuration_id: llmId
  };

  if (voiceId) payload.avatar_persona.voice_id = voiceId;

  try {
    var res = UrlFetchApp.fetch('https://api.liveavatar.com/v1/sessions/token', {
      method:  'post',
      headers: { 'X-API-KEY': apiKey, 'Content-Type': 'application/json' },
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    var data = JSON.parse(res.getContentText());
    Logger.log('Session token: HTTP ' + code);
    Logger.log(JSON.stringify(data));
    if (code === 200 && data.data && data.data.session_token) {
      Logger.log('SESSION TOKEN OK: ' + data.data.session_token.substring(0, 30) + '...');
      return { token: data.data.session_token };
    }
    return { error: 'HTTP ' + code + ': ' + JSON.stringify(data) };
  } catch(e) {
    Logger.log('Error crearSessionToken: ' + e.message);
    return { error: e.message };
  }
}

// doGet: sirve el token al frontend via GET request
// El frontend llama a /exec?action=token y recibe el session token
function doGet(e) {
  var action = (e && e.parameter && e.parameter.action) || '';

  if (action === 'token') {
    var result = crearSessionToken();
    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  }

  // Página HTML de ZOE — sirve el frontend completo
  return HtmlService.createHtmlOutput(getPaginaZOE())
    .setTitle('ZOE — Malditos Optimistas')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getPaginaZOE() {
  // El token se genera SERVER-SIDE y se embebe directamente en el HTML
  // Así no hay fetch desde el browser → no hay problema de CORS
  var tokenResult = crearSessionToken();
  if (tokenResult.error) {
    return '<html><body style="background:#000;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;"><h2>Error al generar token: ' + tokenResult.error + '</h2></body></html>';
  }
  var token = tokenResult.token;

  return '<!DOCTYPE html><html><head>' +
    '<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>ZOE — Malditos Optimistas</title>' +
    '<style>' +
    '@import url("https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap");' +
    '*{margin:0;padding:0;box-sizing:border-box;}' +
    'body{background:#0a0a0f;font-family:Inter,sans-serif;color:#fff;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;}' +
    '.logo{font-size:1rem;letter-spacing:6px;text-transform:uppercase;opacity:0.4;margin-bottom:2rem;}' +
    '.title{font-size:2.5rem;font-weight:600;margin-bottom:0.5rem;background:linear-gradient(135deg,#fff 0%,#a78bfa 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}' +
    '.subtitle{font-size:0.9rem;opacity:0.4;margin-bottom:2.5rem;letter-spacing:1px;}' +
    '.btn{background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border:none;padding:16px 48px;border-radius:100px;font-size:1rem;cursor:pointer;font-weight:600;letter-spacing:1px;transition:all 0.2s;box-shadow:0 0 40px rgba(79,70,229,0.4);}' +
    '.btn:hover{transform:scale(1.03);box-shadow:0 0 60px rgba(79,70,229,0.6);}' +
    '.btn:disabled{opacity:0.4;cursor:not-allowed;transform:none;}' +
    '.status{margin-top:1.5rem;font-size:0.85rem;opacity:0.4;letter-spacing:1px;}' +
    '#container{width:100%;max-width:900px;aspect-ratio:16/9;border-radius:16px;overflow:hidden;display:none;box-shadow:0 0 80px rgba(79,70,229,0.3);}' +
    '#container iframe{width:100%;height:100%;border:none;}' +
    '</style></head><body>' +
    '<div class="logo">Malditos Optimistas</div>' +
    '<div class="title">ZOE</div>' +
    '<div class="subtitle">Co-conductora IA agéntica</div>' +
    '<button class="btn" id="btn" onclick="iniciar()">Iniciar sesión</button>' +
    '<div class="status" id="status"></div>' +
    '<div id="container"><iframe id="frame" allow="microphone; camera; autoplay; display-capture"></iframe></div>' +
    '<script>' +
    'var SESSION_TOKEN = "' + token + '";' +
    'function iniciar() {' +
    '  var btn = document.getElementById("btn");' +
    '  var status = document.getElementById("status");' +
    '  btn.disabled = true;' +
    '  btn.textContent = "Conectando...";' +
    '  status.textContent = "Iniciando sesión con ZOE...";' +
    '  var frameUrl = "https://app.liveavatar.com/session?token=" + encodeURIComponent(SESSION_TOKEN);' +
    '  var frame = document.getElementById("frame");' +
    '  frame.src = frameUrl;' +
    '  document.getElementById("container").style.display = "block";' +
    '  btn.style.display = "none";' +
    '  status.textContent = "ZOE en vivo";' +
    '}' +
    '</script></body></html>';
}



// Test: verificar que el session token se crea correctamente
function testSessionToken() {
  Logger.log('=== TEST SESSION TOKEN ===');
  var result = crearSessionToken();
  if (result.token) {
    Logger.log('OK — Token creado correctamente');
    Logger.log('Token (primeros 40 chars): ' + result.token.substring(0, 40) + '...');
  } else {
    Logger.log('ERROR: ' + result.error);
  }
}

// Verificar si el LLM config existe en la cuenta
function verificarLLMConfigs() {
  var props  = PropertiesService.getScriptProperties();
  var apiKey = props.getProperty('API_KEY');
  var llmId  = props.getProperty('LA_LLM_CONFIG_ID');

  Logger.log('LLM Config ID guardado: ' + (llmId || 'NINGUNO'));

  // Listar todas las configuraciones LLM
  try {
    var res = UrlFetchApp.fetch('https://api.liveavatar.com/v1/llm-configurations', {
      method:  'get',
      headers: { 'X-API-KEY': apiKey },
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    var data = JSON.parse(res.getContentText());
    Logger.log('LLM Configs HTTP: ' + code);
    Logger.log(JSON.stringify(data, null, 2));
  } catch(e) {
    Logger.log('Error listando configs: ' + e.message);
  }
}

// Crear session token con llm_configuration_id en el nivel raíz del payload
// (no dentro de avatar_persona) según el ejemplo exacto de soporte
function crearSessionTokenConLLM() {
  var props     = PropertiesService.getScriptProperties();
  var apiKey    = props.getProperty('API_KEY');
  var avatarId  = props.getProperty('AVATAR_ID');
  var voiceId   = props.getProperty('VOICE_ID');
  var contextId = props.getProperty('CONTEXT_ID');
  var llmId     = props.getProperty('LA_LLM_CONFIG_ID');
  var language  = props.getProperty('AVATAR_LANGUAGE') || 'es';

  Logger.log('Usando llm_configuration_id: ' + llmId);

  // Payload exacto según el ejemplo de soporte de LiveAvatar
  var payload = {
    avatar_id: avatarId,
    avatar_persona: {
      voice_id:   voiceId,
      context_id: contextId,
      language:   language
    },
    mode:                 'FULL',
    is_sandbox:           false,
    interactivity_type:   'CONVERSATIONAL',
    llm_configuration_id: llmId   // nivel raíz, no dentro de avatar_persona
  };

  Logger.log('Payload: ' + JSON.stringify(payload));

  try {
    var res = UrlFetchApp.fetch('https://api.liveavatar.com/v1/sessions/token', {
      method:  'post',
      headers: { 'X-API-KEY': apiKey, 'Content-Type': 'application/json' },
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    });
    var code = res.getResponseCode();
    var body = res.getContentText();
    Logger.log('HTTP: ' + code);
    Logger.log('Response: ' + body);

    var data = JSON.parse(body);
    if (code === 200 && data.data && data.data.session_token) {
      // Decodificar JWT para verificar que llm_configuration_id está adentro
      var tokenParts = data.data.session_token.split('.');
      var padded = tokenParts[1];
      while (padded.length % 4) padded += '=';
      // GAS no tiene atob nativo para base64url — verificamos en logs
      Logger.log('TOKEN CREADO OK');
      Logger.log('Revisar si llm_configuration_id aparece en el JWT decodificado');
      return data.data.session_token;
    }
    Logger.log('ERROR: ' + body);
    return null;
  } catch(e) {
    Logger.log('Exception: ' + e.message);
    return null;
  }
}

// Corregir el LLM Config ID al valor correcto y verificar
function corregirYTestearLLM() {
  var props = PropertiesService.getScriptProperties();

  // El ID correcto es el que se creó exitosamente según el log anterior
  var llmIdCorrecto = '88386443-61d8-49f4-92d5-0db87664b7bd';
  props.setProperty('LA_LLM_CONFIG_ID', llmIdCorrecto);
  Logger.log('LA_LLM_CONFIG_ID actualizado a: ' + llmIdCorrecto);

  // Verificar que quedó guardado
  Logger.log('Verificando: ' + props.getProperty('LA_LLM_CONFIG_ID'));

  // Crear token con el ID correcto
  var token = crearSessionTokenConLLM();
  if (token) {
    Logger.log('TOKEN OK — longitud: ' + token.length);
    // Mostrar el payload del JWT (parte del medio, base64)
    var parts = token.split('.');
    Logger.log('JWT payload (base64): ' + parts[1]);
  }
}

// Actualizar el LLM config con la URL del Cloudflare Worker
// Ejecutar después de deployar el worker
function actualizarLLMConfigConWorker(workerUrl) {
  var props  = PropertiesService.getScriptProperties();
  var apiKey = props.getProperty('API_KEY');
  var llmId  = '88386443-61d8-49f4-92d5-0db87664b7bd';

  if (!workerUrl) {
    Logger.log('ERROR: Pasá la URL del worker como parámetro');
    Logger.log('Ejemplo: actualizarLLMConfigConWorker("https://zoe-bridge.tuusuario.workers.dev")');
    return;
  }

  Logger.log('Actualizando LLM config ' + llmId + ' con base_url: ' + workerUrl);

  // Hay que crear un nuevo config porque LiveAvatar no permite editar el base_url
  // del config existente
  var secretId = props.getProperty('LA_SECRET_ID');

  var res = UrlFetchApp.fetch('https://api.liveavatar.com/v1/llm-configurations', {
    method:  'post',
    headers: { 'X-API-KEY': apiKey, 'Content-Type': 'application/json' },
    payload: JSON.stringify({
      display_name: 'ZOE Worker Bridge',
      model_name:   'gpt-4o-mini',
      secret_id:    secretId,
      base_url:     workerUrl
    }),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('HTTP: ' + code);
  Logger.log(JSON.stringify(data));

  if (code === 200 && data.data && data.data.id) {
    var nuevoId = data.data.id;
    props.setProperty('LA_LLM_CONFIG_ID', nuevoId);
    Logger.log('NUEVO LLM Config ID: ' + nuevoId);
    Logger.log('Ahora ejecutá testSessionToken() para verificar');
    return nuevoId;
  }
  Logger.log('ERROR creando config');
  return null;
}

// ================================================================
// DEPLOY AUTOMÁTICO DEL CLOUDFLARE WORKER DESDE GAS
// Necesitás el Account ID y API Token de Cloudflare.
// Ejecutá: desplegarWorkerCloudflare()
// ================================================================

function desplegarWorkerCloudflare() {
  var props = PropertiesService.getScriptProperties();

  // Obtener credenciales de Cloudflare
  var cfAccountId = props.getProperty('CF_ACCOUNT_ID');
  var cfApiToken  = props.getProperty('CF_API_TOKEN');
  var gasUrl      = props.getProperty('WEBHOOK_URL');

  if (!cfAccountId || !cfApiToken) {
    Logger.log('FALTAN CREDENCIALES DE CLOUDFLARE');
    Logger.log('Ejecutá primero: guardarCredencialesCloudflare("TU_ACCOUNT_ID", "TU_API_TOKEN")');
    Logger.log('');
    Logger.log('Dónde encontrarlas:');
    Logger.log('Account ID: dash.cloudflare.com → lado derecho → Account ID');
    Logger.log('API Token:  dash.cloudflare.com → perfil → API Tokens → Create Token → Edit Workers');
    return;
  }

  var workerName = 'calm-credit-38f7'; // el worker que ya creaste
  var workerCode = 'export default {\n  async fetch(request, env) {\n    const url = new URL(request.url);\n    const cors = {\'Access-Control-Allow-Origin\':\'*\',\'Access-Control-Allow-Methods\':\'GET,POST,OPTIONS\',\'Access-Control-Allow-Headers\':\'Content-Type,Authorization\'};\n    if (request.method === \'OPTIONS\') return new Response(null, {headers: cors});\n\n    // GET /token — genera session token con llm_configuration_id\n    if (request.method === \'GET\' && url.pathname === \'/token\') {\n      try {\n        const res = await fetch(\'https://api.liveavatar.com/v1/sessions/token\', {\n          method: \'POST\',\n          headers: {\'X-API-KEY\': env.LA_API_KEY, \'Content-Type\': \'application/json\'},\n          body: JSON.stringify({\n            avatar_id: env.LA_AVATAR_ID,\n            avatar_persona: {voice_id: env.LA_VOICE_ID, context_id: env.LA_CONTEXT_ID, language: \'es\'},\n            mode: \'FULL\', is_sandbox: false, interactivity_type: \'CONVERSATIONAL\',\n            llm_configuration_id: env.LA_LLM_ID\n          })\n        });\n        const data = await res.json();\n        if (data.data && data.data.session_token) {\n          return new Response(JSON.stringify({token: data.data.session_token}), {headers: {...cors, \'Content-Type\': \'application/json\'}});\n        }\n        return new Response(JSON.stringify({error: JSON.stringify(data)}), {status: 500, headers: {...cors, \'Content-Type\': \'application/json\'}});\n      } catch(e) {\n        return new Response(JSON.stringify({error: e.message}), {status: 500, headers: {...cors, \'Content-Type\': \'application/json\'}});\n      }\n    }\n\n    // POST /chat/completions — reenvía a GAS\n    if (request.method === \'POST\' && url.pathname === \'/chat/completions\') {\n      try {\n        const body = await request.json();\n        const messages = body.messages || [];\n        let userMsg = \'\';\n        for (let i = messages.length-1; i >= 0; i--) {\n          if (messages[i].role === \'user\' && messages[i].content) {userMsg = messages[i].content.trim(); break;}\n        }\n        if (!userMsg) return openAIResp(\'\', cors);\n        const gasRes = await fetch(env.GAS_URL, {method: \'POST\', headers: {\'Content-Type\': \'application/json\'}, body: JSON.stringify({messages: body.messages, user: body.user||\'Usuario\'})});\n        if (!gasRes.ok) return openAIResp(\'\', cors);\n        const gasData = await gasRes.json();\n        const r = (gasData.choices && gasData.choices[0]) ? gasData.choices[0].message.content : (gasData.reply || \'\');\n        return openAIResp(r, cors);\n      } catch(e) {return openAIResp(\'\', cors);}\n    }\n\n    // GET / — página de ZOE\n    const workerUrl = \'https://\' + url.host;\n    const html = \`<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ZOE — Malditos Optimistas</title><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet"><style>*{margin:0;padding:0;box-sizing:border-box;}body{background:#060610;font-family:\'Inter\',sans-serif;color:#fff;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;}body::before{content:\'\';position:fixed;width:600px;height:600px;background:radial-gradient(circle,rgba(79,70,229,0.15) 0%,transparent 70%);top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none;}.brand{font-size:0.7rem;letter-spacing:8px;text-transform:uppercase;color:rgba(255,255,255,0.25);margin-bottom:1.5rem;}.title{font-size:5rem;font-weight:700;letter-spacing:-2px;background:linear-gradient(135deg,#fff 0%,#a78bfa 60%,#7c3aed 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:0.5rem;line-height:1;}.subtitle{font-size:0.85rem;color:rgba(255,255,255,0.3);letter-spacing:3px;text-transform:uppercase;margin-bottom:3rem;}.btn{background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;border:none;padding:18px 56px;border-radius:100px;font-size:1rem;font-family:\'Inter\',sans-serif;font-weight:600;letter-spacing:1px;cursor:pointer;transition:all 0.3s;box-shadow:0 0 50px rgba(79,70,229,0.5);}.btn:hover{transform:scale(1.04);box-shadow:0 0 80px rgba(79,70,229,0.7);}.btn:disabled{opacity:0.5;cursor:not-allowed;transform:none;}.status{margin-top:1.5rem;font-size:0.8rem;color:rgba(255,255,255,0.3);letter-spacing:2px;min-height:1.2rem;}#container{display:none;width:100%;max-width:960px;flex-direction:column;align-items:center;}.wrap{width:100%;aspect-ratio:16/9;border-radius:20px;overflow:hidden;box-shadow:0 0 100px rgba(79,70,229,0.4);position:relative;}video{width:100%;height:100%;object-fit:cover;background:#0a0a1a;}.live{position:absolute;top:16px;left:16px;background:#ef4444;color:white;font-size:0.7rem;font-weight:700;letter-spacing:2px;padding:4px 12px;border-radius:100px;display:flex;align-items:center;gap:6px;}.live::before{content:\'\';width:6px;height:6px;background:white;border-radius:50%;animation:pulse 1.5s infinite;}@keyframes pulse{0%,100%{opacity:1;}50%{opacity:0.3;}}</style></head><body><div id="start" style="display:flex;flex-direction:column;align-items:center;"><div class="brand">Malditos Optimistas</div><div class="title">ZOE</div><div class="subtitle">Co-conductora IA agéntica</div><button class="btn" id="btn" onclick="iniciar()">Iniciar sesión en vivo</button><div class="status" id="st"></div></div><div id="container"><div class="wrap"><video id="vid" autoplay playsinline></video><div class="live">EN VIVO</div></div></div><script type="module">import {LiveAvatarSession} from \'https://esm.sh/@heygen/liveavatar-web-sdk@latest\';window.iniciar=async function(){const btn=document.getElementById(\'btn\'),st=document.getElementById(\'st\');btn.disabled=true;btn.textContent=\'Conectando...\';st.textContent=\'OBTENIENDO TOKEN...\';try{const res=await fetch(\'\${workerUrl}/token\');const data=await res.json();if(data.error){st.textContent=\'Error: \'+data.error;btn.disabled=false;btn.textContent=\'Reintentar\';return;}st.textContent=\'INICIANDO AVATAR...\';const session=new LiveAvatarSession(data.token,{voiceChat:true});session.on(\'stream\',(stream)=>{document.getElementById(\'vid\').srcObject=stream;});session.on(\'ready\',()=>{document.getElementById(\'start\').style.display=\'none\';const c=document.getElementById(\'container\');c.style.display=\'flex\';});session.on(\'error\',(e)=>{st.textContent=\'Error: \'+e.message;btn.disabled=false;btn.textContent=\'Reintentar\';});await session.start();}catch(e){st.textContent=\'Error: \'+e.message;btn.disabled=false;btn.textContent=\'Reintentar\';}};</script></body></html>\`;\n    return new Response(html, {headers: {\'Content-Type\': \'text/html;charset=UTF-8\'}});\n  }\n};\nfunction openAIResp(content, cors) {\n  return new Response(JSON.stringify({id:\'chatcmpl-zoe-\'+Date.now(),object:\'chat.completion\',created:Math.floor(Date.now()/1000),model:\'gpt-4o-mini\',choices:[{index:0,message:{role:\'assistant\',content:content||\'\'},finish_reason:\'stop\'}],usage:{prompt_tokens:0,completion_tokens:0,total_tokens:0}}),{headers:{...cors,\'Content-Type\':\'application/json\'}});\n}';;

  Logger.log('Deploying worker "' + workerName + '"...');

  // Subir el código del worker via API
  var formData = Utilities.newBlob(
    '--boundary\r\nContent-Disposition: form-data; name="metadata"\r\nContent-Type: application/json\r\n\r\n' +
    JSON.stringify({ main_module: "worker.js" }) +
    '\r\n--boundary\r\nContent-Disposition: form-data; name="worker.js"; filename="worker.js"\r\nContent-Type: application/javascript+module\r\n\r\n' +
    workerCode +
    '\r\n--boundary--',
    'multipart/form-data; boundary=boundary'
  );

  var res = UrlFetchApp.fetch(
    'https://api.cloudflare.com/client/v4/accounts/' + cfAccountId + '/workers/scripts/' + workerName,
    {
      method: 'put',
      headers: {
        'Authorization': 'Bearer ' + cfApiToken,
        'Content-Type':  'multipart/form-data; boundary=boundary'
      },
      payload: formData.getBytes(),
      muteHttpExceptions: true
    }
  );

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Deploy HTTP: ' + code);

  if (!data.success) {
    Logger.log('ERROR: ' + JSON.stringify(data.errors));
    return;
  }
  Logger.log('Worker deployado OK');

  // Agregar variable GAS_URL via multipart/form-data (requerido por Cloudflare)
  var boundary = 'boundary' + Date.now();
  var settingsJson = JSON.stringify({
    bindings: [{ type: 'plain_text', name: 'GAS_URL', text: gasUrl }]
  });
  var multipartBody =
    '--' + boundary + '\r\n' +
    'Content-Disposition: form-data; name="settings"\r\nContent-Type: application/json\r\n\r\n' +
    settingsJson + '\r\n' +
    '--' + boundary + '--';

  var resVar = UrlFetchApp.fetch(
    'https://api.cloudflare.com/client/v4/accounts/' + cfAccountId + '/workers/scripts/' + workerName + '/settings',
    {
      method: 'patch',
      headers: {
        'Authorization': 'Bearer ' + cfApiToken,
        'Content-Type':  'multipart/form-data; boundary=' + boundary
      },
      payload: Utilities.newBlob(multipartBody, 'multipart/form-data; boundary=' + boundary).getBytes(),
      muteHttpExceptions: true
    }
  );

  var codeVar = resVar.getResponseCode();
  var bodyVar = resVar.getContentText();
  Logger.log('Variable GAS_URL HTTP: ' + codeVar);
  Logger.log('Response: ' + bodyVar);

  var dataVar = JSON.parse(bodyVar);
  if (dataVar.success) {
    var workerUrl = 'https://' + workerName + '.malditosoptimistas.workers.dev';
    Logger.log('');
    Logger.log('=== WORKER LISTO ===');
    Logger.log('URL: ' + workerUrl);
    Logger.log('Ahora ejecutá: actualizarLLMConfigConWorker("' + workerUrl + '")');
    props.setProperty('CF_WORKER_URL', workerUrl);
    return workerUrl;
  } else {
    Logger.log('ERROR variable: ' + JSON.stringify(dataVar.errors || dataVar));
  }
}

function guardarCredencialesCloudflare(accountId, apiToken) {
  var props = PropertiesService.getScriptProperties();
  props.setProperty('CF_ACCOUNT_ID', accountId);
  props.setProperty('CF_API_TOKEN',  apiToken);
  Logger.log('Credenciales Cloudflare guardadas OK');
  Logger.log('Ahora ejecutá: desplegarWorkerCloudflare()');
}

// EJECUTÁ ESTA FUNCIÓN UNA SOLA VEZ PARA CONFIGURAR CLOUDFLARE
function setupCloudflare() {
  guardarCredencialesCloudflare(
    "e1a2cfe83a065d80a2318e515a8f397f",
    "cfut_0CRXWf2psqkIZzmf1GznaqxWGzwPe25h02kzwAHN804e9acc"
  );
  desplegarWorkerCloudflare();
}

function conectarWorkerALiveAvatar() {
  actualizarLLMConfigConWorker("https://calm-credit-38f7.malditosoptimistas.workers.dev");
}

// FUNCIÓN LIMPIA — solo guarda el ID correcto, no crea nada nuevo
function fijarLLMConfigCorrecto() {
  var props = PropertiesService.getScriptProperties();
  // El config correcto con el Worker URL
  var llmIdCorrecto = 'b1a577ec-d1c9-41d4-8cc3-6d7228114c13';
  props.setProperty('LA_LLM_CONFIG_ID', llmIdCorrecto);
  Logger.log('LA_LLM_CONFIG_ID fijado a: ' + llmIdCorrecto);
  Logger.log('base_url: https://calm-credit-38f7.malditosoptimistas.workers.dev');
  Logger.log('');
  Logger.log('Ahora ejecutá: probarSesionConLLM()');
}

// PROBAR que el session token incluye el llm_configuration_id correcto
function probarSesionConLLM() {
  var props  = PropertiesService.getScriptProperties();
  var apiKey    = props.getProperty('API_KEY');
  var avatarId  = props.getProperty('AVATAR_ID');
  var voiceId   = props.getProperty('VOICE_ID');
  var contextId = props.getProperty('CONTEXT_ID');
  var llmId     = props.getProperty('LA_LLM_CONFIG_ID');
  var language  = props.getProperty('AVATAR_LANGUAGE') || 'es';

  Logger.log('Creando session token con llm_configuration_id: ' + llmId);

  var payload = {
    avatar_id: avatarId,
    avatar_persona: {
      voice_id:   voiceId,
      context_id: contextId,
      language:   language
    },
    mode:                 'FULL',
    is_sandbox:           false,
    interactivity_type:   'CONVERSATIONAL',
    llm_configuration_id: llmId
  };

  var res = UrlFetchApp.fetch('https://api.liveavatar.com/v1/sessions/token', {
    method:  'post',
    headers: { 'X-API-KEY': apiKey, 'Content-Type': 'application/json' },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('HTTP: ' + code);

  if (code === 200 && data.data && data.data.session_token) {
    Logger.log('SESSION TOKEN CREADO OK');
    Logger.log('session_id: ' + data.data.session_id);
    Logger.log('');
    Logger.log('Ahora abrí una sesión con este token en LiveAvatar y preguntale algo a ZOE.');
    Logger.log('Fijate en Cloudflare Workers → calm-credit-38f7 → Observability si llegan requests.');
    Logger.log('Si llegan requests al Worker = custom LLM funcionando.');
    return data.data.session_token;
  }
  Logger.log('ERROR: ' + JSON.stringify(data));
  return null;
}

// Actualizar variables del Worker (todas las necesarias para la página de ZOE)
function actualizarVariablesWorker() {
  var props     = PropertiesService.getScriptProperties();
  var cfAccountId = props.getProperty('CF_ACCOUNT_ID');
  var cfApiToken  = props.getProperty('CF_API_TOKEN');
  var workerName  = 'calm-credit-38f7';
  var boundary    = 'boundary' + Date.now();

  var bindings = [
    { type: 'plain_text', name: 'GAS_URL',       text: props.getProperty('WEBHOOK_URL') },
    { type: 'plain_text', name: 'LA_API_KEY',    text: props.getProperty('API_KEY') },
    { type: 'plain_text', name: 'LA_AVATAR_ID',  text: props.getProperty('AVATAR_ID') },
    { type: 'plain_text', name: 'LA_VOICE_ID',   text: props.getProperty('VOICE_ID') },
    { type: 'plain_text', name: 'LA_CONTEXT_ID', text: props.getProperty('CONTEXT_ID') },
    { type: 'plain_text', name: 'LA_LLM_ID',     text: props.getProperty('LA_LLM_CONFIG_ID') }
  ];

  var settingsJson = JSON.stringify({ bindings: bindings });
  var multipartBody =
    '--' + boundary + '\r\n' +
    'Content-Disposition: form-data; name="settings"\r\nContent-Type: application/json\r\n\r\n' +
    settingsJson + '\r\n' +
    '--' + boundary + '--';

  var res = UrlFetchApp.fetch(
    'https://api.cloudflare.com/client/v4/accounts/' + cfAccountId + '/workers/scripts/' + workerName + '/settings',
    {
      method: 'patch',
      headers: {
        'Authorization': 'Bearer ' + cfApiToken,
        'Content-Type':  'multipart/form-data; boundary=' + boundary
      },
      payload: Utilities.newBlob(multipartBody, 'multipart/form-data; boundary=' + boundary).getBytes(),
      muteHttpExceptions: true
    }
  );

  var code = res.getResponseCode();
  var data = JSON.parse(res.getContentText());
  Logger.log('Variables Worker HTTP: ' + code);

  if (data.success) {
    Logger.log('OK — todas las variables configuradas');
    Logger.log('LA_LLM_ID: ' + props.getProperty('LA_LLM_CONFIG_ID'));
    Logger.log('');
    Logger.log('Abrí esta URL para usar ZOE:');
    Logger.log('https://calm-credit-38f7.malditosoptimistas.workers.dev');
  } else {
    Logger.log('ERROR: ' + JSON.stringify(data.errors));
  }
}
