/**
 * ================================================================
 * ZOE — HANDLER FORMATO OPENAI PARA LIVEAVATAR
 * ================================================================
 * PEGÁ ESTE BLOQUE AL FINAL DE TU CÓDIGO (después del setup anterior)
 *
 * QUÉ HACE:
 * LiveAvatar llama al webhook con formato OpenAI /chat/completions.
 * Este handler detecta ese formato, procesa con ZOE, y responde
 * en formato OpenAI para que LiveAvatar lo entienda.
 *
 * FLUJO:
 * LiveAvatar → GAS (formato OpenAI) → ZOE procesa → GAS responde (formato OpenAI) → Avatar habla
 * ================================================================
 */

// ================================================================
// DETECTOR DE FORMATO — ¿viene de LiveAvatar o del webhook normal?
// ================================================================

function esRequestOpenAI(body) {
  // LiveAvatar manda: { model, messages: [{role, content}], stream, ... }
  return body && body.messages && Array.isArray(body.messages);
}

function extraerMensajeDeOpenAI(body) {
  // Tomar el último mensaje del usuario
  var mensajes = body.messages || [];
  for (var i = mensajes.length - 1; i >= 0; i--) {
    if (mensajes[i].role === 'user' && mensajes[i].content) {
      return mensajes[i].content;
    }
  }
  return '';
}

function respuestaFormatoOpenAI(texto) {
  // Respuesta compatible con OpenAI /chat/completions
  return JSON.stringify({
    id:      'chatcmpl-zoe-' + Date.now(),
    object:  'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model:   'gpt-4o-mini',
    choices: [{
      index:         0,
      message: {
        role:    'assistant',
        content: texto || ''
      },
      finish_reason: 'stop'
    }],
    usage: {
      prompt_tokens:     0,
      completion_tokens: 0,
      total_tokens:      0
    }
  });
}

// ================================================================
// REEMPLAZAR doPost — versión que maneja AMBOS formatos
// ================================================================
// IMPORTANTE: Esta función REEMPLAZA a doPost() del código principal.
// Si tenés doPost() más arriba, renombrala a doPostOriginal() 
// y esta nueva versión se encarga de todo.

function doPost(e) {
  try {
    var body = {};
    if (e && e.postData && e.postData.contents) {
      body = JSON.parse(e.postData.contents);
    }

    Logger.log('WEBHOOK entrada — keys: ' + Object.keys(body).join(', '));

    // ── FORMATO LIVEAVATAR (OpenAI /chat/completions) ──────────────
    if (esRequestOpenAI(body)) {
      Logger.log('Formato OpenAI detectado — viene de LiveAvatar');

      var mensajeUsuario = extraerMensajeDeOpenAI(body);
      Logger.log('Mensaje extraído: "' + mensajeUsuario + '"');

      if (!mensajeUsuario || mensajeUsuario.trim().length < 2) {
        Logger.log('Mensaje vacío — devolviendo silencio');
        return ContentService.createTextOutput(
          respuestaFormatoOpenAI('')
        ).setMimeType(ContentService.MimeType.JSON);
      }

      // Procesar con ZOE — usa toda la lógica existente
      var speaker   = body.user || body.speaker || 'Usuario';
      var respuesta = procesarMensaje(mensajeUsuario, speaker);

      Logger.log('ZOE responde: "' + (respuesta || '[silencio]') + '"');

      // Si ZOE decide no responder (silencio activo), devolver vacío
      if (!respuesta || respuesta.trim() === '') {
        return ContentService.createTextOutput(
          respuestaFormatoOpenAI('')
        ).setMimeType(ContentService.MimeType.JSON);
      }

      // Activar speaking lock para evitar interrupciones
      var segundos = calcularSegundosHablando(respuesta);
      activarLockHablando(segundos);

      return ContentService.createTextOutput(
        respuestaFormatoOpenAI(respuesta)
      ).setMimeType(ContentService.MimeType.JSON);
    }

    // ── FORMATO WEBHOOK NORMAL (legado) ───────────────────────────
    Logger.log('Formato webhook normal');

    var mensaje  = body.message || body.text || '';
    var speaker  = body.speaker || 'Usuario';
    var esFinal  = body.is_final === true || body.final === true;

    var mensajeTrimmed = (mensaje || '').trim();

    if (!mensajeTrimmed || mensajeTrimmed.length < 3) {
      if (!esFinal) return _respuestaVacia();
      return _respuestaVacia();
    }

    var soloLetras = mensajeTrimmed.replace(/[^a-zA-ZáéíóúüñÁÉÍÓÚÜÑ]/g, '');
    if (soloLetras.length < 2) {
      Logger.log('Ruido: "' + mensajeTrimmed + '"');
      return _respuestaVacia();
    }

    if (!mensajeTrimmed || mensajeTrimmed.split(/\s+/).length < 4) {
      if (!esFinal) return _respuestaVacia();
    }

    if (estaHablando()) {
      Logger.log('Speaking lock — descartando');
      return _respuestaVacia();
    }

    if (esMensajeDeEspera(mensajeTrimmed)) {
      Logger.log('Mensaje de espera — silencio');
      return _respuestaVacia();
    }

    if (!estaInterpeladaDirectamente(mensajeTrimmed)) {
      Logger.log('No interpelada — silencio');
      return _respuestaVacia();
    }

    var cacheKey = 'turno_' + speaker.replace(/\s+/g, '_').toLowerCase();
    var ahora    = Date.now();

    if (!esFinal && !esPreguntaCompleta(mensajeTrimmed)) {
      _cache.put(cacheKey, JSON.stringify({ msg: mensajeTrimmed, ts: ahora }), 10);
      var debounceEfectivo = mensajeTrimmed.split(/\s+/).length > 10 ? 3500 : DEBOUNCE_MS;
      Utilities.sleep(debounceEfectivo);
      var cached = _cache.get(cacheKey);
      if (!cached) return _respuestaVacia();
      var cacheParsed = JSON.parse(cached);
      if (cacheParsed.ts !== ahora) return _respuestaVacia();
      mensajeTrimmed = cacheParsed.msg;
      _cache.remove(cacheKey);
    } else {
      _cache.remove(cacheKey);
    }

    var respuesta = procesarMensaje(mensajeTrimmed, speaker);
    if (!respuesta || respuesta.trim() === '') return _respuestaVacia();

    var seg = calcularSegundosHablando(respuesta);
    activarLockHablando(seg);

    Logger.log('Respuesta: ' + respuesta);
    return ContentService.createTextOutput(
      JSON.stringify({ ok: true, reply: respuesta, speak: true })
    ).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    Logger.log('ERROR doPost: ' + err);
    return ContentService.createTextOutput(
      JSON.stringify({ ok: false, error: err.message })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}
